![鲸鱼小屋 3D 房间预览](preview.svg)
