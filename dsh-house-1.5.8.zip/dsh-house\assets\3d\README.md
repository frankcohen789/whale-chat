# 海盐蓝卧室 · 3D 资产与 Three.js 原型

二次元治愈风海盐蓝卧室场景：**整屋高模与角色高模由参考图经图生 3D（Tripo v3.1）生成**（各约 180–190 万三角面、4K 贴图，EXT_meshopt_compression 压缩），外加一个可直接运行的 Three.js 单页原型（轨道旋转 + 点击拾取高亮 + 动画版角色切换）。

## 目录结构

```
whale-room-3d/
├── index.html            # 单页原型（场景、光照、拾取、动画切换、高模/动画版角色切换）
├── server.mjs            # 零依赖本地静态服务器（Node）
├── README.md
├── vendor/               # three 0.187 已本地化（含 meshopt 解码器），离线可跑，无需 npm / 联网
│   ├── three.module.js
│   ├── three.core.js
│   └── addons/           # OrbitControls / GLTFLoader / RoomEnvironment / MeshoptDecoder / utils
└── models/                # GLB 资产
    ├── room_tripo.glb    # AI 整屋高模（当前场景主房间）
    ├── fish_tripo.glb    # AI 角色高模（当前场景主人公，静态）
    ├── fish.glb          # 低模动画版角色（6 段动画，原型内可一键切换）
    ├── room_bedroom.glb  # 低模整屋（备用资产，原型默认不加载）
    ├── bed_whale.glb     # 低模单人床（备用资产）
    ├── desk_gaming.glb   # 低模书桌套装（备用资产）
    ├── bookshelf.glb     # 低模落地书架（备用资产）
    └── rug_whale.glb     # 低模圆地毯（备用资产）
```

## 运行

需要通过 HTTP 访问（ES Module 与 GLB 的 fetch 不能走 `file://` 双击打开）。

```bash
node server.mjs
# 打开 http://localhost:8080/
```

也可以用任意静态服务器把本目录挂起，例如 `npx serve .`。端口可用环境变量覆盖：`PORT=9000 node server.mjs`。

交互：左键拖拽环绕旋转，滚轮缩放；点击物件可高亮并查看说明；底部按钮切换角色动画，或在高模角色（静态）与动画版角色（低模、6 段动画）之间一键切换。相机已限位，只能在房间上方环绕。

AI 高模加载后由原型自动统一缩放（整屋对齐 4.0m × 3.2m × 2.6m 足迹，角色对齐约 1.2m 身高）、地面贴地、中心归位，无需手工摆位。

## GLB 资产清单

坐标系统一 **Y-up，单位米**；材质为 PBR（MeshStandardMaterial）。主要表面内嵌程序化生成的颜色贴图（baseColorTexture，PNG 直接打包进 GLB，无外部贴图文件依赖）：木纹地板、墙面涂料噪点、挂画芯、床毯鲸鱼印花、地毯鲸鱼海浪印花、角色脸部表情贴、围裙小鲸贴花；其余小件为纯色程序化材质。

| 文件 | 尺寸（宽×深×高） | 原点 | 内容 | 动画 |
| --- | --- | --- | --- | --- |
| `room_bedroom.glb` | 4.0 × 3.2 × 2.6 m | 地面中心 | 娃娃屋剖面：两面墙、木地板、大窗+窗框+白纱帘、带小玻璃窗的白门+黄铜把手、踢脚线与顶边收条、三幅墙面挂画、书桌上方双层壁挂木架（彩书+绿植）、悬挂吊兰与多处盆栽；前侧与顶部开放 | 无 |
| `bed_whale.glb` | 1.2 × 2.0 × 0.9 m | 床脚地面中心 | 木质床头、鲸鱼印花被面（内嵌贴图）、两个白枕、一只蓝鲸抱枕 | 无 |
| `desk_gaming.glb` | 桌 1.2 × 0.6 × 0.75 m | 桌脚地面中心 | 白色书桌 + 蓝白电竞椅 + 显示器 + 键盘 + 鼠标 | 无 |
| `bookshelf.glb` | 0.8 × 0.3 × 1.8 m | 书架底部中心 | 木质落地书架、三层彩色书册、一盆绿植（独立资产；原型场景默认使用房间内的壁挂木架，未摆放此落地书架） | 无 |
| `rug_whale.glb` | 直径 2.0 m，厚 2 cm | 地面中心 | 圆形地毯，顶面内嵌深蓝海浪+浅色鲸鱼+气泡印花贴图，白色外圈 | 无 |
| `fish.glb` | 约 1.2 m 高 | 脚底中心 | Q 版大头圆胖鲸鱼女仆：深蓝长卷发、头顶呆毛、白色头箍+侧蓝蝴蝶结、深色大鳍耳（内浅）、黑白女仆裙+白围裙（小鲸贴花）+胸前黑蝴蝶结+前排黑扣、深蓝弯尾；脸部为内嵌表情贴（蓝紫大眼、腮红、小嘴） | 6 段，见下 |

### fish.glb 动画剪辑名（`AnimationClip.name`）

| clip 名 | 含义 |
| --- | --- |
| `idle` | 待机（呼吸起伏、手臂微摆） |
| `sleep` | 睡觉（低头、身体前倾、手臂前垂） |
| `read` | 看书（双手前捧、低头） |
| `water` | 浇花（右臂上举、身体侧倾） |
| `eat` | 吃饭（右手抬到嘴边） |
| `sea` | 看海（左手指侧、头转向侧方） |

每段时长 2 秒，首尾关键帧一致，可循环播放。

## 二次接入要点

- **加载**：用 `GLTFLoader` 载入 `models/*.glb`；房间作为底板，其余物件按 `index.html` 中 `REGISTRY` 的 `pos / rotY` 摆位即可。
- **角色动画**：`const mixer = new THREE.AnimationMixer(gltf.scene)`；`mixer.clipAction(gltf.animations.find(a => a.name === 'idle')).play()`；每帧 `mixer.update(delta)`。切换时先 `fadeOut(0.25)` 再 `fadeIn(0.25)`。
- **拾取**：原型里每个物件组挂了 `userData.meta`（名称 / 描述），射线命中后沿 `userData.pickRoot` 回溯到整组。
- **重新生成**：建模脚本在另一工程的 `src/` 目录（`room.mjs / bed.mjs / desk.mjs / bookshelf.mjs / rug.mjs / fish.mjs`），基于 three 程序化几何体 + `GLTFExporter` 导出；改尺寸、配色或姿态后重跑脚本即可覆盖对应 GLB。

## 已知限制

- AI 高模（整屋 / 角色）由图生 3D 生成，未绑骨、无骨骼动画；需要角色动画时用底部按钮切到低模动画版（节点动画，形变精度有限）。
- AI 高模为单一贴图整模，物件不可单独拆出编辑；需要单独家具资产时用备用低模 GLB。
- 低模资产几何与贴图均为程序化生成，不含外部纹理与法线贴图；角色动画为关节节点驱动（非顶点蒙皮），大幅度动作下部件贴合度有限。
- 纱帘、玻璃为半透明材质，未做折射。
- AI 高模约 12–13 MB/个（meshopt 压缩后），首次加载需要数秒。
