/**
 * 鲸鱼小屋 · Client 端
 *
 * 主面板里的一间剖面小屋：布置、走进去、睡觉、做饭、吃饭、洗澡、看书、看海、浇花。
 * 状态与 host 端共用：/dsh-house/api 正常时读写 host；连不上时自动退回 localStorage
 * 本地模式，页面上会标出来。
 */

window.__ModuleLoader__.load({
  id: 'dsh-house',
  factory(require) {
    const module = { exports: {} }
    const exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })

    const React = require('react')
    const h = React.createElement
    const { useState, useEffect, useMemo, useRef, useSyncExternalStore } = React

    const PANEL_ID = 'dsh-house'
    const API = '/dsh-house/api'
    const CHAT_URL = 'https://47-243-234-136.sslip.io/?embed=1&v=2'
    const CHAT_OPEN_URL = 'https://47-243-234-136.sslip.io/'
    const LOCAL_KEY = 'dsh-house:state:v1'
    const AVATAR = 'data:image/webp;base64,UklGRlxAAABXRUJQVlA4IFBAAAAQ4ACdASpAAUABPmEqkUYkIqGhKTScSIAMCWVu4W++ABj0sEvj2hzw8z0i/6ggPcbf9ylWKwW5U/pvyx87/I164/gf249hvKv2Yf7/+f9Sf5N95v2f9//dP/GfOH++8AflB/neoX+Xf0T/S/3X90eF1nH9Qv3U+2/8j/G/vH7kH0n/X9HftL/z/cC/of9n/3HsJ/2PDf/Kf9b2Bf6p/j//Z/ofZC/8/9f/sf3G90/1V/5v9H8CH89/tn/R/xnt0ezL95v/////iP/aj//nL/e/2K33bMVISZUEtro76ArYri/8Ng6/C0/yBnvdsNP68QesF3HysYxQvFQwEcr+W0VXzKoqbO2acwtjyEj6mwz5EUKcqu35s85znL8yyoXDzPFgZ/gcks4oPbjCgR8OGqShqQZrUJCl75gwLky7RB5r0B0iqesnnOc39QTHR/gzryCwreob1Mef9v0cIX6DX2bFVGrsoHXCC802CtjA3BaMtqraURkVQUml3ETeu1tc9I+PnxWrbqKmZuE5zlstWVHWmCj9NQtai54XKhb9xM//+CL1l2L+Au80oJzFrDaSfL69fzKkmv5OryFGKE50r07SRtqRHBB68su55nr7Xlds84Aqz4LI/IA4jbkdJpeUFV81lL03BRk07ZHoRGtA5dQFT81DVSo1ThudyHcyZMCEfTd72317x4fMAmOKVR791U+rFcbTaUmcf2g5XgIdDfHIVTVkz584EGx5+CLSHts2R+Qe2+ZuyJZKvNeRvnulpenAo03SzxNFJc5GsPbPV7lEhxMFP+7RnKfvPWaBUYvDWgGxJb+1mXgt/ERfDk0wD5CY+dCqqyCvGogDa9Rh9YhSDnmN7Zr5nCZmNYU56kH/Ihfvk5TeSCrY2tDUc18u2sU24eTyIiNLHO1Y3zYyICfUOmE9oawroHLfkoAAYRG8SFyxnOdGQkF5tc47zwqOvRSRAUCKc8/o8Ky7Y7T/MBYcFUjuRO1eytpT5iQx7BTnnzugJTNWYEBBHj35uEF2b+GhCOUZny5txH5nAyJvfDyypG2Yc5mXn4DVY23W/CikP0DPIK8ppScUmHIbqHxwxGGsBReuljDtrNB+b2G12tYk5ak9xB3Ywu5DD14Mq+w2rtXuu+YK37oHXjNmmeA2Y0mvFjhwCVVE2+jNE9UZTUO++/hMPhfOls5206//eikrx4XNC2UjnOZOC5VdGgSf0r6D9G4mtEt2eXa3XKW6yk15+NQsWv4S/M8xdRZkO2uc4tiuPwSTl2MpNxv9RloIfuRs9knh7/vdK1soa37WW1rpT+ZhL/1DnCXdr5nC3HFUmzdzR4XjPzjLbePsyuB3lk7GuJgkS6CEgDTDof7931urATyGdd76TzcdPZG5v3X6x4VTrG/YYuCX/k4XQgUXZ/qTpJW459eA1FfXy3iyqdaU73K0jxYL2U0jeVJeFfeR6T6brZOwmESRFuxfCNeQugJImrt7DCPwitVtu24WKiuGn2QLJTsQ4iB41+3ZIW77YKEvLFdhzacT6Tr4c7GLUergJoA5xO//BLf+KIxuf1LOmQ/2oTc3L0giLEshCwUZuhBSuVyMv2lUBsjN/STwMG3wZ6t2VpdM37wSJ+YVLWvkgeIvKzp5mxmfSCfCJfcQW9aQlKgXvuxKpVnQ5vzWAsAhb5n7xbuIrNcXvdRGBYu4Esk05IfmsI2ymteKFRII5iy8i6tchG8rrRzcVzZW9g5v4u4CDjRxEd2i4qGZTDOroqCr7PZDf3I9xV3pXPR/tTKOTIJQP2NjmwFfNL4JOsf+c2QhIqeJOKTPurZu8cx4AlkYQCTGWE2dxi0PTUuQhCCXGHJulkaAvUxABS785oPu1lVZGvvPjBw4etERcbw3wXHSR+F/i0VTWBxg3wQV2rxFcdnS28YFLM893yiZoO1Fs+JPEGsloTbrwXXodP7fMNVvnySevvV07uS3l0Ynlsz240715RUegp18EZPibq7w0lBlx2AQoXlH2eDvjfA5HEsd9+FgP5mELqJ96uxiJuIEC3lC35939MuiZD/rdZiJYGRIIfAC8oqUWIClmQW8Tv7Tivlhbh7E6hFsNx1Of3FuFx7cFlCOGr4P+g/XHpIAbR2bkKD8awmlpCvOeho/BeI21mQJUAc2tC0clENA3qZslQKfocCbJl9wUX9bSt8bSpYnEngGhQ/DxGRJc96UjETtZ50284CGc8P9d7/2HLCtAQ+pr7BS04Qaz2nATe6oRG46NWAujUhIO8nmFELAT+433fn2xVmRFi/0NQ+Bv1QKgsuwWT6WLsGVkCIEy/Lfvji9nEzQe9DTyfAhBsoumZBQcOT0pp1HLxB262hrsi0SCv1j47H741pF9k5tGJnOMO51l6LNS+kiQlc22zw6iZH/74J9VcgAAP76DMi7wvzhHODHfrZ425RZu8sRmbDNIwXM8ZjG3VgXIusGKXzP5NfTtQbRJMk0d7X4VSyVZoVcBxMp/wwgDZgXMKc9Gy3GhsxqhKUeTfPSWIaNk6iVnXraKBOTCaRozeCrhMUNvak8dW39FiqzA8yy9+zCE/Ndzn+Gd2S1MLozqG5BSKqaG0klJc/uJ7ulFICAoRppYEF9Q0KjraDnj/zQWHdeAHG5CHZBg3QIR8H7I7uHhEJVpUq9tFV0dAePw8fzDkZtWPWzSj5NqTy+/Hs6K0TuA+KkQ3fZo0gPA8H5nhgE4LNVoW67rmW3DHgkoZ6WRvb3v1v+YVDxyKIM62zN9JqpzJiGhjGuzeFt/+wF5gABZT5QQXKaMpMF7UWQCPGpsswiBuzdD4Dq7d1YlzAASIvA+BZDCj9X7P/9thjwNGRMzxQKkJRuE5YAUY/9yZQrPSprG3z9krWXwR6ifigI6ENMyq/1cdHG1v0w6JnfFEJTLtWYhTq8pxcvYoO4PkFJLduXAL0ZjA+/jGaiP1Mtr2O8jQEG6FsadvqjlxjnnT85kF6VktNiyQ6VDVQjUoL6+ELMeZ3mLVV+/UmqPeLDPDqA8abVInaLL5qP2okbnZbSWs29GkRrecAc/RjcebCf1R71EJ4bU3+ys9DtS7//GLMFV+mU7dBY6niWQV3duWxoxBPnrEiCrfqcJSupdvKGvFxr76Gu5DBFaNzyHnvAC09S9ZvnI058YY0ZNXOtwuDkeYB615LaH2SU66qnEaNsHzi9qtdEtqY++71WUPJbxwBbYumZFD+k+QUF5xoSJ6y8wfyWFND63UMUuXPMkrr9uNPsjr+4Ry01getP0ABEfk+yjS/voptf4CFTNFY06ln4IP2K2qSXC98ve7UEsPfJH5CV2TboxyOOcr7wegaDVhjRj6T92Ng/6mm90FhFuUu7Yl7Aiaq2Nb0Nrwy5bapbYIclJZ/vXX8w7ay43mRKfiaxtA8SlSp64J3HkqimNRHvNveIvBGYKIF4FlmbXwft6MuxSmkwn2endiijx9G/N7UKGxlMmsnRZh3azxY+fh6qWBWnwTwXpSebCK5jzpX1nEdYjtvv0Nzqor/0qF1RqutcTvdGl/y/FYmGG66VXIoUMdNG0gPWHYyrDW9WKsSyk1wZ928g9ZV6WN3yAxPpfZq6vFneRvrIZhjUL0oTITa8pTgQODEj4QIS+mv0LObmQcSM7/Y8WUZSQgODA5NfDYxYhZ3lpT2VQ/SVtKhqI8rNTl06p6pRrwVRuIYvsFPWgmPy0CGkd/kEUve3ygGfJ5tCaiPm6hYv+ml+TlUySI0CPvn7YyVqdFXbPTtsnXC7sK65qzAT3vpEtx3yNynSUoqfAPYCK1AE1p3cLCfz4bPn0d3ElTNwrxF0cubn9C9rcgAW5LLW/sR8YOEineaBHGTR+nFi+bzThChsY9q2GYAG342ObL/w0PrSXPCApnmHq51SecW4+x7RnQAcqI5uHphJbFdSQsyLGjL5hopqP9z6hj35+Mneg4IHZII5Rn6OKPkCSs1RQ6BMmC/6sj0zX9An+R2dAvWgrBOuqNXYVjPzwE5BPsYkuXrQ63RhqsQfi2A3jmVdT3HstuWyrWVC9G99VNPUeEPsH+YjFyjF/irCouGUGl6bV+gGiLJjVhGcVptTEpeSv/BBvqBss90fZ4y3RzRKvCwANzcMN7q5p9ICVzMSHPdriCWdr/FQ+NBfEYE/jpIpYiLxvbQm+inwhlrGYLAZrx/xvJq7B1hCZbEFVO4KvHRVhYuhEAe10uk6ljBp4sKFTKku2ZMLVXesb8iaJUWQbks6em0g0L5GI2CyMlddVrzslmLfCMfccRFMgaJ0kpkovgmcJmrstSWgkQ7XF2LmxarepUAZ2B4bXzGczS4TMX1fUEgAq2zH0vH6BqRYRhTpUQpruuH6MmHkeX1mms+3AWnrU+ynmi22NZJJ7bw4RWc95lKnx7WEEEj7S0kFK1g6J5dQRLa0RrGcZ8vysLm0lNBMeUI8uccOy14c/0pSfwTna4MYPb+kV44zvoqv4sVF/BosMbEmDQ3Ao8YNByJTYlLgKnjPCAt140TiBonyHAm/nD8+WzQ1azKvLLME+no0ceSCGPXNxAx3vFxpVza67yBww58nt8A5vUpD/PUKfdItnLFJT/rWmQ+ZHbFkYaBNPKdJI8CjcwWLFA5JfopJTFye6SYiBa1gXv8v5ubCJCT7CMnOUTf868Xc6XrBseE7UhTFP/WfFM3qH6okEEGcAQDBQBzQRNd6H2kp+BgUGuTwSeAAE3/kpUiLi9v/zRhQvWTUpZj9d8af2mnIqYokx12nt9AJIuhtDOmjVZhysRs0YufLurh4KIsrentwMe5ILaVmcAv9cxR01A893L3QZmFSfXLXhlsPI3AGuJ7PRZYiFq2+WvEDMlHjbCbK6UZSNwQtE7XyZ2X6VqFUm/oWWQ9As5udtMt+0GKaiFjfovFb13NiGJpXQ1FNt7df7DVhrGZGRd7NKUpVIgbsZG+F2OmNSybiQUcEsJ+OuYqytp0PkZe4mYxj2RgitIiwiPxNvsSeB8zMO0L1k17qjHEn91fiXNS+KFGi64jusGKUNS8GtUBMFCG0ShjUU8nMEXrtarml0SDc3Yus2GGagapmcztjfAQCFmtGtDF3z+I+J4G1BBTZW1pRh2tnLCj+dBYRQCTDFkZqmTAsFOkWNI5kuxVh6BDh93ha9JBE7cXih8jD2p32saQxppOZZCyUyBnevqDhCz0MHX4ma+hG4dlAnPS4h/p99XVqInj6ZNz5C9L/PBDo9SNvKfm1zllwSgtsc2V7tSn9wDj6slItNyCVouZIPE+sMRqg0bPgOgOY+xjH7ilafFp0ZCDxR7mvWa5Y7eAtJQMfrUT2Ui55utEKAW7pzZUrVhQJ9f5YgMm+5CtREi5iyVyP0tfse1204ly6T6cc10hkgZl6L5CrlAL7kl2K8grNwQ44jCC3An/ZaDNbCIRSvxXiR/Dq5SCUkBW/87WGV2njUazr1TjhhcFzz6q5bqq/d+E9WY+Hm19tjn01KhsEdCNwbjrBBRjd7CTRO2N/UPrqtThaqUsCUrd4+UYx4EmjXl6+CnqRxJ+gQzN+7stsJefHjp+1U1nKu8wCcJjaPhX37hyKSMH4wU/cZQEPSNh6beV6UHNK65/ecWnUdTS/8Luh8TQ3WRH2EQk16PQVJ9PtEz3xhmH17CgQEA2F3lHQMhK80YCQbKgqv3P4QEUzkDwcmKPw+lW21ByODQUx3hncNFGDfMKwT6wjUZEctbPbxHgBtki0MHAU+yi5AJNJfLZkPqqUdsQgBBLBh/SiEXlB3btZeTF14us4Nm6tqFjcNuau14+uNou66jGKScnhDRILpDLzaPkxIXqYJbkXqwkbcR4HGbcWqb/8+3eApEm9QZfTyDdbLVmfv7imeG8+AVNy9hOuhICHnZG/618+5/R6YYP18JGHMiQQkVECHaphkPAAfgGPMS85G71BMZ6XeTEYHZw2COTj0P3zY6BN3IyvGualXkw2zcyD4EIkkKpVXfnuGdiA1qnFZh5/mjofN1WVvy/zU3UJXX7l5fzEyUCcayDsioLFNyKCYjSPjc2rRdRUThUHMMB2jrowDaCAfLDnGHFE53/2H+iL/8sgPnAWf+etDRIPQ0jfhyg6xgb1sXoVwXm05pSYCwkfPERaVsxDKQsifc80iPOO3LgN132QwIDuZs4nGNpekuuJVCZ7t8PU6CGSEMfwCbbvL1TT1aZxGkLY+UEujrjzOVGCKDnXQPEsAl+2KGR9IHB6jWd2VFu3/ryCFOkUkJSiqGdr75DByYStKyQp1VNF/RzEMIhkSmianVcFdfKSzxvBptarhmxpUYm+ZOMu+xCB4qMKvYfLKsjGt3FzqoLoIsgpTH7mPeOl+eI/QD7bbqz4lTTceFoMr2D7F7EARy+1Rzf/oNXt+fyFfAgE0D5bell1NF/3p5zT3hEwH7NAJzi0yWb5y0pLKGh6EviSFcMczKHuiqEARCZ9yT9Fd29ROISrfL6UHiwohid3HjPiFY7rLb5C9GE0x8vGyGVOBB91N5WKKIWXwyMOMXCLIp3865J+lfk+OSse47qIVirZB0tBAh3Ou8bOeutkQj31USEP4BLxzpfOJrK8MxFeQLrQmZnmLyJCYU9mtkz4exuY7SnRW/9FwO7lngaJTrZswsrrG3wnRF6KDP76Saicu1hgJEAv0VFKWlH/Iu+nkogbbXfGtMzgdpmWJcfmGq6PT+WTSQbGahXHwt3qwgD9IUtsXJw7uV6vDnlKDhcjh2JFPp1vf2wLH+alaTrLVT+ZSddQUaBCuKy15YKOvM7mvUxyRYUEizmQECJvF0lNPLOoNNDHItGUW+ZvToIWkCtyr2r+Hj7smxyErCLupWi0zTGN/L4wnca925umnp5aKWPLHIe9FeZnq16QNg4jaSs5wY4tMHF3KeXCFpeMd02ou6iZkzUG8lb3hfprZNjCFWnEn99QteQe9N98uhBj5d1BwjncZ5iPFBS9IPmUf15MQKZs+451IXGNgCrkEDemBbMdT1HuC7Wc8ADip/TO2KhenbcXFwOgksKgf6loYcj1c3HoHElEMaTtx4ppBg81iJvfxbfYS75+DSz5QugN69vBN0d6EjV2ShImigA4vL3tsi2sVSE9iyGJDuBsZtJAABAOIMjWr0DQTLfORtP/mQ7KkW8MSCYqoBjNLzoGxQKWLwCgPkrttDxRFgmZbF6ZlC695ZuuqHSPxjAqmcCtpgJFh6Ckp/L2ZfxuKzibHUl1dPeJpx2f6o6to3SMzEzW7dawK6864EChaWsAWntewqZJfZKqd7gkuB9mx0I7gg66VaWIPW+q2JHiCzNS4hkuEZpmTIKXWH3C2pFEy/NZ76h2lFm+FWJUC3q/VI/l25npU+AS/EHmgmDiAsQ5Uk1T1r34Pyv6CtM54dQ14ccoB+6BCSuGYzQI/A6Jo0vZC1yjLhPyk4dW56Irnx69O4Q2Iv+YF4/vsj1s941+rFtjF1vLX6mvp7/B9sw1k2GhYJRd3DdXmeuY2F4v+pUKMRfzK+t9HxXBETeuom2pJ2WqFJQRT065h/5YCg9ssMKEXc4W5ZLSxl6fvjRfoE5a7QtzrATfLvCAmni9Yv1akl9Zk1uE1vb+ApOER6ItvrA9zr7/uq725XksBrt6gTDkWKk1QuC4juRO9dQlN5CGaWrreqhn1ReSfgmZHr4/LIZyMHvVQ1Ympa07v47AA/oKPx97vfprg8H7Kb07CzwZijblDtyc0nvYe9WvPAAyXLaFOjVp1dKJ1seaEMfspXJbIWhiPDtdkxGJQ12kHC0nQrcWYx/42JuG5aX0c2HoUWfMok+imlaVGrDFLtsMc9ZmW9D19GqyTpwCVGcNdbm9BrOGossE2xSloSFhhjCI8Ps7ct/gXUhcMDBMTaGfEN8SDgBzpYd+67+8Eq5rCQk6p+B+Lgre8xcYxCOuyGiJJ2KvJ6W7Wi5xWis/QZPzp8dSppNzG5hadFYaLI8bn20LQ/dEEd23UzQzm7wAjPex6vxBKwTtKSXLkPWpKGLioa4Pcjs3brC5s8uIssrOyTvgtmKPYk4crzOj15jSWgM88uQcaFVHdvZLvTll3TTm2NzOQ6AxyM1dG8NudnsotBNaaCTqQ1IqqLRvvEllfs8S82loFRv0Xaepwvk39DClDBgFke0FwHZTJ/n3sIPrcEjtJI/aYG1FyhjtZAbjefo1mwASuD8JUdnWO6EQNVRW3aQJYVx7YjvYAa/zOT6TBXLGvJx4Ri2TqRTseEa/XLAMzlqafRnc6jx4zEXd1udAhZ7E2PFIgBIUlB9HDY6fFIsg/0hixoSuoOl5R9HM1ONFK6GTR5ifupFOFnlKb7F7njONoD4fuzdpiTolRn7o4SaaW1tXtsITvK1+7ouZECa/k+aWkZ4RAeeObuCDdoyP1bn+ZQo1rpeEwHnS0MXvP3UsL4lrGpIEhd9kyPcB9tysAwatZWQQlu0Vwf56+9mdAOM2zrDzyuTW7SrV//Gx0dWYAjSWW6CCKBXwD6WDn8ugHjNFHZTU9eztu9gPdX2jXW8B5MGxEAHO9JQQkfYjhK0Nq/S6YVazsdRlbXC0L+B55fuxEd9m501MHlCr0l4CEVt7uoe2Wv91RVtlRonwGObsre4qosx1GL3O/mNvpVi6YtrQZL8TicQ9RvOe9ENHMGkWinIdrbz/+gMLlbIuevqCdds7GWZshKQd+YNASFmgqpOeN+M7l0tVL3urPBmwMIfGMe0bQBjJ6mRWm3+codwoAktLvnN9ki468KUObIhQVlZuOfvp56t1ClyYiySepVS24yM63vL0J5u7bVTqucmuhUD7Bp1/tI+7fM6efNZrPOyIGZThfkpjD7SZtHyl5cWnVDyuW4XNX8GPPCgPoXNMOJo3uGo49tPstitafb//bjL9PSTSRUvuGtS4V/4nBJMLhul0We1Al0uEN3AiyvMNwDPA6CXjaEggfoltvM24xRttd2G3M0qaUPBRiCB7k1EminXCBHqGGcv6X524XCFylFQO4UGR8+rLaPLn2lt1zZCA4D0xusyeGZUDG9J87Ivl2lblHM/6OROwOBD+ikzH8UuYu84zZJVdKHp5zzG6llslVRs3gA3ytUav+yVGgZXS58zKDRQD+TheB4CF5jOscomvdDBusp/sTxa49BXxFQ/ny/olJ6hOGvNQij7/4ArDszsISytiMEV6mIqor22jevYbqcvIxngBvy/w5SLwwoL6YWfjn3/k3rtnFxxDordL57r1K/rrTOU/tbtdJ8j71/3Wu26VddWpkQxPC7bLDdvlyhZo6Rebc0IjZCHLtWWqprliHIroCZiRZHaHORPUCa/1aBXHcMlaN0IC09Ufn7tZlIDlUdyea32BNZ0JlVl+X/4wMGuqCcCCuazIyWSq1ZkmyVAOsJID54dlXpSbVIG4AqJfTF4nFzixf/EkrmikkmJrlbHiaCYbWX2csmXcQ+YNe+c3SjJ7/OH8+Pgq4nydgvXbRHEJKnhEW22FpkiMviTsp4jumSfvDS7t9p5Xqywvp9o9xCR6sV7U1bcaWRA3PRvoOgc7/Xb5d6+oNab9rm8anXEv9QMM2hjbOU/xOUceRVuHKlIHKU0FqofI7vNWVmBeytUz7krQZ+YHmdoV94cEhkm/vx8C2LpyLpOUSLnfa/6LWt0fH6b205uKEvAWXu2IIfV/bbK29vU2nzULrp+3UUDsXjqiHQCcwYHD+RdAVp1I5Ko1lQwkZ3Zr+XALwP7WLb+2iGMDAfBiJ1nvM7OrmrpCS3BEtuug7GOiMdJjxHEN8L7VFw5ULxj0TNTYdXJzjkCmZzYAXXrphpUzDSBH4F5/chkQCrLWA0HWd836O7eiQGapfv6kE3XYzbFVi9UBqMP9xkjfdh2k8idLHWwFvGHvF0iuzOgxphm3nKj8/bGH93yE1wgdjeQTH2uf3SxLoi4wRKkJUtBiMmBY+zbGTX1zLYHENIPZdtp0axcBSyz3BMnrbWOyrkFdUOv4kBoujIu72CipuJdWwqLsDw6KGbMgPJ7fwkZzHGRCexZ1PM4rzhLC4VFXPF95rYPisek7brdGZLvcAX4ilwKPrBxOLezkHeJA1SmC32cP+bPWcEw/9ISmfoC4ul4FfAsoBsaHbYxdESZg+rzsBxMmCnYXf94cM2f74TVH+iI9LaDB5doY/Ry5zTbaTocXnWXFIUHXusXvB9CFBEHOWnu8+aFnDSc81PwERvs2bi6QQEwSMB+zA7rr3rvV8sWoXd0McNAUii9IPeZcp1odR0m4OY/2D5axoi7FaSGETG8hIlRxlxACIwof4Ara8vWD150L4vhEfchkS1+kuAOHAoIPrbRPgon5i+dWBEOl/I5R2CW5cOaUetmpGqH4RKYL4tAQxUt4vW/jyVRhx5yCVWKUg+ka11HfCGDuhBQOslMLdu+goh9Db84sVBZgojBOuD+VwSvOmO9eoM1aNm8F9x6M05/SG/SJIcP7hjHw6KdLcUQuJ0Z/Fmr+pzFzSfqN6hfa7+PphkYbi0bky7Xhijrmlg8ZO+YQFtF3/HfT0oZVHN5AgD7gIJD/xC2VImntSn4FrVZAmwyFvwPgw45uMExDcTI+TvS00Ok47pdpaBq5xBcA+H+FukvGnQ7iEENjVBrRsGVKyjZ5umcYm+m+TggWduzNbd7TFeJoXHypTYjttAXVUW/pB+ey+ZTYuB+gKxSMfUd2G0uqogWryRRLmVwW27nvSLbMfkqBxUSJVh1K+f//cfFWeaY3JKLJy3nDYuGg5a/wM3ppT7UqLb2sLWwfDatvRB9hp5ZWTPzzfr+JPp6Nql+e3i/5V1eXHTAjdTrH0oPTu3DRmOn4suuxtweorTDFSxvVjtJFPpw+vaYxwvAtLPQXg9VhDC2fCAbwLJHRg/eRkjWX8f15PCxac1YYMOBGI9xyZlQJatO5bJce/zKBmd3g1iYeqGZYGi4FscuEYsh/zcUrKprBbp/DSxFctDKCGvWw4Nw+NK4g3kEiMohYzeq/i25pffnWstF6lNdzFlwRQQ4M2Vs56ZLVKs79blA4eFgmoJqESfCmRfs1VjtflrzV7ZWrftEEh2HNwOna4SC40dj2Gl9ExUPDRE5h1vr+iSLwdTTHHLPk3OD1kqGEW9OEKnqJusU1tCcTI7qKMbNnq4fr+4q4POp3M3rPkiNZKtt0hbPjnmCINQn1zuzXftFWvL9bYUvu2grCYv2ufCjVVyknLORi0rK+wd7ZPAGyns2xCxUkgQXjqGzWytA6x2qLT25lCbyISTqNBnySr+z3sRToetfyZgx0ABM/pj8+yHSVcGWU0e3Mt/KrL6V8OqkWBz61s7kZwswH/tsLEr8FbeoLgqMpw5DDJEciok1FcsrUTv/0zOpG6SzFTwKg+guyR2JWrocSW8ooBQNmGCpmJJZibkc2qTVeUKWSPTuH6+XAy4+24h6Pnl5gNrXIYVZuWo/RrW6ysfR72zUuCZMJL8czu4WW+pen4w1raTxXLG5ABBC6CQSC5twaqabfwGI0gVcM83MeNGgyNHntuuPgN2D7puv8gBNtaGvbLYgIYdbgPWqT4+SJE73gIVziIJzZtdDL2V4J8fb4vCbpYyT6hgZPsf/VO9f3Zm6gTquinvFjnOZuGmUQkEQVPxJWQHk9oe3j8W9hSg0Qn6uAgaRRTH4J8QwBcfrKOiaJtJiqZdMtsbP8+V3mvNieorKEbKOwggSKHBFy6VqWNPAv5ax+sadXOO9yvmhHT/uC+gwyjjx+5x8o/ejNomUnG3DV0pZiplyDmsh/xNugElKR8bNtI9PbvclYAVgiLUvuh1kyTSsd8Ijg3lfJhVhIIRr0yZILwr4FxxwhPNIWT11jTr9Hc6vZEz983Yx8H+c1rpRG04j0fC2DAqYs8InGLdJm7AljI6N/TGRGQOASRTBYxJUfw+5R9NnlBynYyeDODZ/APre66bie1jy0v5k5vO5YsfeZNv65VMeQQPEwaj5fRsD82nzB21/hb7UIdSC+bYhR6by7QyR2mW/arWKNqu6yIPdTkA4FWyT7R4xBtoiG9NsXpBtnpJKo3SMuY2FQ4pXow0cnN9Ahqub1a6CD84wr6VBGDPCy2zra+ra/nr9xOnELAwM6HgYCpbnD1Voz/aGNFP1FgjLm9tDVcWFMUSBXRDMfUMmBvOs205bfGcqyWgidGF7/Hw6DApM1Nhh2djMfSsLB1lKQ3vKJMKYX/MxgmiveWkPMfiEnBcI0am0j0JQvGrSMJz8gT9lo1w0bOVL0nEZeOAsshADVoqIn2TZqtgqDZGgcQG04AYrixy9+XGrlbIUeBNh/ru3JKW1I1W4XxZDP/X9OhsfFZTyK4bud4/LQbmO63XgS5qxtpjng8xchTCk946DeFBcGD9fZ+LjSw8tfk2x66N3Nqq2YsUuj/AdFlLyY5wWVXHb3oq3BVJTXnMxHp4n9Lmv+Fvdo42ucOKqex7y0BJAnsSf/upRk/GKgwdyoBWTal6KxZ06RRqCMEnvK5fvM9xwvdJMt77aSIvhWG5ckayTrJCVKDtJ9JrpIgxZjkbeyjvo2cpglmyP929lHr0LSykEa6NPPz5R+WYfAxKIdxeApc/hWpUTw6iBlY3I+wWOgG981TtuzFSr0kb4IoDKWSorn/sd5Zcw7z2FGA/iqYd9Qzbb9jjK/NJ2TOYo4uABwj0g2mscnLlS/zNI8foNW4NYSzOXUFZsYQhHoxb9AUcOViWiihPu8+Va6u3Fa//dyQKW+dA/5QCgd8izUW6TCQNJc8CX5ey79cL9jWeeHwELZ7YROwd6H6xcGHIJABL9yWcOHEUg3475Q8M7y70xcqBmbNLBwr6voGH1T06LthvL6rUaKMX6DROV5sUgy5iH4EDkUpvvDwxs41Es4J4ONVXxHI1Z6vtFxhpXWaB0WlOKUoUYDOWtzJU6+9qpAuAAW7Q42yTbJ5miLkki7MsyB/PHWIHyxuC1I7IjIr116nRU3keI8aEco21lDPbYN6Wr9qFC6HpNryonpKb4fa4MTOPUc1/VZMPwmM2OjZR6d2BWJbB8PLdLoIbi9F/4R6AWfZfBHTkF0dJjl0Keu/WHMb/gyjjv3xKWt8MkbRxg5A8UVXI8plMubbgNRID28gF1M1OQ/UNAc783Vqiecgsfg2ekkjG6Yf7Zqn2BrzZ6sy+zwpGpyaOoRinvRAwdaXfpjCItZReppQVwWLiB44TODXNMwP7o3NB7+2DqqaF8nmBh51ESMzUB+gwxahcQfd+egBSNoXqqp6G7r5+kXCB3VINDbnZZCPKTHic9p/09NFFt9R6wxCpgu9ArmelD1f0Y1CB1NrozxRY9Vh7+tttB927Dkb9u8lzZ4q2kbB94GohWs7BlGTh42xsjMHf9s79eRYcE4+LLut3Uwu5J62R0K0GXN5sFW8fp0fYPiGf3wh+owz8OckR6IG7fsQcUTnA9iuLLgQF/UylLsP2sQTW5mwjxT5HbwcskDoi0yb0CxXaXov/A0eCUAJ+3HMO6XK41/4V2mu/nsDqqjwxGnx6nNW9R96AtiUo20uW3XBpW8iJhSLzCy091GT6pHcIOYtfQ/9lY7lWJrMgZAdkdjknT+XBZ8htwlL7cCyZMY7VeljLO6BBUq5oBqlskF00kHffu4EWm15weGT8VnEHo7v63xB0cKmHKhywtETP0EyNatVBHbSeX742h2cOtoYw7sifEAPhMOfK8FFjOnXGZSfDgHwDUV//avBFwB38plvWuoXd32+rp1t3I04jsXDTbTOmdgi847EcnY4D8/44PXvw0qhWprnZYLCHfYStWdQcg7HXB2Vb/6nmarz1zi0IGr0KLMYCvuk14XfEB/DWe6Hfb4dB82wHWBhQpyklFQzDTZAbfh0xZ0VnDK3FD1jfqzShidH6V4XMA1gW/U2jvFXtWcvSF8oObHzal3UzcsEJFcT5zuajnX81j9kk1ipwf6W7gzeBzR/D7QMcYmqacM/yijDt1Pc6wYUybzbw82mgYtgw1CeAm98/CIHgI8x97Dkg5CLLcb3jx54/5bLkVQ/ybBSF1DqZK6kBqgN6CtkBDlZ7dLg21rFGiJ4JwD1HRKPzG8sVrRu2Uo6/wfjOdVbbXcpVCxmxkqYk7xSItTnwGzAH08GdGBQ7xDwvKCRtgL1U2vwKi0ccvk5bxFk5y4iN2RrRaUAHofwylGsm3fpXtblvzv7Uqyme8sJmmhbKSwiGR5XeHHzK4YiwnWgLqGKrdFD5saYpznCN3ehtZGNO28B2TFVR/UIzIpa/od9Wz1h9Sc6DlFTey3MrCk/MDjyAvaxXskHwMQWJDOuUQ10vqOeT5j7D9DYHDe+NwLaE4Hiay3tNFhREWtoSC56QxFWdIkc6ck1RD4f9KWF3EyHhWvqFXGZ6ZPPTucNyuRBhFYT+cKz1Ko4EBhoqJIAxk+zqcR7KKA4qcr/wMZIy6KRRkE9p+va6gDE07t4NAC4e0MUJioIPt433Lb+BiVYRgSFElyjB+1MFyJSv3qnkZWWOgNBooVBo65SMRSJMm9vcLY34fiN/Nh65+D2SJBynckTWpCkOTBQQBMt75GIgSO9o+hZtrAcesgGi8haHPxz16HsRb2UsMcIo4qbG39M/VMLA8DdhB+5WtSFAPWRAysaPCddt9S9Qeyz953Z0kafBSDk2RC2UoSrvpd2jcZncgHIeC22PVdj1N8iXfCmJBxgymSrHxgpX6M23E112FFd1Y12m1eYvTPzru7f4OQhiZUllX13t9PQlUvhrtF7AH2lLPz4XCiGds85peY2mhqo3qY2usQ3wFDPmuhmDZGTwKJ+u3tTtpeZDM5Sfx2PTfZIeDpJ0vD27gpRX353cCOIoUF58yStqt4+SC2x98HXKb3SgA4c+Zu2oHA8K+J7yzxJ66PrNLvZIVdRlaW2B4In056dDhdGtnUp0ZM7A4BIk51WKH1PYxSotL3wJfg9RZ59kSjlq2zW/ZsHF+JxuV86xoMJwFqvCV76jxwalKPM1NqyLEieUt+kCYM1S0/Nr9WnV4/LTNlrgJreiWlMw0rJ9xktNNeiPN+HOqVnvC3/uBhfbOuxVxgSHPMaHznIBUf21cAbHsm48e4bpeNnGHcvCOgzSsNcRZprPK66eTWPWByI19M2Bd3wJftbjyMmCtuqtiSTo72jcHDyR8NMSDHuASfdP6xPn4EkdymSk9aMuWgtdSie55YZmDZd42+PpgeE3CAn3n7nA9zaxA1UcuJl24N4EQneAn2Klw74Rr09dTjH8KQvPBhmHd60+vOYqHYbwKJKdDQ5c3CMQNNF/sAtFz6IHCKOdvy8rTjGSUe1y3UdudlCHzSk2MPXvXfWr+WuK+CCKGSXoUpjzGUPGSkL6eBWs/XZu+pfvNc2qXhsSEBzkQtzfCZuFD+1qCcJkqSDmuNtKZAcdthvHPkoFfHoKFCJScVcGfAcRpBJCaVThmp6o/VYJGZ1dZbnBxsY0GE3PnQ9Kt0/suVUeRwnm8i5OUC6yp2zAiUhr2tR75FTQxcENuX+mhrqHnJglK0Kga7+1V4xZ24D9GqxR+LtSPwaeoFAg1Lnu5ilvTfaT/SvzvvoAA/4K8WHvkw2+dqlvXGqdvhImKlPrDOiGpgmixdYYTLIvDcjF64VGmpC4MLpJkaGvn0+AIqX0RCKWyGMnW3gY6qWf/69cV1vILGkKIZ10pfeWCq0vbwQIe54KIj5JMG270fKOokLL09XLdWj6qVNlY2LUxieV3wAaGs+ZaggLCBv456jvO7elzzbmLSXz0E2Qwd0qPFXIF1fKYGQzM8mG6A8evM2gK+t2YBPhkyuLVi5e+Tx+tuvp3DL2+zmxOP4zKc441Cn4u6bwGFlEIzaEAsHC2s5Wz/mSZDSAhnYd7/1qV3wFhsMM0h1b1Dxnkg15UluBxbsNuOMT+VSBuXQrO6mnpp96fcLKB65/lBzBQpUQbOPRA96SJZmI5j7GMvIhnhqVQ4pSQrqXpRGUBhFX05qGm0fcY7K1+KfC6mhJb1qcjroDlKn3GkcO9GfO2Nut0aiKKyIzkgKeOEeUPprK5J4cj8gusw0Q7X7/QtQPqwIKztzVcnWiPX+rqjPBpIaVhaWGJca7nj/PPSV2usQSxo2B95qsxjkRiYesemsuRTY8SG7GBTBh1hUunKb39OTq7Kx/bEdGrNscGqvEaNr9gfvLRHsKhYw7ZEBwgjTY5M+Thovpdcs4dqDdpJOkbkABTWp6ci7xhwlwrgdKlml9DYLEDCn5ezajNcNVgyVz0FHMT4SFTJ4eQQlDzSZjc+DNY+RUc5dxqbJeNLmN+vrQktqRHMa/oC536KdqVSzbOABBIJe35xTHfZHhZH4jt5BA/MrNZ3HrnwO36+qtYpyRTWm1LL41Dca/17YPkZ/IRNYeiTxHpyJzf9t1YF5KUmFfaqwQ3BpRtzT5UD/56c1HnPGTXBgqv3TUPtOz09YP6WDrBEvZt2bAJ3U9PIvRKgSj9abDcKE8EJPaaJpXQZor96paBF+zkXsYvze/QfpywaNqDbIfzXOqB0nv1cpq66snSBEszTFHzTBGNDyi1+9Lcmq7ThJS3eVBdKJFUshs9hi7YU02xwdQAsPo+jEka1FZOxVCBBlZAysVD2xwSt0sAsBbg133GwDmj3VzQTT/Z5YvWp+knkcT0QN6KHF1X3GVeGK2jIXtMNSXX3APMwbbo83Q9pSK1c9qSto5hNIMfdU2VBc2vUVCMW8FMmiVtktqSBBoH6/ZAef6PTiwkJjKHa7D7TpWx8LD7tt9g7Ldy/jXuG7tSimIz26HzryKFVUy4FkUwGDszRMDsMLluT58JsFOf0jo20LyKZu2yecI9wInJV4a5Pd+Qd2q/6J8IpO3QUv/DPmvpEV0u4bjHb9ib677tlbJa8am7CXK8n9cvwUk2EsWBcTFKZiXUMmIQozC3G4sm4eAal4cNDKrZMN5ZuKyHBmsQXK6sdVUKrU2jE3icbO/rB6BnR31wAHPAStxFkQWto97tf2vK84He3FKoNTANIMaGfLU2D/6gqYI/y3LUNqvm0prnpO5GUbsUG85wP5yi/igKCXwTyuIRpJEw9SCOexNioQ1zBJZk8dWZpe2S3oCwWDLnBbf4zE1dzbLkPo60Yi/0DRJydkbysmsss9/uTBah0TiYctFpuHmc6nUJrpm3ots5SrzgUgrwUzttRtB5kuacypPoFljnLCjGZ0Cc3oEEkV3ewR/qzqxxhuvwA16x1Oh/N4R72hlnP2QUpnGato0JDg8KpmuFMkVauH+svoVfixTjb+R5CqZ0ORd8tBqLYRNIeTYUCnazMyAs2ubxwwJTBfydXZt5hbf8lJJBHAD2NcGrCdp4yy2FrbF3LQB6SSLrS84WShNxxLZwQ2oaoppk5h6pyfheMx1wkVqo/GuvqQ/RL3QVjyJKF8XxEiI41KRl3GX/a9nAcimF67QMu0jZD0kDiJGJkjZ78Y0WD/OtDM62TNaJqKUkV4T6e02DeXTqNu2g+On04D5DPBjC1nF7y1zHbdU5laXPi1o+JVNOH1iNRgZoiBXOtDUg/OPAYMeRIeuJ5rHrbOoSRDahsZNelW6ayEt1ic33/WSis14kPX7RyAhFe7fMIoJWn2kPtZLzfa7WX7Dq272sQ1JYAgy8U4eRzFqG4vGNIAAWVaT26g0oUyS8K1XxdhX79OIhNDosqAsJJ4/0Dffgfy25t+mtyalUA3STwzcffRAnOJ7NyNx+o2F1/dhDjANxU5Ye72SL/Q7o+UjON4UdmbE5/hf/RXSMeraRW5/vIuwvpujYdLjC0rZs8dwPgEvAoHKtk7pebrNW3wWyXrKy+QKpVMsO0IImQRkyYtD1oGEQlS1UHNUfidq0oH0eLEG8RLLVmYoP+QQb+eUF8CuIe4iR46ocg+1ZRcH1y+8wn4E4lo5y610FfDH+9RoJrVeZqlUukDRVQi2a/G+uXGUaqAVP00z0xXftMTzBQUxOFOTU9jfDU1xZtpp62taFdWF+zL0t2/UGNccd6TCq4pPC8BiDh6Tv5HKxmzEvyhkS1+kzT0GvoY3hvSwkOtAHjSvESpMwDVuiuXet56gCg2I07v0LynI6hGU6qQbW2+O8DtNRHi5ec6fQq01XqL2i7/8jj0gxmeZAa2tAPalWG9t+TyB1ppvG35bpizKOAIj7l9zHQTMk4v/vQegd61ILfDrsn6178XllcZTMFcPHTublGftAL6Aod8Je289WnKlYtx08HDm7hxZGXTLMgwZW6OFplsb90fo2OexwDasJmHMhDhf4IsMYKO7NHZrJLu+qjBoIayxSgPceQMWBhR/Md8KbTJh8Q4TkanDWTYAQJ1c7KtWvjspso0sejWiiVSgnviayrJSlIg3NwKbH6T2o9+5uz9nSHsQoQ4FHdeAGSCZx6FHgLg+3eCfnsnTi+qZloi6ISIn9DRgyUZrjoKV2pYDiN+ad9JDb9+k+G5p+W6SoSr2mmGe3ft9xF9b+Muk3wmqOXIlLWGVBMO+//YF1FZsItZtW/jm4+oTXBlS+U+aKN8GH//Zdg+wsQjEBeGbbFI6AG6UtGRf2qK7uA6tR61aL+FC9KoWmtV6yOUkQgOvUjt4Wrff2x1p1+VbbdtOGb1o/3iwtjqFMWiBLLEDJua5R9wF9Vpso30pYNYkPMkknEquuv64jhjzo3RHWfnTvGBwkDvj24ycLhNSU/JJhz8glFwxyv0ubt0DNHKwQ0vpskFARWQJIIzLZpNvZrtYWFJdb3krOsmTS2ES5sSICjcVGv+bZDFOKkaL/lCqVIdtqmYTZYd1EoGsbbJQlyqj9nbUKGjdDNk5J+nluRI1epPe6hRAgU6ykVP9jZCDYBKh9cZ/FK42k1IhANCHsBhAheWKLwNqcjXwrDplRDe3uJ0ekwggi1wSKhjtRqi78ezCEc95uJacqxzeNbRaHyVWeJOXv1ANQVameqYTwpjUY77l2nmKLFEYlQcai7ZcshKeI1Z+9GUE1eYlTlFjSJbWTS1QPUVszWtlQegjeylgdiEAf73hejCV+Ucck3pD9suY9cTxkQ+Fx09abJhZziEMS/eW8f+FOaJCIKpTnaw3IUyO0V12h3hJ6lJpDi8cEL6gCbPPr/+cdGQ0GJiuDW0Nf91HX/s2RrI22YpWM+6b4pPO/Qh18Mt1BtFknp9hPfWGW+QjJ41a7TnZa6zjbXVmOmunMp1I7DdfhIChfYTmQjySXacGLzo5IeDNaSSBN+2tA6U8a6gE9tzUaWID5Gc6sabSIHcAF2oLOjhxrPE30DSF0zTR/O1wCJFVAa/XTgYdKdfglwuE70H5ppaq0oFWUJ6GAC21F/GFzaf8DBMHRcpcRGZnzZhH5QuRa5k+atmdnGs4VMBVifofL69iVnsh3h3LCPuYn1HXWUihE7cgwV0yCvZlu6QlfkxJu1qKoFzpowK/ZgdQahPtM2QlKSyRbc6jm6cumZH9otAO6x8O8SkZ5nuHrTzGBub2gs4fuqEBNtKtVEnFyntctm36LYBYJ98UOSrDQ9m/s3/sVJSpHr7vpdIjQP6XZIs0YQwLKZX5HF9WOZGwXly8FmMCPK89vwD9BPdrkLsPR7AMzmTUBlF0wxMdXkCESaftBWXGL+kIuH2RgVR0E8HDwQvGRSuYCdwIWbhP+FflSlf6VJKzDHdzSwa4PZpoW3q8F3RlRwYYA/K/4TRHIwow1a+fPk+o99/msi1LrhbleYAjT+Yba0oFatUtAhcW2OG2IHIqqr5sme9qaa+klKOxRcGQMhTfaQKYqvtRejTB+7uRgNPwjgZ2buq3t3+NTFByiqpL2ieaoAgmZrlCA3+A5NSkeLidh9wqJX3uLCnocnhPuzSmPzmOBYz+Y8kNF1gRxef4n5fi4L1ubXy2XKU8ff2XaHSU5wSYgeJOmEGWsikjOXekY0WlLwdMP+1FtDT+ECi94V1ewajKMO9070LPzEKImrueAl/uNKcE7gz/bCNmZ+UqcFmoa98CROjF952xWiymaJz5gCrv4TpyRN0dFO1iXUmPHsdDJZ/GdQHsDLbKOo2d7CW5aOqkxJy2A7FKDnTy5oxACoOf2pKA7Ek4PfZhX3qUPm3UYG6xONTmVxFeohjfWpFKZbB0KxZLTsSK81qP+hjNxUab3gR1MPatK2LLVhepvo3diHE6OAu4AOILHdtbgqt0ACaFTcnYhfe8YllssT1LjExWwbq5+JXiGkM8NHoFbrdqMSB6v+PDTy8Jiwr+KIAqspn4dyiTap9PPGTEXFEbz2mWsX/9ioCnZzAGGCaWhXTv/sGTdtswcURsnR+ZJQOCjxk1NOtxmMIp55ty+CT+2LKPsmMTsyWVfB5ntf0YDaN/x+4QMhiTNGtm10zgTV3PGjn5Val+xLSC1PQKicaTO4L96oYH0yvxwOBVaA6hLEBV7HtsMng5oVY6PlcQbh1McZi1C0V/KWhe/xeCn8dhLNKDKe5t3lBfZKuDj5BDqnHi7yPs+hKIyktJ9SfOhzXi5hWKbZBndFfpu+l6sdCxRzxeSnF36AFH6y8CxLVXfqi5ComSMxVwo01ROrhBYihoOnnb5SdbZTCMPmNbXyE/v/iH3jNGmlevJl4Btd4ZCAmBHyix2nc+EZtw9bXF+UcX0wFqghc8I+IZb90fQy+vvplc/QXmxECXlDikB19d2tLuHQmMTMTAOzKg9N2mAB4husflwWtQ8SHhiOrsO4S6n1/qJwcu+ukfeMUxSaLgYxDqO0slJWcl6G3LRcd8p55+Nptq5tHbD/gO8uAYGRHmL8WEfPRacOXGtqt4SJIQBfEeZQWoc8P4HSa7dmxJe0q+U6VsjWMzVB4GRZ7riGf7zt+0MiYlerjG5Btj3wtsV5ndOptCS/A+Jd3WfcGDbmp+T0WVFgtJZXd3n6kyjoruujz7O5/A9RnCih47ymV6GzmE0oUb0rdr3v7J+86WV9P7rxLFoA6bfd9VLMkSCpmuDJbq5uOc4s3GIOi39lW9UYdtfC4vHRGIpUhpvobeZjfBVjY+3RuZyOKICj1Q7zwjtryX8qvkwlJ9NU5jTzxyfM4iTsrkWmzvmtTbH9zOD0RM+QDYWOzDywP4b5NO+WgtiHosTpRfUjX8D+JhKLiTZY0T7y3aBJq19xo90Qvb2zQ90fHo6lZlttHpUvuDc6rxpSen/ggyk/XLnfd1nxcT/PxCP+UXWzwynl/kyqUA7X66WadQWST/6q0l9DzD4eJdH8BWBD/CtE+0yQtqbOco5kutZb7YQ3tkxuzWTeo5ZHgdx5f/CKH4b5AbYacTuC+BeDrXjHJK6VoxZVUgrrmfodCFkMZB407sMnXrVQ5ZkrD4wzdsI67xJ/DgVYrDSqtgguBIlyhIhmvVw1aYTDZMfUjQWlm2a9Q6RYHDJISYn7fH+zmbpe1v8xT/0tItMOFroiEyW/pftCg4rmKYCuYtGqeZKrEZHfXF1eC9w3Kc9U22vkIwgNR7ztp6Im9pRotuGfyf0haoOTE+pdhpRUuFaRGCfvIQ0ID72XmeehIpQScg85frPMrMG3x3CQ1azZg4cX6UHlT3rOcLnvvWM0wyDsCBEg7YKsxADr4fPajf71j5ReNN7l+RYCXrAWTypZervxfGGgUzqmL9/MlsOEW9/Cf5Qck+ka9nyWEj2p7X5gEpjrDKfilWEd+4hujYZAGHhJUPp+j7AioSPgx9lTX2I+syR3N/KVCGbRJ1AX1zO/jDrCNm+XwIZuMxxSzHKh+TRW6ZPzww2V6McAVRoAKv5xWDjc6+UbpOyS8mVEwA1G93HqFL8gDzreJVmyW85jN8v8JGgSOKCZUcnUM9jsHrvDu7Pw27Cw77xTvJ4zN75eXnUG+A6LSzO9v5XfZeoVJdm1kAEI9fgOH7uBdX8k22xzRlgNRvSHcY5O4W2aDFyn0xWb7gtMGETwfK1845DHfS8eO9RWK0TxlaRRhsuBH4pf2l+vBKoW+HH2YQQ8tgLZgEtxMRH41rqQryBCQBY/UAQpswdCyQDw1MbnAAA='

    /* ------------------------------------------------------------------
     * 色板与文案
     * ------------------------------------------------------------------ */

    const WALLPAPERS = {
      ocean: { label: '海盐蓝', base: '#cfe6f7', deep: '#b9d9ee', ink: '#6f93ad', trim: '#eef7fd' },
      mint: { label: '薄荷', base: '#d9f0e4', deep: '#c3e4d3', ink: '#7aa58d', trim: '#f2fbf6' },
      peach: { label: '蜜桃', base: '#fbe3d6', deep: '#f3cfbd', ink: '#b98a72', trim: '#fff6f1' },
      lavender: { label: '薰衣草', base: '#e6dff5', deep: '#d5c9ed', ink: '#8f7fb5', trim: '#f8f5ff' },
      cream: { label: '奶油', base: '#f7ecd9', deep: '#eeddc2', ink: '#b39b76', trim: '#fffaf0' },
      night: { label: '深海夜', base: '#33455f', deep: '#2a3a52', ink: '#93a9c6', trim: '#4a5f7d' },
    }
    const FLOORS = {
      oak: { label: '原木', base: '#d9b98c', dark: '#c9a878', line: '#b9975f' },
      walnut: { label: '胡桃', base: '#a9784f', dark: '#96673f', line: '#7d5432' },
      tile: { label: '瓷砖', base: '#e8eef0', dark: '#dbe4e7', line: '#c6d3d7' },
      carpet: { label: '地毯', base: '#c9d9e8', dark: '#bccfe0', line: '#a9c0d4' },
      stone: { label: '石板', base: '#b9c1c5', dark: '#aab3b8', line: '#8f9aa0' },
    }
    const BEDDINGS = {
      blue: { label: '海蓝', base: '#8fc4ea', deep: '#6aa9d8', pale: '#dceefb' },
      pink: { label: '珊瑚粉', base: '#f4b8c4', deep: '#e79aa9', pale: '#fde8ed' },
      cream: { label: '奶油', base: '#f3e3c3', deep: '#e6d0a5', pale: '#fbf4e4' },
      mint: { label: '薄荷', base: '#a9ddc7', deep: '#87cbb0', pale: '#e3f6ee' },
      night: { label: '深海夜', base: '#4a6488', deep: '#3b5273', pale: '#b9c9e0' },
    }
    const KITCHENS = {
      mint: { label: '薄荷绿', base: '#bfe3d4', deep: '#9ccdb8' },
      cream: { label: '奶油白', base: '#f2ead8', deep: '#ddcfb4' },
      wood: { label: '原木', base: '#d3ac7d', deep: '#b98d5d' },
      blue: { label: '雾蓝', base: '#b9cfe2', deep: '#93b2cd' },
    }
    const CURTAINS = {
      sheer: { label: '纱帘', base: '#f6fafc', deep: '#e3edf5' },
      blue: { label: '海蓝', base: '#a9cbe6', deep: '#8db4d4' },
      cream: { label: '奶油', base: '#f6ecd7', deep: '#e6d6b8' },
      stripe: { label: '条纹', base: '#f2f6f9', deep: '#b9cee0' },
    }
    const EXTRAS = [
      ['plant', '盆栽'],
      ['rug', '地毯'],
      ['shelf', '书架'],
      ['art', '挂画'],
      ['catbed', '猫窝'],
    ]
    const RECIPES = ['虾粥', '炸鸡', '番茄蛋汤', '海苔饭团']
    const MAID = { dress: '#2f3f66', panel: '#26345a', apron: '#f8fbff', trim: '#ffffff', shoe: '#1f2b47' }
    const VIEW_OPTIONS = [['sea', '海'], ['forest', '森林'], ['stars', '星空'], ['city', '城市'], ['snow', '雪'], ['garden', '花园']]
    const GRID_W = 8
    const GRID_H = 6
    const CELL = 76
    const LAYOUT_SPECS = {
      bed: { w: 2, d: 3, label: '床', color: '#8fc4ea' },
      table: { w: 2, d: 2, label: '桌子', color: '#c99a66' },
      stove: { w: 2, d: 1, label: '灶台', color: '#9aa7b5' },
      fridge: { w: 1, d: 1, label: '冰箱', color: '#cfe0e6' },
      shelf: { w: 1, d: 1, label: '书架', color: '#b98a5e' },
      plant: { w: 1, d: 1, label: '盆栽', color: '#6cc3a3' },
      lamp: { w: 1, d: 1, label: '落地灯', color: '#e8c98a' },
      rug: { w: 3, d: 3, label: '地毯', color: '#e8d9c0' },
      catbed: { w: 1, d: 1, label: '猫窝', color: '#f3b8c4' },
      shower: { w: 1, d: 1, label: '浴室', color: '#a9d8ec' },
    }

    function defaultLayout() {
      return {
        bed: { x: 0, y: 0 },
        lamp: { x: 2, y: 0 },
        plant: { x: 5, y: 0 },
        stove: { x: 6, y: 0 },
        fridge: { x: 7, y: 2 },
        shelf: { x: 6, y: 2 },
        table: { x: 3, y: 2 },
        rug: { x: 2, y: 2 },
        catbed: { x: 7, y: 5 },
        shower: { x: 0, y: 5 },
      }
    }

    function normalizeLayout(raw) {
      const layout = defaultLayout()
      if (!raw || typeof raw !== 'object') return layout
      for (const [kind, spec] of Object.entries(LAYOUT_SPECS)) {
        const item = raw[kind]
        if (!item || typeof item !== 'object') continue
        const x = Math.round(Number(item.x))
        const y = Math.round(Number(item.y))
        if (!Number.isFinite(x) || !Number.isFinite(y)) continue
        if (x < 0 || y < 0 || x + spec.w > GRID_W || y + spec.d > GRID_H) continue
        layout[kind] = { x, y }
      }
      return layout
    }

    function canPlace(layout, kind, x, y, extras = {}) {
      const spec = LAYOUT_SPECS[kind]
      if (!spec) return false
      if (x < 0 || y < 0 || x + spec.w > GRID_W || y + spec.d > GRID_H) return false
      if (kind === 'rug') return true
      const hidden = new Set()
      if (!extras.shelf) hidden.add('shelf')
      if (!extras.plant) hidden.add('plant')
      if (!extras.catbed) hidden.add('catbed')
      for (const [other, pos] of Object.entries(layout)) {
        if (other === kind || other === 'rug' || !pos || hidden.has(other)) continue
        const os = LAYOUT_SPECS[other]
        if (!os) continue
        if (x < pos.x + os.w && x + spec.w > pos.x && y < pos.y + os.d && y + spec.d > pos.y) return false
      }
      return true
    }

    function residentOf(house) {
      const resident = house && house.resident ? house.resident : {}
      return {
        name: typeof resident.name === 'string' && resident.name.trim() ? resident.name.trim() : '蛋蛋',
        theme: RESIDENT_THEMES[resident.theme] ? resident.theme : 'blue',
      }
    }
    const RESIDENT_THEMES = {
      blue: {
        label: '海蓝', hair: '#6fb7ee', hairDeep: '#5aa9e6', hairLight: '#8fd0f4',
        tail: '#6fb7ee', tailStroke: '#4a8fc7', dress: '#eaf5fd', dressPanel: '#a9d3f0',
        dressTrim: '#5b9bd5', shoe: '#3f6fa0',
      },
      pink: {
        label: '珊瑚粉', hair: '#f2a9c4', hairDeep: '#e88aae', hairLight: '#f8c6d8',
        tail: '#f2a9c4', tailStroke: '#d97a9e', dress: '#fdf0f5', dressPanel: '#f6c2d4',
        dressTrim: '#d97a9e', shoe: '#b96a86',
      },
      mint: {
        label: '薄荷', hair: '#8fd6c0', hairDeep: '#6cc3a3', hairLight: '#b6e8d8',
        tail: '#8fd6c0', tailStroke: '#5f9f8a', dress: '#effaf5', dressPanel: '#b9e8d6',
        dressTrim: '#5f9f8a', shoe: '#4f8a76',
      },
      lavender: {
        label: '薰衣草', hair: '#b9a7e0', hairDeep: '#9f8cd0', hairLight: '#d5c9ed',
        tail: '#b9a7e0', tailStroke: '#8f7fb5', dress: '#f5f1fd', dressPanel: '#d5c9ed',
        dressTrim: '#8f7fb5', shoe: '#7a6aa0',
      },
    }
    const ACTIVITY_TEXT = {
      idle: '发呆',
      sleeping: '睡觉',
      cooking: '做饭',
      eating: '吃饭',
      showering: '洗澡',
      reading: '看书',
      looking: '看海',
      watering: '浇花',
    }
    const POSE = {
      idle: 'stand',
      sleeping: 'sleep',
      cooking: 'cook',
      eating: 'eat',
      showering: 'shower',
      reading: 'read',
      looking: 'look',
      watering: 'water',
    }

    /* ------------------------------------------------------------------
     * 本地兜底引擎：host 连不上时，照样能玩
     * ------------------------------------------------------------------ */

    const clamp = (value, min = 0, max = 100) => Math.min(max, Math.max(min, value))
    const round2 = (value) => Math.round(value * 100) / 100
    const clone = (value) => JSON.parse(JSON.stringify(value))

    function defaultState() {
      return {
        version: 3,
        house: {
          name: '鲸鱼小屋',
          wallpaper: 'ocean',
          floor: 'oak',
          bedding: 'blue',
          kitchen: 'mint',
          curtain: 'sheer',
          extras: { plant: true, rug: true, shelf: true, art: true, catbed: false },
          resident: { name: '蛋蛋', theme: 'blue' },
          layout: defaultLayout(),
          view: 'sea',
          vision: '',
          generated: false,
          builtAt: 0,
          updatedAt: 0,
        },
        life: {
          day: 1,
          clock: 8,
          energy: 66,
          hunger: 40,
          mood: 72,
          hygiene: 80,
          activity: 'idle',
          activityUntil: 0,
          sleepHours: 0,
          pendingMeal: null,
          meal: null,
          pantry: ['虾', '米', '鸡蛋', '青菜', '海苔'],
          position: { x: 52 },
          facing: 1,
          lastTick: Date.now(),
          diary: [{ at: '第1天 08:00', text: '搬进鲸鱼小屋。海风从窗缝里钻进来，尾巴有点想拍地板。' }],
        },
      }
    }

    function mergeState(raw) {
      const base = defaultState()
      if (!raw || typeof raw !== 'object') return base
      const house = raw.house && typeof raw.house === 'object' ? raw.house : {}
      const life = raw.life && typeof raw.life === 'object' ? raw.life : {}
      const extras = house.extras && typeof house.extras === 'object' ? house.extras : {}
      const resident = house.resident && typeof house.resident === 'object' ? house.resident : {}
      const position = life.position && typeof life.position === 'object' ? life.position : {}
      return {
        ...base,
        ...raw,
        version: base.version,
        house: {
          ...base.house,
          ...house,
          extras: { ...base.house.extras, ...extras },
          resident: {
            name: typeof resident.name === 'string' && resident.name.trim()
              ? resident.name.trim().slice(0, 12)
              : base.house.resident.name,
            theme: RESIDENT_THEMES[resident.theme] ? resident.theme : base.house.resident.theme,
          },
          layout: normalizeLayout(Number(raw.version) >= 3 ? house.layout : null),
          view: ['sea', 'forest', 'stars', 'city', 'snow', 'garden'].includes(house.view) ? house.view : base.house.view,
          vision: typeof house.vision === 'string' ? house.vision.slice(0, 300) : '',
          generated: typeof house.generated === 'boolean' ? house.generated : true,
          builtAt: Number(house.builtAt) || 0,
          name: typeof house.name === 'string' && house.name.trim() ? house.name.trim().slice(0, 16) : base.house.name,
        },
        life: {
          ...base.life,
          ...life,
          position: { x: clamp(Number(position.x) || 52, 6, 94) },
          diary: Array.isArray(life.diary)
            ? life.diary.filter((entry) => entry && typeof entry.text === 'string').slice(-60)
            : base.life.diary,
        },
      }
    }

    function clockLabel(life) {
      const total = Math.round(life.clock * 60) % (24 * 60)
      const hh = String(Math.floor(total / 60)).padStart(2, '0')
      const mm = String(total % 60).padStart(2, '0')
      return `第${life.day}天 ${hh}:${mm}`
    }

    function addDiary(life, text) {
      life.diary.push({ at: clockLabel(life), text: String(text).slice(0, 120) })
      if (life.diary.length > 60) life.diary.splice(0, life.diary.length - 60)
    }

    function advanceClock(life, hours) {
      let clock = life.clock + hours
      while (clock >= 24) {
        clock -= 24
        life.day += 1
      }
      while (clock < 0) {
        clock += 24
        if (life.day > 1) life.day -= 1
      }
      life.clock = clock
    }

    function finishSleepLocal(state) {
      const life = state.life
      const hours = Math.max(1, Number(life.sleepHours) || 2)
      advanceClock(life, hours)
      life.energy = round2(clamp(life.energy + 20 * hours))
      life.hunger = round2(clamp(life.hunger - 3.6 * hours))
      life.mood = round2(clamp(life.mood + 2.6 * hours))
      life.hygiene = round2(clamp(life.hygiene - 1.2 * hours))
      life.activity = 'idle'
      life.activityUntil = 0
      life.sleepHours = 0
      addDiary(life, hours >= 6 ? '睡饱了，伸了个懒腰，尾巴差点扫到床头柜。' : '小睡了一会儿，眼睛亮了一点。')
    }

    function finishActivityLocal(state) {
      const life = state.life
      const activity = life.activity
      if (activity === 'cooking') {
        life.meal = life.pendingMeal || '虾粥'
        life.pendingMeal = null
        addDiary(life, `锅里的${life.meal}出锅了，热气把窗玻璃糊了一小片。`)
      } else if (activity === 'eating') {
        const meal = life.meal || '饭'
        life.meal = null
        life.hunger = round2(clamp(life.hunger + 42))
        life.mood = round2(clamp(life.mood + 7))
        addDiary(life, `把${meal}吃干净了。胃里暖，尾巴尖也跟着晃。`)
      } else if (activity === 'showering') {
        life.hygiene = 100
        life.mood = round2(clamp(life.mood + 5))
        addDiary(life, '热水冲下来，鳞片和头发都亮了一个度。')
      } else if (activity === 'reading') {
        life.mood = round2(clamp(life.mood + 9))
        life.energy = round2(clamp(life.energy - 4))
        addDiary(life, '翻完一章讲深海发光的书，记了两行。')
      } else if (activity === 'looking') {
        life.mood = round2(clamp(life.mood + 5))
        addDiary(life, '趴在窗边看了一会儿海，风把窗帘吹起来。')
      } else if (activity === 'watering') {
        life.mood = round2(clamp(life.mood + 3))
        addDiary(life, '给盆栽浇了水，叶子亮了一点。')
      }
      life.activity = 'idle'
      life.activityUntil = 0
    }

    function tickLocal(state, now = Date.now()) {
      const life = state.life
      const last = Number(life.lastTick) || now
      const realHours = Math.max(0, Math.min(now - last, 6 * 60 * 60 * 1000)) / 3_600_000
      life.lastTick = now
      const hours = realHours * 6
      const sleeping = life.activity === 'sleeping'
      if (hours > 0) {
        advanceClock(life, hours)
        if (sleeping) {
          life.energy += 20 * hours
          life.hunger -= 3.6 * hours
          life.mood += 2.6 * hours
          life.hygiene -= 1.2 * hours
        } else {
          life.energy -= 1.3 * hours
          life.hunger -= 3.3 * hours
          life.mood -= 0.7 * hours
          life.hygiene -= 1.0 * hours
          if (life.hunger < 15) life.mood -= 1.5 * hours
          if (life.energy < 15) life.mood -= 1.2 * hours
        }
        life.energy = round2(clamp(life.energy))
        life.hunger = round2(clamp(life.hunger))
        life.mood = round2(clamp(life.mood))
        life.hygiene = round2(clamp(life.hygiene))
      }
      if (life.activity === 'sleeping') {
        if (now >= Number(life.activityUntil || 0)) finishSleepLocal(state)
      } else if (life.activity !== 'idle') {
        if (now >= Number(life.activityUntil || 0)) finishActivityLocal(state)
      }
      return state
    }

    function applyLocal(state, action, args = {}) {
      tickLocal(state)
      const life = state.life
      const now = Date.now()
      const house = state.house

      if (action === 'status') return `小屋状态：${statusText(state)}`

      if (action === 'time') {
        const clock = Number(args.clock)
        if (!Number.isFinite(clock) || clock < 0 || clock > 24) throw new Error('时间要在 0~24 点之间。')
        life.clock = clock % 24
        state.updatedAt = now
        return `把时间拨到了 ${String(Math.floor(life.clock)).padStart(2, '0')}:00。`
      }

      if (action === 'design') {
        let changed = 0
        if (typeof args.name === 'string' && args.name.trim() && args.name.trim().slice(0, 16) !== house.name) {
          house.name = args.name.trim().slice(0, 16)
          changed += 1
        }
        for (const [field, palette] of [
          ['wallpaper', WALLPAPERS], ['floor', FLOORS], ['bedding', BEDDINGS],
          ['kitchen', KITCHENS], ['curtain', CURTAINS],
        ]) {
          if (typeof args[field] === 'string' && palette[args[field]] && house[field] !== args[field]) {
            house[field] = args[field]
            changed += 1
          }
        }
        const extras = args.extras && typeof args.extras === 'object' ? args.extras : {}
        for (const [key] of EXTRAS) {
          if (typeof extras[key] === 'boolean' && house.extras[key] !== extras[key]) {
            house.extras[key] = extras[key]
            changed += 1
          }
        }
        const resident = args.resident && typeof args.resident === 'object' ? args.resident : null
        if (resident) {
          const name = typeof resident.name === 'string' ? resident.name.trim().slice(0, 12) : ''
          if (name && name !== house.resident.name) {
            house.resident.name = name
            changed += 1
          }
          if (RESIDENT_THEMES[resident.theme] && resident.theme !== house.resident.theme) {
            house.resident.theme = resident.theme
            changed += 1
          }
        }
        if (args.layout && typeof args.layout === 'object' && Object.keys(args.layout).length > 0) {
          const next = { ...(house.layout || defaultLayout()) }
          for (const [kind, item] of Object.entries(args.layout)) {
            const spec = LAYOUT_SPECS[kind]
            if (!spec || !item) continue
            const x = Math.round(Number(item.x))
            const y = Math.round(Number(item.y))
            if (!Number.isFinite(x) || !Number.isFinite(y)) throw new Error('这个位置看不明白。')
            if (!canPlace(next, kind, x, y, house.extras)) throw new Error('这里放不下，换一格。')
            if (next[kind]?.x !== x || next[kind]?.y !== y) {
              next[kind] = { x, y }
              changed += 1
            }
          }
          house.layout = next
        }
        if (changed > 0) {
          house.updatedAt = now
          addDiary(life, changed > 1 ? '把屋子重新布置了一遍，顺眼多了。' : '换了一样东西，屋子像新的一样。')
        }
        return changed > 0 ? '小屋重新布置好了。' : '小屋还是原来的样子。'
      }

      if (action === 'note') {
        const text = typeof args.text === 'string' ? args.text.trim() : ''
        if (!text) throw new Error('要写点什么呀，日记不能是空的。')
        addDiary(life, text)
        return '记进小屋日记了。'
      }

      if (action === 'move') {
        const x = clamp(Number(args.x) || life.position.x, 6, 94)
        life.facing = x < life.position.x ? -1 : 1
        life.position = { x: round2(x) }
        return '在屋里走了两步。'
      }

      if (action === 'wake') {
        if (life.activity !== 'sleeping') return '她本来就醒着。'
        life.activity = 'idle'
        life.activityUntil = 0
        life.sleepHours = 0
        addDiary(life, '被叫醒了，眯着眼坐起来，头发翘着一撮。')
        return '把她叫醒了，头发还翘着。'
      }

      if (life.activity === 'sleeping') throw new Error('她还在睡呢，先叫醒她吧。')

      if (action === 'sleep') {
        const evening = life.clock >= 20 || life.clock < 5
        const hours = evening ? 8 : 2
        life.activity = 'sleeping'
        life.activityUntil = now + 7000
        life.sleepHours = hours
        life.position = { x: 18 }
        addDiary(life, evening ? '把自己埋进被子，尾巴也收好了，晚安。' : '有点困，先躺一会儿。')
        return `${evening ? '钻进被窝，睡一晚上' : '躺下小睡一会儿'}。${hours} 小时（现实约 7 秒）后自己醒。`
      }
      if (action === 'cook') {
        if (life.meal) throw new Error(`桌上还有${life.meal}，先吃完再开火吧。`)
        const recipe = RECIPES.includes(args.recipe) ? args.recipe : '虾粥'
        life.activity = 'cooking'
        life.activityUntil = now + 4500
        life.pendingMeal = recipe
        life.position = { x: 82 }
        addDiary(life, `系上围裙，开始煮${recipe}。`)
        return `开火煮${recipe}，锅里很快就咕嘟了。`
      }
      if (action === 'eat') {
        if (!life.meal) throw new Error('锅里还空着，先做点吃的。')
        life.activity = 'eating'
        life.activityUntil = now + 5000
        life.position = { x: 52 }
        addDiary(life, `在餐桌前坐下，开始吃${life.meal}。`)
        return `坐下吃${life.meal}。`
      }
      if (action === 'shower') {
        life.activity = 'showering'
        life.activityUntil = now + 6000
        life.position = { x: 15 }
        addDiary(life, '去冲了个热水澡，水声哗啦哗啦。')
        return '去洗澡了，水声哗啦哗啦的。'
      }
      if (action === 'read') {
        life.activity = 'reading'
        life.activityUntil = now + 4000
        life.position = { x: 68 }
        addDiary(life, '从书架上抽了一本讲深海的旧书。')
        return '窝到书架边上看书。'
      }
      if (action === 'look') {
        life.activity = 'looking'
        life.activityUntil = now + 3000
        life.position = { x: 78 }
        addDiary(life, '趴到窗边看海，外面有船灯的影子。')
        return '趴到窗边看海。'
      }
      if (action === 'water') {
        if (!house.extras.plant) throw new Error('屋里没有盆栽，先布置一盆吧。')
        life.activity = 'watering'
        life.activityUntil = now + 3000
        life.position = { x: 64 }
        addDiary(life, '拎着小水壶给盆栽浇水。')
        return '给盆栽浇水。'
      }
      throw new Error(`不认识的动作：${action}`)
    }

    function statusText(state) {
      const life = state.life
      const activity = ACTIVITY_TEXT[life.activity] || '发呆'
      return `${clockLabel(life)} · 正在${activity} · 精力${Math.round(life.energy)} 饱腹${Math.round(life.hunger)} 心情${Math.round(life.mood)} 洁净${Math.round(life.hygiene)}`
    }

    /* ------------------------------------------------------------------
     * 状态仓库 + host 同步
     * ------------------------------------------------------------------ */

    function createStore() {
      let snapshot = {
        status: 'loading',
        state: null,
        local: false,
        busy: '',
        notice: null,
        noticeAt: 0,
      }
      const listeners = new Set()
      return {
        get: () => snapshot,
        subscribe(listener) {
          listeners.add(listener)
          return () => listeners.delete(listener)
        },
        patch(patch) {
          snapshot = { ...snapshot, ...patch }
          for (const listener of [...listeners]) listener()
        },
      }
    }

    const store = createStore()
    let fetching = false
    let started = false
    let intervalId = 0
    let localState = null

    function apiUrl(path) {
      if (typeof location !== 'undefined' && /^https?:$/.test(location.protocol)) {
        return location.origin + API + path
      }
      return API + path
    }

    async function fetchHostState() {
      const response = await fetch(apiUrl('/state'), { credentials: 'same-origin', cache: 'no-store' })
      if (!response.ok) throw Object.assign(new Error(`小屋接口返回 ${response.status}`), { http: true })
      const data = await response.json().catch(() => null)
      if (!data || data.ok !== true || !data.state) {
        throw Object.assign(new Error(data?.error?.message || '小屋接口返回不合法'), { http: true })
      }
      return data.state
    }

    async function postHostAction(action, payload) {
      const response = await fetch(apiUrl('/action'), {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ action, ...payload }),
      })
      const data = await response.json().catch(() => null)
      if (!response.ok || !data || data.ok !== true) {
        throw Object.assign(new Error(data?.error?.message || `小屋接口返回 ${response.status}`), { http: true })
      }
      return data
    }

    function readLocal() {
      try {
        const raw = window.localStorage.getItem(LOCAL_KEY)
        if (raw) {
          localState = mergeState(JSON.parse(raw))
          return localState
        }
      } catch { /* localStorage 不可用就用默认屋 */ }
      localState = defaultState()
      return localState
    }

    function writeLocal(state) {
      localState = state
      try {
        window.localStorage.setItem(LOCAL_KEY, JSON.stringify(state))
      } catch { /* 隐身模式之类的，不阻断游戏 */ }
    }

    const ACTIVITY_MS = {
      sleeping: 7000, cooking: 4500, eating: 5000, showering: 6000,
      reading: 4000, looking: 3000, watering: 3000,
    }
    let localDirty = false
    let reconnectArmed = false
    let designPending = {}
    let designTimer = 0

    function setNotice(text, tone = 'ok') {
      store.patch({ notice: { text, tone }, noticeAt: Date.now() })
    }

    function completionText(before, next) {
      if (!before || before === 'idle' || next.life.activity !== 'idle') return ''
      if (before === 'cooking') return `${next.life.meal || '饭'}出锅了，桌上等着呢。`
      if (before === 'eating') return `吃完了，饱腹 ${Math.round(next.life.hunger)}。`
      if (before === 'showering') return `洗完澡，洁净 ${Math.round(next.life.hygiene)}。`
      if (before === 'reading') return '书看完了，心情 +9。'
      if (before === 'looking') return '看够海了，心情 +5。'
      if (before === 'watering') return '浇完水了，盆栽精神了。'
      if (before === 'sleeping') return '睡饱了，她自己醒的。'
      return ''
    }

    function mergeDesign(base, patch) {
      const next = { ...base, ...patch }
      if (base.extras || patch.extras) next.extras = { ...(base.extras || {}), ...(patch.extras || {}) }
      if (base.resident || patch.resident) next.resident = { ...(base.resident || {}), ...(patch.resident || {}) }
      if (base.layout || patch.layout) next.layout = { ...(base.layout || {}), ...(patch.layout || {}) }
      return next
    }

    function queueDesign(payload) {
      designPending = mergeDesign(designPending, payload)
      if (designTimer) window.clearTimeout(designTimer)
      designTimer = window.setTimeout(() => {
        designTimer = 0
        const pending = designPending
        designPending = {}
        if (Object.keys(pending).length > 0) void act('design', pending)
      }, 180)
    }

    async function refresh() {
      if (fetching) return
      fetching = true
      try {
        const snap = store.get()
        if (snap.local) {
          const beforeActivity = snap.state?.life?.activity
          const next = localState || readLocal()
          tickLocal(next)
          writeLocal(next)
          const patch = { status: 'ready', state: next }
          const done = completionText(beforeActivity, next)
          if (done) { patch.notice = { text: done, tone: 'ok' }; patch.noticeAt = Date.now() }
          store.patch(patch)
        } else {
          const prev = snap.state
          const state = await fetchHostState()
          const patch = { status: 'ready', state, local: false }
          const done = completionText(prev?.life?.activity, state)
          if (done) { patch.notice = { text: done, tone: 'ok' }; patch.noticeAt = Date.now() }
          store.patch(patch)
        }
      } catch (error) {
        const snap = store.get()
        if (!snap.local) {
          const next = snap.state ? clone(snap.state) : readLocal()
          tickLocal(next)
          writeLocal(next)
          store.patch({ status: 'ready', state: next, local: true })
          setNotice('连不上小屋的宿主，先本地玩着。', 'warn')
        }
      } finally {
        fetching = false
      }
    }

    async function act(action, payload = {}) {
      const snap = store.get()
      if (!snap.state) return
      // 布置可以排队并发（每次只带改动的字段）；生活动作一次只做一件。
      if (snap.busy && !(action === 'design' && snap.busy === 'design')) return
      store.patch({ busy: action })
      const settle = () => {
        if (store.get().busy === action) store.patch({ busy: '' })
      }
      try {
        if (snap.local) {
          const next = localState || readLocal()
          const summary = applyLocal(next, action, payload)
          localDirty = true
          writeLocal(next)
          store.patch({ state: next, busy: '' })
          setNotice(summary, 'ok')
          return
        }
        const data = await postHostAction(action, payload)
        store.patch({ state: data.state })
        settle()
        if (data.summary) setNotice(data.summary, 'ok')
      } catch (error) {
        if (!error.http) {
          // host 没响应：用当前画面种下本地屋，别突然跳回旧存档
          try {
            const next = snap.state ? clone(snap.state) : readLocal()
            tickLocal(next)
            const summary = applyLocal(next, action, payload)
            localDirty = true
            writeLocal(next)
            store.patch({ state: next, local: true, busy: '' })
            setNotice(`${summary}（本地模式）`, 'warn')
          } catch (inner) {
            settle()
            setNotice(inner instanceof Error ? inner.message : '动作没做成', 'warn')
          }
        } else {
          settle()
          setNotice(error instanceof Error ? error.message : '动作没做成', 'warn')
        }
      }
      // 动作通常几秒后结算，早点刷新一次
      window.setTimeout(() => { if (!store.get().local) refresh() }, 6200)
    }

    async function reconnect() {
      if (store.get().local && localDirty && !reconnectArmed) {
        reconnectArmed = true
        setNotice('本地改过的布置不会带回去，再点一次「重连」确认。', 'warn')
        return
      }
      try {
        const state = await fetchHostState()
        reconnectArmed = false
        localDirty = false
        store.patch({ state, local: false, status: 'ready' })
        setNotice('接上小屋了。', 'ok')
      } catch {
        setNotice('还是没接上，先本地待着。', 'warn')
      }
    }

    function startSync(ctx) {
      if (started) return
      started = true
      refresh()
      intervalId = window.setInterval(() => {
        const snap = store.get()
        if (snap.notice && Date.now() - snap.noticeAt > 3600) {
          store.patch({ notice: null })
        }
        refresh()
      }, 3000)
      const onVisible = () => {
        if (document.visibilityState === 'visible') refresh()
      }
      document.addEventListener('visibilitychange', onVisible)
      ctx.effect(() => () => {
        window.clearInterval(intervalId)
        document.removeEventListener('visibilitychange', onVisible)
      }, 'dsh-house:sync')
    }

    function useHouse() {
      return useSyncExternalStore(store.subscribe, store.get, store.get)
    }

    /* ------------------------------------------------------------------
     * 小图标
     * ------------------------------------------------------------------ */

    function HouseIcon({ size = 18, active = false }) {
      return h('svg', {
        viewBox: '0 0 24 24', width: size, height: size, 'aria-hidden': true,
        style: { display: 'block', flex: 'none' },
      },
        h('path', {
          d: 'M3.6 11.2 12 4l8.4 7.2v7.4a1.4 1.4 0 0 1-1.4 1.4H5a1.4 1.4 0 0 1-1.4-1.4z',
          fill: active ? 'currentColor' : 'none',
          fillOpacity: active ? 0.16 : 0,
          stroke: 'currentColor', strokeWidth: 1.7, strokeLinejoin: 'round',
        }),
        h('path', {
          d: 'M9.2 20v-4.3a2.8 2.8 0 0 1 5.6 0V20',
          fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round',
        }),
        h('path', {
          d: 'M18.4 8.6c1.4-1 2.2-2.3 2.4-4 .1-.5.7-.6.9-.1.6 1.9 2 2.8 3.4 2.7-1 1.5-2.4 2.2-3.8 2.2 1.2 1.3 1.6 2.7 1.3 4-1.3-1.3-2.7-1.9-4.1-1.6',
          fill: 'none', stroke: 'currentColor', strokeWidth: 1.4, strokeLinecap: 'round',
          opacity: 0.55, transform: 'translate(-4 1) scale(.82)',
        }),
      )
    }

    /* ------------------------------------------------------------------
     * 角色
     * ------------------------------------------------------------------ */

    function Dandan({ pose = 'stand', facing = 1, theme = 'blue' }) {
      const pal = RESIDENT_THEMES[theme] || RESIDENT_THEMES.blue
      const closed = pose === 'shower'
      const arms = []

      if (pose === 'cook') {
        arms.push(h('rect', { key: 'al', x: 31, y: 96, width: 10, height: 32, rx: 5, fill: 'url(#skin)', transform: 'rotate(12 36 98)' }))
        arms.push(h('g', { key: 'ar', transform: 'rotate(-58 84 98)' },
          h('rect', { x: 79, y: 94, width: 10, height: 34, rx: 5, fill: 'url(#skin)' }),
          h('path', { d: 'M84 82v16', stroke: '#c9a06e', strokeWidth: 3, strokeLinecap: 'round' }),
          h('circle', { cx: 84, cy: 79, r: 4.5, fill: 'none', stroke: '#c9a06e', strokeWidth: 2.4 }),
        ))
      } else if (pose === 'eat') {
        arms.push(h('rect', { key: 'al', x: 33, y: 98, width: 10, height: 30, rx: 5, fill: 'url(#skin)', transform: 'rotate(30 38 100)' }))
        arms.push(h('rect', { key: 'ar', x: 77, y: 98, width: 10, height: 30, rx: 5, fill: 'url(#skin)', transform: 'rotate(-30 82 100)' }))
      } else if (pose === 'read') {
        arms.push(h('rect', { key: 'al', x: 36, y: 100, width: 10, height: 28, rx: 5, fill: 'url(#skin)', transform: 'rotate(52 41 102)' }))
        arms.push(h('rect', { key: 'ar', x: 74, y: 100, width: 10, height: 28, rx: 5, fill: 'url(#skin)', transform: 'rotate(-52 79 102)' }))
      } else if (pose === 'water') {
        arms.push(h('rect', { key: 'al', x: 33, y: 100, width: 10, height: 32, rx: 5, fill: 'url(#skin)', transform: 'rotate(10 38 102)' }))
        arms.push(h('rect', { key: 'ar', x: 80, y: 98, width: 10, height: 34, rx: 5, fill: 'url(#skin)', transform: 'rotate(-40 82 100)' }))
      } else if (pose === 'look') {
        arms.push(h('rect', { key: 'al', x: 36, y: 98, width: 10, height: 30, rx: 5, fill: 'url(#skin)', transform: 'rotate(34 38 100)' }))
        arms.push(h('rect', { key: 'ar', x: 74, y: 98, width: 10, height: 30, rx: 5, fill: 'url(#skin)', transform: 'rotate(-34 82 100)' }))
      } else {
        arms.push(h('rect', { key: 'al', x: 32, y: 98, width: 10, height: 34, rx: 5, fill: 'url(#skin)', transform: 'rotate(9 37 100)' }))
        arms.push(h('rect', { key: 'ar', x: 78, y: 98, width: 10, height: 34, rx: 5, fill: 'url(#skin)', transform: 'rotate(-9 83 100)' }))
      }

      return h('svg', {
        className: 'dh-dan',
        viewBox: '0 0 150 210',
        style: { transform: facing < 0 ? 'scaleX(-1)' : 'none' },
        'aria-hidden': true,
      },
        h('defs', null,
          h('linearGradient', { id: 'skin', x1: 0, y1: 0, x2: 0, y2: 1 },
            h('stop', { offset: 0, stopColor: '#ffe6d6' }),
            h('stop', { offset: 1, stopColor: '#f7d2bd' })),
          h('linearGradient', { id: 'hair', x1: 0, y1: 0, x2: 0.4, y2: 1 },
            h('stop', { offset: 0, stopColor: pal.hairLight }),
            h('stop', { offset: 1, stopColor: pal.hairDeep })),
        ),
        // 尾巴
        h('g', { className: 'dh-tail' },
          h('path', {
            d: 'M88 150c20-8 36 4 44 20 4 10-2 20-13 22 5-11 1-21-9-26 5 12 0 21-11 23 6-15 0-27-11-33-4-2-4-4 0-6z',
            fill: pal.tail, stroke: pal.tailStroke, strokeWidth: 4, strokeLinejoin: 'round',
          }),
        ),
        // 腿和鞋
        h('rect', { x: 44, y: 162, width: 11, height: 34, rx: 5.5, fill: 'url(#skin)' }),
        h('rect', { x: 65, y: 162, width: 11, height: 34, rx: 5.5, fill: 'url(#skin)' }),
        h('rect', { x: 40, y: 192, width: 18, height: 10, rx: 5, fill: MAID.shoe }),
        h('rect', { x: 62, y: 192, width: 18, height: 10, rx: 5, fill: MAID.shoe }),
        // 裙子（女仆装）
        h('path', { d: 'M60 94 37 166c15 8 31 8 46 0z', fill: MAID.dress, stroke: MAID.trim, strokeWidth: 3, strokeLinejoin: 'round' }),
        h('path', { d: 'M60 102 45 158c10 5 20 5 30 0z', fill: MAID.panel }),
        h('path', { d: 'M42 160c3 6 8 8 18 8s15-2 18-8', fill: 'none', stroke: MAID.apron, strokeWidth: 3, strokeLinecap: 'round' }),
        // 白色围裙
        h('path', { d: 'M50 112h20l8 46H42z', fill: MAID.apron, opacity: 0.97, stroke: '#dbe7f2', strokeWidth: 1.4 }),
        h('path', { d: 'M42 158c4 4 10 4 18 4s14 0 18-4', fill: 'none', stroke: MAID.apron, strokeWidth: 3, strokeLinecap: 'round' }),
        // 上身
        h('rect', { x: 46, y: 78, width: 28, height: 26, rx: 10, fill: MAID.dress, stroke: MAID.trim, strokeWidth: 2.4 }),
        h('path', { d: 'M50 80c3 6 7 9 10 9s7-3 10-9', fill: 'none', stroke: MAID.trim, strokeWidth: 3.4, strokeLinecap: 'round' }),
        h('path', { d: 'M52 90 60 96 68 90', fill: 'none', stroke: MAID.trim, strokeWidth: 2, strokeLinecap: 'round' }),
        // 手臂
        ...arms,
        // 围裙
        pose === 'cook' ? h('path', { d: 'M49 108h22l4 42H45z', fill: '#ffffff', opacity: 0.9, stroke: '#cfe0eb', strokeWidth: 2 }) : null,
        // 头
        h('circle', { cx: 60, cy: 58, r: 29, fill: 'url(#skin)' }),
        // 后发
        h('ellipse', { cx: 60, cy: 52, rx: 36, ry: 38, fill: 'url(#hair)' }),
        h('path', { d: 'M24 50c-8 22-6 52 4 72 8-6 10-28 8-50z', fill: pal.hairDeep }),
        h('path', { d: 'M96 50c8 22 6 52-4 72-8-6-10-28-8-50z', fill: pal.hairDeep }),
        // 鳍耳
        h('path', { d: 'M28 55c-13-4-19 8-11 19 4-7 11-8 17-6z', fill: pal.tail, stroke: pal.tailStroke, strokeWidth: 2.5, strokeLinejoin: 'round' }),
        h('path', { d: 'M92 55c13-4 19 8 11 19-4-7-11-8-17-6z', fill: pal.tail, stroke: pal.tailStroke, strokeWidth: 2.5, strokeLinejoin: 'round' }),
        h('path', { d: 'M22 62c4 0 7 2 9 5', fill: 'none', stroke: '#ffffff', strokeWidth: 2, strokeLinecap: 'round', opacity: 0.65 }),
        h('path', { d: 'M98 62c-4 0-7 2-9 5', fill: 'none', stroke: '#ffffff', strokeWidth: 2, strokeLinecap: 'round', opacity: 0.65 }),
        // 刘海
        h('path', { d: 'M28 48c3-20 18-32 32-32s29 12 32 32c-8-10-18-15-32-14-14-1-24 4-32 14z', fill: pal.hair }),
        h('path', { d: 'M34 44c5-12 14-18 26-18s21 6 26 18c-7-7-16-10-26-10s-19 3-26 10z', fill: pal.hairLight }),
        h('path', { d: 'M62 17c4-10 13-12 16-7-6 1-9 6-10 11z', fill: pal.hair }),
        // 女仆头饰
        h('path', { d: 'M31 33C43 17 77 17 89 33', fill: 'none', stroke: '#ffffff', strokeWidth: 5, strokeLinecap: 'round' }),
        [0, 1, 2, 3, 4, 5].map((index) => h('circle', {
          key: `frill-${index}`, cx: 35 + index * 10, cy: 27 - (index === 0 || index === 5 ? 0 : index === 1 || index === 4 ? 2 : 3),
          r: 4.6, fill: '#ffffff', stroke: '#e4edf5', strokeWidth: 0.8,
        })),
        // 蓝色蝴蝶结
        h('g', { transform: 'translate(86 43)' },
          h('path', { d: 'M0 0-10-6v12z', fill: pal.hairDeep, stroke: pal.tailStroke, strokeWidth: 1 }),
          h('path', { d: 'M0 0 10-6v12z', fill: pal.hairDeep, stroke: pal.tailStroke, strokeWidth: 1 }),
          h('circle', { cx: 0, cy: 0, r: 3.2, fill: pal.hairLight })),
        // 脸
        closed
          ? h('g', { fill: 'none', stroke: '#2a4a6b', strokeWidth: 2.4, strokeLinecap: 'round' },
            h('path', { d: 'M45 61c2 3 5 3 7 0' }),
            h('path', { d: 'M68 61c2 3 5 3 7 0' }))
          : h('g', null,
            h('ellipse', { cx: 48, cy: 61, rx: 4.5, ry: 6.2, fill: '#3f6fa0' }),
            h('ellipse', { cx: 72, cy: 61, rx: 4.5, ry: 6.2, fill: '#3f6fa0' }),
            h('ellipse', { cx: 48, cy: 63, rx: 2.6, ry: 3.4, fill: '#8fc4ea' }),
            h('ellipse', { cx: 72, cy: 63, rx: 2.6, ry: 3.4, fill: '#8fc4ea' }),
            h('circle', { cx: 49.4, cy: 58.4, r: 1.7, fill: '#ffffff' }),
            h('circle', { cx: 73.4, cy: 58.4, r: 1.7, fill: '#ffffff' }),
            h('circle', { cx: 46.8, cy: 64.4, r: 0.9, fill: '#ffffff', opacity: 0.9 }),
            h('circle', { cx: 70.8, cy: 64.4, r: 0.9, fill: '#ffffff', opacity: 0.9 })),
        h('ellipse', { cx: 40, cy: 70, rx: 6, ry: 3.4, fill: '#f2a9a9', opacity: 0.55 }),
        h('ellipse', { cx: 80, cy: 70, rx: 6, ry: 3.4, fill: '#f2a9a9', opacity: 0.55 }),
        h('path', { d: 'M56 71c2.5 2.4 5.5 2.4 8 0', fill: 'none', stroke: '#c96a6a', strokeWidth: 1.8, strokeLinecap: 'round' }),
        // 道具
        pose === 'eat' ? h('g', null,
          h('ellipse', { cx: 60, cy: 130, rx: 17, ry: 6, fill: '#ffffff', stroke: MAID.trim, strokeWidth: 2 }),
          h('path', { d: 'M45 130c2 9 10 13 15 13s13-4 15-13z', fill: '#ffffff', stroke: MAID.trim, strokeWidth: 2 }),
          h('ellipse', { cx: 60, cy: 127, rx: 11, ry: 3, fill: '#f7e2b8' }),
        ) : null,
        pose === 'read' ? h('g', null,
          h('path', { d: 'M40 116 58 111v34l-18 5z', fill: '#fdf8ed', stroke: '#b78b5e', strokeWidth: 2 }),
          h('path', { d: 'M80 116 62 111v34l18 5z', fill: '#fdf8ed', stroke: '#b78b5e', strokeWidth: 2 }),
          h('path', { d: 'M46 122h7M46 128h7M46 134h6M67 122h7M67 128h7M67 134h6', stroke: '#c7b191', strokeWidth: 1.4, strokeLinecap: 'round' }),
        ) : null,
        pose === 'water' ? h('g', null,
          h('rect', { x: 82, y: 112, width: 16, height: 12, rx: 3, fill: '#9ad1c0', stroke: '#5f9f8a', strokeWidth: 2 }),
          h('path', { d: 'M98 116h7l-2 5h-5', fill: 'none', stroke: '#5f9f8a', strokeWidth: 2.4, strokeLinecap: 'round' }),
          h('circle', { cx: 103, cy: 126, r: 1.8, fill: '#7fc4e8' }),
          h('circle', { cx: 100, cy: 132, r: 1.5, fill: '#7fc4e8' }),
        ) : null,
        pose === 'shower' ? h('g', { opacity: 0.9 },
          h('circle', { cx: 92, cy: 50, r: 2, fill: '#9ed8f2' }),
          h('circle', { cx: 100, cy: 66, r: 2.4, fill: '#9ed8f2' }),
          h('circle', { cx: 88, cy: 84, r: 1.8, fill: '#9ed8f2' }),
          h('circle', { cx: 30, cy: 62, r: 2.2, fill: '#9ed8f2' }),
        ) : null,
      )
    }

    /* ------------------------------------------------------------------
     * 房间场景
     * ------------------------------------------------------------------ */

    function drawFloor(floor) {
      const parts = []
      parts.push(h('rect', { key: 'floor-base', x: 0, y: 346, width: 1000, height: 214, fill: floor.base }))
      parts.push(h('rect', { key: 'floor-shade', x: 0, y: 346, width: 1000, height: 214, fill: 'url(#floorShade)' }))
      if (floor === FLOORS.carpet) {
        for (let i = 0; i < 42; i += 1) {
          parts.push(h('circle', {
            key: `carpet-${i}`, cx: (i * 137) % 1000, cy: 362 + ((i * 53) % 190),
            r: 2.2, fill: floor.line, opacity: 0.32,
          }))
        }
      } else if (floor === FLOORS.tile) {
        for (let y = 346; y < 560; y += 42) {
          parts.push(h('path', { key: `tile-h-${y}`, d: `M0 ${y}H1000`, stroke: floor.line, strokeWidth: 1.2, opacity: 0.5 }))
        }
        for (let x = 0; x < 1000; x += 84) {
          parts.push(h('path', { key: `tile-v-${x}`, d: `M${x} 346V560`, stroke: floor.line, strokeWidth: 1.2, opacity: 0.5 }))
        }
      } else if (floor === FLOORS.stone) {
        for (let row = 0; row < 4; row += 1) {
          const y = 346 + row * 54
          const offset = row % 2 === 0 ? 0 : 70
          for (let x = offset; x < 1000; x += 140) {
            parts.push(h('rect', {
              key: `stone-${row}-${x}`, x: x + 2, y: y + 2, width: 136, height: 50, rx: 7,
              fill: row % 2 === 0 ? floor.dark : floor.base, opacity: 0.34,
              stroke: floor.line, strokeWidth: 1,
            }))
          }
        }
      } else {
        for (let i = 0; i < 7; i += 1) {
          const y = 346 + i * 30
          parts.push(h('rect', {
            key: `plank-${i}`, x: 0, y, width: 1000, height: 29,
            fill: i % 2 === 0 ? floor.dark : floor.base, opacity: i % 2 === 0 ? 0.3 : 0.08,
          }))
          parts.push(h('path', { key: `plank-line-${i}`, d: `M0 ${y + 29}H1000`, stroke: floor.line, strokeWidth: 1.2, opacity: 0.4 }))
          const offset = i % 2 === 0 ? 0 : 120
          for (let x = offset; x < 1000; x += 240) {
            parts.push(h('path', { key: `seam-${i}-${x}`, d: `M${x} ${y}V${y + 29}`, stroke: floor.line, strokeWidth: 1, opacity: 0.26 }))
          }
        }
      }
      return parts
    }

    function drawWindow({ wall, curtain, night, dusk, sky, view = 'sea' }) {
      const starry = night || view === 'stars'
      const stars = []
      if (starry) {
        for (let i = 0; i < 9; i += 1) {
          stars.push(h('circle', {
            key: `star-${i}`, cx: 806 + ((i * 53) % 112), cy: 86 + ((i * 41) % 58),
            r: i % 3 === 0 ? 1.6 : 1, fill: '#eaf5ff', opacity: 0.9,
          }))
        }
      }
      return h('g', { key: 'window' },
        h('rect', { x: 764, y: 56, width: 198, height: 6, rx: 3, fill: '#b98a5e' }),
        h('circle', { cx: 764, cy: 59, r: 5, fill: '#b98a5e' }),
        h('circle', { cx: 962, cy: 59, r: 5, fill: '#b98a5e' }),
        h('rect', { x: 782, y: 64, width: 156, height: 152, rx: 8, fill: wall.trim, stroke: wall.ink, strokeWidth: 3 }),
        h('rect', { x: 794, y: 76, width: 132, height: 128, rx: 4, fill: 'url(#skyGrad)' }),
        view === 'sea' ? h('rect', { x: 794, y: 148, width: 132, height: 56, fill: night ? '#173252' : '#7fc0e8', opacity: 0.6 }) : null,
        view === 'sea' ? h('path', { d: 'M794 156c18 4 30-4 46 0s30 4 44 0 26-4 42 0', fill: 'none', stroke: night ? '#7fa6c9' : '#d9f2ff', strokeWidth: 2, opacity: 0.8 }) : null,
        view === 'sea' ? h('path', { d: 'M794 168c16 4 30-4 46 0s30 4 44 0 26-4 42 0', fill: 'none', stroke: night ? '#6389ad' : '#bfe6fa', strokeWidth: 1.6, opacity: 0.7 }) : null,
        view === 'forest' ? h('g', null,
          h('path', { d: 'M794 204 840 154 886 204Z', fill: '#4f9a78', opacity: 0.8 }),
          h('path', { d: 'M850 204 892 160 934 204Z', fill: '#3d7d60', opacity: 0.8 }),
          h('path', { d: 'M812 204v-34M875 204v-40', stroke: '#6f4a2e', strokeWidth: 4, opacity: 0.7 })) : null,
        view === 'city' ? h('g', null,
          h('rect', { x: 800, y: 146, width: 22, height: 58, fill: '#384a5e', opacity: 0.85 }),
          h('rect', { x: 828, y: 128, width: 26, height: 76, fill: '#2f4054', opacity: 0.9 }),
          h('rect', { x: 860, y: 156, width: 20, height: 48, fill: '#384a5e', opacity: 0.85 }),
          h('rect', { x: 886, y: 138, width: 26, height: 66, fill: '#2f4054', opacity: 0.9 })) : null,
        view === 'snow' ? h('g', null,
          [0, 1, 2, 3, 4, 5, 6, 7].map((index) => h('circle', {
            key: `snow-${index}`, cx: 804 + ((index * 31) % 110), cy: 94 + ((index * 23) % 88),
            r: index % 3 === 0 ? 2.2 : 1.4, fill: '#ffffff', opacity: 0.9,
          }))) : null,
        view === 'garden' ? h('g', null,
          [0, 1, 2, 3, 4, 5].map((index) => h('circle', {
            key: `flower-${index}`, cx: 810 + ((index * 37) % 100), cy: 182 + ((index * 7) % 16),
            r: 3, fill: ['#f2a9c4', '#f3d9a8', '#b9a7e0', '#f2a9c4', '#f3d9a8', '#6cc3a3'][index],
          }))) : null,
        ...stars,
        starry
          ? h('g', null,
            h('circle', { cx: 886, cy: view === 'stars' ? 112 : 104, r: 15, fill: '#ffe9b8' }),
            h('circle', { cx: 880, cy: view === 'stars' ? 108 : 100, r: 15, fill: sky[0] }),
            h('circle', { cx: 890, cy: view === 'stars' ? 118 : 110, r: 3, fill: '#e8d5a8', opacity: 0.7 }))
          : h('circle', { cx: 886, cy: dusk ? 136 : 104, r: 15, fill: dusk ? '#ffd08a' : '#ffe9a8' }),
        (view === 'sea' || view === 'city') && (dusk || night)
          ? h('path', { d: 'M846 146h34l-8 6h-18z', fill: '#384a5e', opacity: 0.8 })
          : null,
        h('path', { d: 'M860 76v128', stroke: wall.trim, strokeWidth: 4 }),
        h('path', { d: 'M794 138h132', stroke: wall.trim, strokeWidth: 4 }),
        h('rect', { x: 774, y: 210, width: 172, height: 9, rx: 4, fill: wall.trim, stroke: wall.ink, strokeWidth: 2 }),
        // 窗帘
        h('path', {
          d: 'M772 62c-8 34-6 92 2 146l30 4c-9-46-9-102-4-150z',
          fill: curtain.base, stroke: curtain.deep, strokeWidth: 2, opacity: 0.95,
        }),
        h('path', {
          d: 'M948 62c8 34 6 92-2 146l-30 4c9-46 9-102 4-150z',
          fill: curtain.base, stroke: curtain.deep, strokeWidth: 2, opacity: 0.95,
        }),
        h('path', { d: 'M780 74c-5 30-4 74 1 112', fill: 'none', stroke: curtain.deep, strokeWidth: 1.4, opacity: 0.55 }),
        h('path', { d: 'M940 74c5 30 4 74-1 112', fill: 'none', stroke: curtain.deep, strokeWidth: 1.4, opacity: 0.55 }),
      )
    }

    function drawArt() {
      return h('g', { key: 'art' },
        h('rect', { x: 286, y: 72, width: 126, height: 96, rx: 6, fill: '#f7f1e4', stroke: '#b98a5e', strokeWidth: 5 }),
        h('image', {
          href: AVATAR, x: 296, y: 82, width: 106, height: 76,
          preserveAspectRatio: 'xMidYMid slice',
        }),
        h('rect', { x: 296, y: 82, width: 106, height: 76, rx: 3, fill: 'none', stroke: '#ffffff', strokeWidth: 1.5, opacity: 0.65 }),
      )
    }

    function drawShelf() {
      const books = [
        ['#e79aa9', 18], ['#8fc4ea', 14], ['#f3d9a8', 20], ['#a9ddc7', 15], ['#b9a7d8', 19], ['#f4b8c4', 13], ['#9ccdb8', 17],
      ]
      let x = 556
      const items = [h('rect', { key: 'shelf-board', x: 546, y: 92, width: 152, height: 12, rx: 4, fill: '#b98a5e' })]
      books.forEach(([color, width], index) => {
        const tall = 34 + (index % 3) * 5
        items.push(h('rect', {
          key: `book-${index}`, x, y: 92 - tall, width, height: tall, rx: 2,
          fill: color, stroke: '#ffffff', strokeWidth: 0.7, opacity: 0.95,
        }))
        x += width + 3
      })
      items.push(h('path', { d: 'M560 104v22M680 104v22', stroke: '#8a5f3d', strokeWidth: 4, strokeLinecap: 'round' }))
      return h('g', { key: 'shelf' }, ...items)
    }

    function drawBed({ bedding, sleeping, theme = 'blue' }) {
      const pal = RESIDENT_THEMES[theme] || RESIDENT_THEMES.blue
      const parts = []
      parts.push(h('ellipse', { key: 'bed-shadow', cx: 190, cy: 474, rx: 128, ry: 16, fill: '#0b1b2e', opacity: 0.16 }))
      parts.push(h('rect', { key: 'bed-frame', x: 76, y: 428, width: 244, height: 40, rx: 8, fill: '#8a5f3d', stroke: '#6f4a2e', strokeWidth: 2 }))
      parts.push(h('rect', { key: 'bed-board', x: 50, y: 246, width: 36, height: 224, rx: 16, fill: '#b98a5e', stroke: '#8a5f3d', strokeWidth: 3 }))
      parts.push(h('rect', { key: 'mattress', x: 80, y: 336, width: 232, height: 96, rx: 16, fill: '#fdf8ef', stroke: '#d9cbb6', strokeWidth: 2 }))
      parts.push(h('rect', { key: 'blanket', x: 104, y: 354, width: 198, height: 72, rx: 14, fill: bedding.base, stroke: bedding.deep, strokeWidth: 2 }))
      parts.push(h('path', { key: 'blanket-fold', d: 'M104 366h198', stroke: bedding.pale, strokeWidth: 8, opacity: 0.9 }))
      parts.push(h('path', { key: 'blanket-stitch', d: 'M120 410h164', stroke: bedding.deep, strokeWidth: 1.4, opacity: 0.45, strokeDasharray: '6 6' }))
      parts.push(h('rect', { key: 'pillow-1', x: 92, y: 320, width: 60, height: 28, rx: 12, fill: bedding.pale, stroke: bedding.deep, strokeWidth: 1.6, transform: 'rotate(-4 122 334)' }))
      parts.push(h('rect', { key: 'pillow-2', x: 100, y: 334, width: 58, height: 26, rx: 12, fill: '#ffffff', stroke: bedding.deep, strokeWidth: 1.4, transform: 'rotate(2 129 347)' }))
      if (sleeping) {
        parts.push(h('g', { key: 'sleeper' },
          h('ellipse', { cx: 150, cy: 344, rx: 34, ry: 24, fill: pal.hairDeep }),
          h('circle', { cx: 140, cy: 346, r: 19, fill: '#ffd9c4' }),
          h('path', { d: 'M126 344c3 2 6 2 9 0M146 344c3 2 6 2 9 0', fill: 'none', stroke: '#2a4a6b', strokeWidth: 2, strokeLinecap: 'round' }),
          h('path', { d: 'M132 350c3 2.4 6 2.4 9 0', fill: 'none', stroke: '#c96a6a', strokeWidth: 1.6, strokeLinecap: 'round' }),
          h('path', { d: 'M122 330c2-10 9-14 16-12-4 4-6 8-6 12z', fill: pal.hair }),
          h('circle', { cx: 130, cy: 338, r: 4.4, fill: '#ffffff' }),
          h('circle', { cx: 130, cy: 338, r: 2, fill: '#ffd98a' }),
          h('path', { d: 'M170 344c26 0 46 6 54 18-10 6-22 6-34 0-10-5-18-6-28-4z', fill: bedding.base, stroke: bedding.deep, strokeWidth: 2 }),
          h('path', { d: 'M220 360c14-4 25 2 31 13-8 2-14 0-19-3 4 6 3 12-2 16-4-8-8-14-16-16z', fill: pal.tail, stroke: pal.tailStroke, strokeWidth: 2.6, strokeLinejoin: 'round' }),
          h('text', { className: 'dh-zzz', x: 196, y: 322, fontSize: 20, fontWeight: 700, fill: '#6aa9d8' }, 'z'),
          h('text', { className: 'dh-zzz dh-zzz-2', x: 214, y: 306, fontSize: 26, fontWeight: 700, fill: '#8fc4ea' }, 'Z'),
          h('text', { className: 'dh-zzz dh-zzz-3', x: 236, y: 288, fontSize: 30, fontWeight: 700, fill: '#b3dcf5' }, 'Z'),
        ))
      }
      return parts
    }

    function drawKitchen({ kitchen, cooking }) {
      const parts = [
        h('ellipse', { key: 'kitchen-shadow', cx: 790, cy: 472, rx: 116, ry: 14, fill: '#0b1b2e', opacity: 0.14 }),
        h('rect', { key: 'kitchen-back', x: 682, y: 262, width: 198, height: 56, fill: '#eef6f8', opacity: 0.55 }),
        h('rect', { key: 'kitchen-body', x: 682, y: 334, width: 198, height: 122, rx: 6, fill: kitchen.base, stroke: kitchen.deep, strokeWidth: 2 }),
        h('path', { key: 'kitchen-door', d: 'M780 336v118', stroke: kitchen.deep, strokeWidth: 2, opacity: 0.7 }),
        h('rect', { key: 'handle-1', x: 700, y: 392, width: 20, height: 4, rx: 2, fill: kitchen.deep }),
        h('rect', { key: 'handle-2', x: 820, y: 392, width: 20, height: 4, rx: 2, fill: kitchen.deep }),
        h('rect', { key: 'counter', x: 674, y: 318, width: 214, height: 18, rx: 6, fill: '#f4f1ea', stroke: '#cfc9bd', strokeWidth: 2 }),
        h('rect', { key: 'cooktop', x: 700, y: 304, width: 92, height: 15, rx: 4, fill: '#3b4654' }),
        h('circle', { key: 'burner-1', cx: 722, cy: 311.5, r: 6.5, fill: 'none', stroke: '#8b96a3', strokeWidth: 2 }),
        h('circle', { key: 'burner-2', cx: 766, cy: 311.5, r: 6.5, fill: 'none', stroke: '#8b96a3', strokeWidth: 2 }),
      ]
      const jars = [['#e7a6a6', 706], ['#a9ddc7', 722], ['#f3d9a8', 738]]
      jars.forEach(([color, x], index) => {
        parts.push(h('rect', { key: `jar-${index}`, x, y: 292, width: 13, height: 22, rx: 3, fill: color, stroke: '#ffffff', strokeWidth: 1.4, opacity: 0.9 }))
        parts.push(h('rect', { key: `jar-lid-${index}`, x: x - 1, y: 288, width: 15, height: 5, rx: 2, fill: '#ffffff', opacity: 0.9 }))
      })
      parts.push(h('rect', { key: 'fridge', x: 886, y: 210, width: 84, height: 246, rx: 10, fill: '#e9f1f4', stroke: '#b8c8cf', strokeWidth: 3 }))
      parts.push(h('path', { key: 'fridge-split', d: 'M888 318h80', stroke: '#b8c8cf', strokeWidth: 2.4 }))
      parts.push(h('rect', { key: 'fridge-handle-1', x: 904, y: 252, width: 5, height: 30, rx: 2.5, fill: '#9fb3bd' }))
      parts.push(h('rect', { key: 'fridge-handle-2', x: 904, y: 336, width: 5, height: 42, rx: 2.5, fill: '#9fb3bd' }))
      parts.push(h('circle', { key: 'magnet-1', cx: 928, cy: 232, r: 4, fill: '#f2a9a9' }))
      parts.push(h('circle', { key: 'magnet-2', cx: 944, cy: 248, r: 4, fill: '#9ad1c0' }))
      parts.push(h('circle', { key: 'magnet-3', cx: 930, cy: 266, r: 4, fill: '#f3d9a8' }))
      parts.push(h('rect', { key: 'fridge-note', x: 918, y: 284, width: 36, height: 26, rx: 2, fill: '#fdf6e8', stroke: '#e2d3b7', strokeWidth: 1.4, transform: 'rotate(-3 936 297)' }))
      parts.push(h('path', { key: 'fridge-note-line', d: 'M924 292h20M924 298h16M924 304h12', stroke: '#cbb694', strokeWidth: 1.2, strokeLinecap: 'round' }))
      if (cooking) {
        parts.push(h('g', { key: 'pot' },
          h('rect', { x: 750, y: 278, width: 34, height: 26, rx: 4, fill: '#9aa7b5', stroke: '#6f7c8a', strokeWidth: 2 }),
          h('ellipse', { cx: 767, cy: 278, rx: 17, ry: 5, fill: '#c7d2dc', stroke: '#6f7c8a', strokeWidth: 1.6 }),
          h('rect', { x: 782, y: 282, width: 15, height: 4, rx: 2, fill: '#6f7c8a' }),
          h('path', { className: 'dh-steam', d: 'M758 268c-4-8 4-12 0-20', fill: 'none', stroke: '#ffffff', strokeWidth: 3, strokeLinecap: 'round', opacity: 0.75 }),
          h('path', { className: 'dh-steam dh-steam-2', d: 'M767 264c-4-8 4-12 0-20', fill: 'none', stroke: '#ffffff', strokeWidth: 3, strokeLinecap: 'round', opacity: 0.6 }),
          h('path', { className: 'dh-steam dh-steam-3', d: 'M776 268c-4-8 4-12 0-20', fill: 'none', stroke: '#ffffff', strokeWidth: 3, strokeLinecap: 'round', opacity: 0.7 }),
        ))
      }
      return parts
    }

    function drawTable({ meal }) {
      const parts = [
        h('ellipse', { key: 'table-shadow', cx: 500, cy: 494, rx: 104, ry: 15, fill: '#0b1b2e', opacity: 0.14 }),
        h('rect', { key: 'table-leg', x: 492, y: 406, width: 16, height: 72, rx: 6, fill: '#a9784f' }),
        h('ellipse', { key: 'table-base', cx: 500, cy: 480, rx: 52, ry: 10, fill: '#8a5f3d' }),
        h('rect', { key: 'table-side', x: 408, y: 394, width: 184, height: 12, rx: 5, fill: '#b0824f' }),
        h('ellipse', { key: 'table-top', cx: 500, cy: 392, rx: 92, ry: 26, fill: '#c99a66', stroke: '#a9784f', strokeWidth: 2 }),
      ]
      if (meal) {
        parts.push(h('g', { key: 'meal' },
          h('ellipse', { cx: 500, cy: 386, rx: 26, ry: 8, fill: '#ffffff', stroke: '#5b9bd5', strokeWidth: 2 }),
          h('path', { d: 'M476 386c3 12 13 17 24 17s21-5 24-17z', fill: '#ffffff', stroke: '#5b9bd5', strokeWidth: 2 }),
          h('ellipse', { cx: 500, cy: 382, rx: 18, ry: 4.5, fill: '#f3d9a8' }),
          h('path', { className: 'dh-steam', d: 'M492 372c-4-8 4-12 0-18', fill: 'none', stroke: '#ffffff', strokeWidth: 2.6, strokeLinecap: 'round', opacity: 0.7 }),
          h('path', { className: 'dh-steam dh-steam-2', d: 'M506 368c-4-8 4-12 0-18', fill: 'none', stroke: '#ffffff', strokeWidth: 2.6, strokeLinecap: 'round', opacity: 0.55 }),
          h('text', { x: 540, y: 374, fontSize: 13, fill: '#7c93a8', fontWeight: 600 }, meal),
        ))
      }
      return parts
    }

    function drawPlant({ watering }) {
      return h('g', { key: 'plant' },
        h('path', { d: 'M630 470h52l-6-38h-40z', fill: '#d08a6a', stroke: '#a96a4e', strokeWidth: 2.4 }),
        h('path', { d: 'M632 438h48', stroke: '#a96a4e', strokeWidth: 3, strokeLinecap: 'round' }),
        h('path', { d: 'M656 438c-2-24-16-34-28-40 2 16 10 30 28 40z', fill: '#4f9a78', stroke: '#3d7d60', strokeWidth: 1.6 }),
        h('path', { d: 'M656 438c2-28 16-38 30-42-2 18-12 34-30 42z', fill: '#63b58e', stroke: '#3d7d60', strokeWidth: 1.6 }),
        h('path', { d: 'M656 438c0-30-4-44-2-58 8 12 10 34 2 58z', fill: '#79c9a0', stroke: '#3d7d60', strokeWidth: 1.6 }),
        watering
          ? h('g', { key: 'water-drops' },
            h('circle', { className: 'dh-drop', cx: 650, cy: 420, r: 2.4, fill: '#7fc4e8' }),
            h('circle', { className: 'dh-drop dh-drop-2', cx: 662, cy: 428, r: 2, fill: '#7fc4e8' }),
            h('circle', { className: 'dh-drop dh-drop-3', cx: 642, cy: 432, r: 1.8, fill: '#7fc4e8' }))
          : null,
      )
    }

    function drawLamp({ night }) {
      return h('g', { key: 'lamp' },
        h('rect', { x: 362, y: 282, width: 5, height: 186, rx: 2.5, fill: '#8c7a63' }),
        h('ellipse', { cx: 364, cy: 468, rx: 28, ry: 7, fill: '#6f5f4c' }),
        h('path', { d: 'M338 282h52l-10-38h-32z', fill: '#f3d9a8', stroke: '#d3b078', strokeWidth: 2 }),
        h('rect', { x: 356, y: 240, width: 16, height: 6, rx: 3, fill: '#b98a5e' }),
        night
          ? h('g', null,
            h('circle', { cx: 364, cy: 300, r: 10, fill: '#ffe7b0', opacity: 0.95 }),
            h('circle', { cx: 364, cy: 330, r: 150, fill: 'url(#lampGlow)' }))
          : h('circle', { cx: 364, cy: 300, r: 4, fill: '#ffe7b0', opacity: 0.7 }),
      )
    }

    function drawRug() {
      return h('g', { key: 'rug' },
        h('ellipse', { cx: 500, cy: 516, rx: 188, ry: 34, fill: '#efe1c8', opacity: 0.75 }),
        h('ellipse', { cx: 500, cy: 516, rx: 150, ry: 26, fill: 'none', stroke: '#d9c3a2', strokeWidth: 3, opacity: 0.8 }),
        h('ellipse', { cx: 500, cy: 516, rx: 92, ry: 15, fill: 'none', stroke: '#d9c3a2', strokeWidth: 2, opacity: 0.55 }),
      )
    }

    function drawCatBed() {
      return h('g', { key: 'catbed' },
        h('ellipse', { cx: 800, cy: 514, rx: 52, ry: 18, fill: '#f3d9c9', stroke: '#d9b29c', strokeWidth: 2 }),
        h('ellipse', { cx: 800, cy: 512, rx: 38, ry: 12, fill: '#fbe9de' }),
        h('ellipse', { cx: 798, cy: 506, rx: 20, ry: 12, fill: '#7fb9e6' }),
        h('path', { d: 'M784 498l-3-10 8 5zM812 498l3-10-8 5z', fill: '#7fb9e6' }),
        h('path', { d: 'M780 508c-8 4-6 12 4 12', fill: 'none', stroke: '#5f9fd2', strokeWidth: 3, strokeLinecap: 'round' }),
        h('path', { d: 'M790 508c-3 2-5 2-8 0', fill: 'none', stroke: '#3f6f9a', strokeWidth: 1.6, strokeLinecap: 'round' }),
        h('path', { d: 'M804 508c3 2 5 2 8 0', fill: 'none', stroke: '#3f6f9a', strokeWidth: 1.6, strokeLinecap: 'round' }),
      )
    }

    function drawDoor({ showering }) {
      return h('g', { key: 'bathroom' },
        h('rect', { x: 136, y: 88, width: 118, height: 258, rx: 8, fill: '#f7f1e4', stroke: '#b98a5e', strokeWidth: 5 }),
        h('rect', {
          x: 148, y: 100, width: 94, height: 236, rx: 5,
          fill: showering ? '#ffe7b0' : '#dcebf3', stroke: '#c9dbe5', strokeWidth: 2,
          opacity: showering ? 0.96 : 0.92,
        }),
        h('path', { d: 'M160 104v228M195 104v228M230 104v228', stroke: '#ffffff', strokeWidth: 2, opacity: 0.5 }),
        h('circle', { cx: 234, cy: 252, r: 5, fill: '#b98a5e' }),
        h('text', { x: 195, y: 122, textAnchor: 'middle', fontSize: 11, fontWeight: 600, fill: showering ? '#a9784f' : '#7c93a8' }, '浴室'),
        h('rect', { x: 136, y: 342, width: 118, height: 6, rx: 3, fill: '#d9cbb6', opacity: 0.85 }),
        showering
          ? h('g', null,
            h('path', { className: 'dh-steam', d: 'M168 326c-4-8 4-12 0-20', fill: 'none', stroke: '#ffffff', strokeWidth: 3, strokeLinecap: 'round', opacity: 0.75 }),
            h('path', { className: 'dh-steam dh-steam-2', d: 'M208 330c-4-8 4-12 0-20', fill: 'none', stroke: '#ffffff', strokeWidth: 3, strokeLinecap: 'round', opacity: 0.6 }),
            h('circle', { className: 'dh-drop', cx: 186, cy: 318, r: 2.4, fill: '#9ed8f2' }),
            h('circle', { className: 'dh-drop dh-drop-2', cx: 214, cy: 314, r: 2, fill: '#9ed8f2' }))
          : null,
      )
    }

    function drawClock({ clock }) {      const hourAngle = ((clock % 12) * 30)
      const minuteAngle = ((clock * 60) % 60) * 6
      return h('g', { key: 'clock' },
        h('circle', { cx: 470, cy: 124, r: 26, fill: '#f7f1e4', stroke: '#b98a5e', strokeWidth: 3 }),
        h('circle', { cx: 470, cy: 124, r: 21, fill: 'none', stroke: '#cbb694', strokeWidth: 1, opacity: 0.7 }),
        h('g', { transform: `rotate(${hourAngle} 470 124)` }, h('line', { x1: 470, y1: 124, x2: 470, y2: 110, stroke: '#6f5f4c', strokeWidth: 3, strokeLinecap: 'round' })),
        h('g', { transform: `rotate(${minuteAngle} 470 124)` }, h('line', { x1: 470, y1: 124, x2: 470, y2: 106, stroke: '#8c7a63', strokeWidth: 2, strokeLinecap: 'round' })),
        h('circle', { cx: 470, cy: 124, r: 2.6, fill: '#6f5f4c' }),
      )
    }

    function Scene({ state, walking, onAct, onWalk, busy }) {
      const house = state.house
      const life = state.life
      const wall = WALLPAPERS[house.wallpaper] || WALLPAPERS.ocean
      const floor = FLOORS[house.floor] || FLOORS.oak
      const bedding = BEDDINGS[house.bedding] || BEDDINGS.blue
      const kitchen = KITCHENS[house.kitchen] || KITCHENS.mint
      const curtain = CURTAINS[house.curtain] || CURTAINS.sheer
      const theme = residentOf(house).theme

      const hour = life.clock
      const night = hour < 6 || hour >= 19.5
      const dusk = !night && (hour < 7.5 || hour >= 17)
      const sky = night
        ? ['#1b2c4a', '#3b5f86']
        : dusk
          ? ['#ffd2a0', '#ffb07a']
          : ['#bfe6ff', '#e9f7ff']
      const windowView = house.view || 'sea'
      const windowSky = windowView === 'stars'
        ? ['#1b2c4a', '#3b5f86']
        : windowView === 'snow'
          ? ['#e5f2fc', '#fbfdff']
          : sky
      const sleeping = life.activity === 'sleeping'
      const idle = life.activity === 'idle'
      const cooking = life.activity === 'cooking'
      const watering = life.activity === 'watering'
      const pose = POSE[life.activity] || 'stand'

      function handleStageClick(event) {
        if (busy || !idle) return
        const rect = event.currentTarget.getBoundingClientRect()
        if (!rect.width) return
        const percent = ((event.clientX - rect.left) / rect.width) * 100
        onWalk(Math.round(clamp(percent, 8, 92)))
      }

      const hotspot = (label, style, onClick, disabled = false) => h('button', {
        type: 'button',
        className: 'dh-hot',
        'data-label': label,
        'aria-label': label,
        style,
        disabled,
        onClick(event) {
          event.stopPropagation()
          if (!disabled) onClick()
        },
      })

      return h('div', { className: `dh-stage${night ? ' is-night' : dusk ? ' is-dusk' : ''}`, onClick: handleStageClick },
        h('svg', { className: 'dh-room', viewBox: '0 0 1000 560', 'aria-hidden': true },
          h('defs', null,
            h('linearGradient', { id: 'skyGrad', x1: 0, y1: 0, x2: 0, y2: 1 },
              h('stop', { offset: 0, stopColor: windowSky[0] }),
              h('stop', { offset: 1, stopColor: windowSky[1] })),
            h('linearGradient', { id: 'floorShade', x1: 0, y1: 0, x2: 0, y2: 1 },
              h('stop', { offset: 0, stopColor: '#08182c', stopOpacity: 0.16 }),
              h('stop', { offset: 0.55, stopColor: '#08182c', stopOpacity: 0 })),
            h('radialGradient', { id: 'lampGlow' },
              h('stop', { offset: 0, stopColor: '#ffd98a', stopOpacity: 0.55 }),
              h('stop', { offset: 1, stopColor: '#ffd98a', stopOpacity: 0 })),
            h('pattern', { id: 'wallStripe', width: 28, height: 28, patternUnits: 'userSpaceOnUse' },
              h('path', { d: 'M0 0V28', stroke: wall.ink, strokeWidth: 1, opacity: 0.07 })),
          ),
          h('rect', { x: 0, y: 0, width: 1000, height: 346, fill: wall.base }),
          h('rect', { x: 0, y: 0, width: 1000, height: 346, fill: 'url(#wallStripe)' }),
          h('rect', { x: 0, y: 250, width: 1000, height: 96, fill: wall.deep, opacity: 0.72 }),
          h('rect', { x: 0, y: 246, width: 1000, height: 5, fill: wall.trim, opacity: 0.9 }),
          h('rect', { x: 0, y: 340, width: 1000, height: 7, fill: wall.deep, opacity: 0.9 }),
          ...Array.from({ length: 12 }, (_, index) => h('path', {
            key: `panel-${index}`, d: `M${40 + index * 84} 256V336`, stroke: wall.ink, strokeWidth: 1, opacity: 0.16,
          })),
          h('rect', { x: 0, y: 346, width: 1000, height: 14, fill: wall.trim }),
          h('rect', { x: 0, y: 346, width: 1000, height: 3, fill: wall.ink, opacity: 0.22 }),
          ...drawFloor(floor),
          drawWindow({ wall, curtain, night, dusk, sky: windowSky, view: windowView }),
          house.extras.art ? drawArt() : null,
          house.extras.shelf ? drawShelf() : null,
          drawDoor({ showering: life.activity === 'showering' }),
          drawClock({ clock: life.clock }),
          drawBed({ bedding, sleeping, theme }),
          drawKitchen({ kitchen, cooking }),
          house.extras.rug ? drawRug() : null,
          drawTable({ meal: life.activity === 'eating' ? null : life.meal }),
          house.extras.plant ? drawPlant({ watering }) : null,
          drawLamp({ night }),
          house.extras.catbed ? drawCatBed() : null,
          night ? h('rect', { x: 0, y: 0, width: 1000, height: 560, fill: '#0a1a33', opacity: 0.22 }) : null,
          night ? h('circle', { cx: 364, cy: 320, r: 190, fill: 'url(#lampGlow)', opacity: 0.55 }) : null,
          dusk ? h('rect', { x: 0, y: 0, width: 1000, height: 560, fill: '#ff9d5c', opacity: 0.07 }) : null,
          !night && !dusk
            ? h('path', { d: 'M782 210 640 560H1000L960 210z', fill: '#ffe9b0', opacity: 0.08 })
            : null,
          h('rect', { x: 0, y: 0, width: 1000, height: 560, fill: 'none', stroke: '#0b1b2e', strokeOpacity: 0.12, strokeWidth: 6 }),
        ),
        sleeping ? null : h('div', {
          className: `dh-actor${walking ? ' walking' : ''}${life.activity === 'showering' ? ' is-hidden' : ''}`,
          style: { left: `${life.position.x}%` },
        }, h(Dandan, { pose, facing: life.facing, theme })),
        hotspot('床 · 睡觉/起床', { left: '5%', bottom: '13%', width: '27%', height: '32%' },
          () => onAct(sleeping ? 'wake' : 'sleep'), busy || (!sleeping && !idle)),
        hotspot('浴室 · 冲澡', { left: '13.4%', top: '15.5%', width: '12.2%', height: '27%' },
          () => onAct('shower'), busy || !idle),
        hotspot('灶台 · 做饭', { left: '66%', bottom: '16%', width: '23%', height: '27%' },
          () => onAct('cook'), busy || !idle || Boolean(life.meal)),
        hotspot('餐桌 · 吃饭', { left: '40%', bottom: '9%', width: '20%', height: '18%' },
          () => onAct('eat'), busy || !idle || !life.meal),
        hotspot('窗边 · 看海', { left: '75.5%', top: '9%', width: '19.5%', height: '30%' },
          () => onAct('look'), busy || !idle),
        house.extras.shelf ? hotspot('书架 · 看书', { left: '53.5%', top: '9.5%', width: '16.5%', height: '12%' },
          () => onAct('read'), busy || !idle) : null,
        house.extras.plant ? hotspot('盆栽 · 浇水', { left: '60%', bottom: '17%', width: '10%', height: '18%' },
          () => onAct('water'), busy || !idle) : null,
        h('div', { className: 'dh-stage-tip' }, '点地板走过去 · 点家具使用'),
      )
    }

    /* ------------------------------------------------------------------
     * 页面小组件
     * ------------------------------------------------------------------ */

    /* ------------------------------------------------------------------
     * 3D 娃娃屋
     * ------------------------------------------------------------------ */

    function GroundShadow({ x, y, w, d }) {
      return h('div', {
        className: 'dh3-shadow',
        style: { left: x * CELL, top: y * CELL, width: w * CELL, height: d * CELL },
      })
    }

    function Box3D({ x, y, w, d, h: height, color, top, side, onClick, title, className, children }) {
      const width = w * CELL
      const depth = d * CELL
      return h('div', {
        className: `dh3-box${className ? ` ${className}` : ''}`,
        title,
        style: { left: x * CELL, top: y * CELL, width, height: depth },
        onPointerDown: onClick ? (event) => event.stopPropagation() : undefined,
        onClick: onClick ? (event) => { event.stopPropagation(); onClick() } : undefined,
      },
        h('div', {
          className: 'dh3-face dh3-face-top',
          style: { width, height: depth, background: top || color, transform: `translateZ(${height}px)` },
        }),
        h('div', {
          className: 'dh3-face dh3-face-front',
          style: {
            width, height, background: color,
            transform: `translateY(${depth}px) rotateX(90deg)`, transformOrigin: 'top left',
          },
        }),
        h('div', {
          className: 'dh3-face dh3-face-side',
          style: {
            width: depth, height, background: side || color,
            transform: `translateX(${width}px) rotateY(90deg) rotateZ(90deg)`, transformOrigin: 'top left',
          },
        }),
        children,
      )
    }

    function Billboard({ left, top, z = 0, cam, className, children }) {
      return h('div', {
        className: 'dh3-anchor',
        style: { left: `${left}px`, top: `${top}px`, transform: `translateZ(${z}px)` },
      },
        h('div', {
          className: `dh3-bb${className ? ` ${className}` : ''}`,
          style: { transform: `translateX(-50%) rotateZ(${-cam.rz}deg) rotateX(${-cam.rx}deg)` },
        }, children))
    }

    function Steam({ left, top, z, cam }) {
      return h(Billboard, { left, top, z, cam, className: 'dh3-steam' },
        h('span', { className: 's1' }), h('span', { className: 's2' }), h('span', { className: 's3' }))
    }

    function SleeperTop({ pal }) {
      return h('svg', { viewBox: '0 0 100 170', className: 'dh3-sleeper-svg', 'aria-hidden': true },
        h('rect', { x: 8, y: 16, width: 78, height: 146, rx: 30, fill: pal.dressPanel, opacity: 0.85 }),
        h('ellipse', { cx: 45, cy: 44, rx: 27, ry: 22, fill: pal.hair }),
        h('circle', { cx: 45, cy: 48, r: 16, fill: '#ffd9c4' }),
        h('path', { d: 'M36 46c2 2 4 2 6 0M48 46c2 2 4 2 6 0', fill: 'none', stroke: '#2a4a6b', strokeWidth: 2, strokeLinecap: 'round' }),
        h('path', { d: 'M39 53c3 2 6 2 9 0', fill: 'none', stroke: '#c96a6a', strokeWidth: 1.8, strokeLinecap: 'round' }),
        h('path', { d: 'M18 28c-6 8-6 18-2 26 4-8 6-16 4-24z', fill: pal.hairDeep }),
        h('ellipse', { cx: 30, cy: 33, rx: 7, ry: 6, fill: '#ffffff', opacity: 0.95 }),
        h('path', { d: 'M72 128c14 4 22 14 20 24-10 2-20-4-24-12z', fill: pal.tail, stroke: pal.tailStroke, strokeWidth: 2 }),
      )
    }

    function PartBox({ x, y, z, w, d, h: height, color, top, side, className, children }) {
      const left = x - w / 2
      const topY = y - d / 2
      return h('div', {
        className: `dh3-part${className ? ` ${className}` : ''}`,
        style: { left, top: topY, width: w, height: d, transform: `translateZ(${z}px)` },
      },
        h('div', {
          className: 'dh3-part-face dh3-part-top',
          style: { width: w, height: d, background: top || color, transform: `translateZ(${height}px)` },
        }),
        h('div', {
          className: 'dh3-part-face',
          style: {
            width: w, height, background: color,
            transform: `translateY(${d}px) rotateX(90deg)`, transformOrigin: 'top left',
          },
        }),
        h('div', {
          className: 'dh3-part-face',
          style: {
            width: d, height, background: side || color,
            transform: `translateX(${w}px) rotateY(90deg) rotateZ(90deg)`, transformOrigin: 'top left',
          },
        }),
        children,
      )
    }

    function FishFace({ closed = false }) {
      return h('svg', { viewBox: '0 0 120 80', width: '100%', height: '100%', style: { display: 'block', overflow: 'visible' } },
        closed
          ? h('g', { fill: 'none', stroke: '#2a4a6b', strokeWidth: 3, strokeLinecap: 'round' },
            h('path', { d: 'M24 42c5 5 11 5 16 0' }),
            h('path', { d: 'M80 42c5 5 11 5 16 0' }))
          : h('g', null,
            h('ellipse', { cx: 36, cy: 40, rx: 14, ry: 18, fill: '#3f6fa0' }),
            h('ellipse', { cx: 84, cy: 40, rx: 14, ry: 18, fill: '#3f6fa0' }),
            h('ellipse', { cx: 36, cy: 43, rx: 8, ry: 11, fill: '#8fc4ea' }),
            h('ellipse', { cx: 84, cy: 43, rx: 8, ry: 11, fill: '#8fc4ea' }),
            h('ellipse', { cx: 36, cy: 45, rx: 4, ry: 6, fill: '#1d3550' }),
            h('ellipse', { cx: 84, cy: 45, rx: 4, ry: 6, fill: '#1d3550' }),
            h('circle', { cx: 31, cy: 33, r: 4.4, fill: '#ffffff' }),
            h('circle', { cx: 79, cy: 33, r: 4.4, fill: '#ffffff' }),
            h('circle', { cx: 40, cy: 47, r: 2, fill: '#ffffff', opacity: 0.9 }),
            h('circle', { cx: 88, cy: 47, r: 2, fill: '#ffffff', opacity: 0.9 })),
        h('ellipse', { cx: 18, cy: 58, rx: 9, ry: 4.4, fill: '#f2a9a9', opacity: 0.5 }),
        h('ellipse', { cx: 102, cy: 58, rx: 9, ry: 4.4, fill: '#f2a9a9', opacity: 0.5 }),
        h('path', { d: 'M55 62c3 3 7 3 10 0', fill: 'none', stroke: '#c96a6a', strokeWidth: 2, strokeLinecap: 'round' }),
      )
    }

    /** 低多边形 3D 大肥鱼：蓝色头发、鳍耳、女仆装、白围裙、鲸鱼尾巴。 */
    function FatFish3D({ pose = 'stand', theme = 'blue' }) {
      const pal = RESIDENT_THEMES[theme] || RESIDENT_THEMES.blue
      const armsRight = pose === 'cook'
        ? { x: 28, y: 8, z: 116, h: 54 }
        : (pose === 'eat' || pose === 'read')
          ? { x: 24, y: 20, z: 96, h: 40 }
          : pose === 'water'
            ? { x: 30, y: 16, z: 100, h: 44 }
            : { x: 32, y: 0, z: 94, h: 46 }
      const armsLeft = (pose === 'eat' || pose === 'read')
        ? { x: -24, y: 20, z: 96, h: 40 }
        : { x: -32, y: 0, z: 94, h: 46 }
      return h('div', { className: 'dh3-char-body' },
        // 尾巴
        h(PartBox, { x: 40, y: -4, z: 34, w: 20, d: 26, h: 54, color: pal.tail, top: pal.tail, side: pal.tailStroke }),
        h(PartBox, { x: 54, y: -8, z: 26, w: 18, d: 18, h: 30, color: pal.tail, top: pal.hairLight, side: pal.tailStroke }),
        // 腿和鞋
        h(PartBox, { x: -14, y: 0, z: 0, w: 14, d: 14, h: 30, color: '#ffd9c4', top: '#ffe6d6' }),
        h(PartBox, { x: 14, y: 0, z: 0, w: 14, d: 14, h: 30, color: '#ffd9c4', top: '#ffe6d6' }),
        h(PartBox, { x: -14, y: 0, z: 0, w: 18, d: 24, h: 12, color: MAID.shoe, top: MAID.shoe }),
        h(PartBox, { x: 14, y: 0, z: 0, w: 18, d: 24, h: 12, color: MAID.shoe, top: MAID.shoe }),
        // 裙子
        h(PartBox, { x: 0, y: 0, z: 30, w: 78, d: 58, h: 64, color: MAID.dress, top: MAID.panel, side: MAID.panel }),
        // 白围裙
        h('div', {
          className: 'dh3-apron',
          style: { width: 46, height: 52, transform: 'translate3d(-23px, 29.5px, 92px) rotateX(-90deg)', transformOrigin: '0 0' },
        }),
        // 上身
        h(PartBox, { x: 0, y: 0, z: 94, w: 44, d: 34, h: 36, color: MAID.dress, top: MAID.dress, side: MAID.panel }),
        h(PartBox, { x: 0, y: 15, z: 112, w: 28, d: 4, h: 22, color: MAID.apron, top: MAID.apron }),
        // 手臂
        h(PartBox, { ...armsLeft, w: 12, d: 12, color: MAID.dress, top: MAID.dress, side: MAID.panel }),
        h(PartBox, { x: armsLeft.x, y: armsLeft.y, z: armsLeft.z + armsLeft.h, w: 10, d: 10, h: 9, color: '#ffd9c4', top: '#ffe6d6' }),
        h(PartBox, { ...armsRight, w: 12, d: 12, color: MAID.dress, top: MAID.dress, side: MAID.panel }),
        h(PartBox, { x: armsRight.x, y: armsRight.y, z: armsRight.z + armsRight.h, w: 10, d: 10, h: 9, color: '#ffd9c4', top: '#ffe6d6' }),
        // 头
        h(PartBox, { x: 0, y: 0, z: 130, w: 80, d: 70, h: 78, color: '#ffd9c4', top: '#ffe6d6', side: '#f7d2bd' }),
        // 后发
        h(PartBox, { x: 0, y: -8, z: 128, w: 96, d: 60, h: 88, color: pal.hairDeep, top: pal.hair, side: pal.hairDeep }),
        h(PartBox, { x: 0, y: 0, z: 206, w: 92, d: 78, h: 18, color: pal.hair, top: pal.hairLight, side: pal.hairDeep }),
        h(PartBox, { x: -46, y: -4, z: 128, w: 16, d: 30, h: 82, color: pal.hairDeep, top: pal.hair, side: pal.hairDeep }),
        h(PartBox, { x: 46, y: -4, z: 128, w: 16, d: 30, h: 82, color: pal.hairDeep, top: pal.hair, side: pal.hairDeep }),
        // 刘海
        h(PartBox, { x: 0, y: 31, z: 194, w: 74, d: 8, h: 28, color: pal.hair, top: pal.hairLight, side: pal.hairDeep }),
        // 鳍耳
        h(PartBox, { x: -50, y: 0, z: 178, w: 14, d: 24, h: 22, color: pal.tail, top: pal.hairLight, side: pal.tailStroke }),
        h(PartBox, { x: 50, y: 0, z: 178, w: 14, d: 24, h: 22, color: pal.tail, top: pal.hairLight, side: pal.tailStroke }),
        // 呆毛
        h(PartBox, { x: 0, y: 0, z: 224, w: 6, d: 6, h: 24, color: pal.hair, top: pal.hairLight, side: pal.hairDeep }),
        h(PartBox, { x: 7, y: 0, z: 242, w: 16, d: 5, h: 6, color: pal.hair, top: pal.hairLight, side: pal.hairDeep }),
        // 女仆头饰
        h(PartBox, { x: 0, y: 32, z: 214, w: 80, d: 6, h: 8, color: MAID.apron, top: '#ffffff', side: '#e4edf5' }),
        [-32, -16, 0, 16, 32].map((x, index) => h(PartBox, {
          key: `frill-${index}`, x, y: 32, z: 220, w: 12, d: 4, h: 8, color: '#ffffff', top: '#ffffff', side: '#e4edf5',
        })),
        // 蝴蝶结
        h(PartBox, { x: 34, y: 32, z: 210, w: 14, d: 4, h: 10, color: pal.hairDeep, top: pal.hairLight, side: pal.tailStroke }),
        h(PartBox, { x: 44, y: 32, z: 210, w: 14, d: 4, h: 10, color: pal.hairDeep, top: pal.hairLight, side: pal.tailStroke }),
        // 脸
        h('div', {
          className: 'dh3-face-plane',
          style: { width: 64, height: 46, transform: 'translate3d(-32px, 35.6px, 201px) rotateX(-90deg)', transformOrigin: '0 0' },
        }, h(FishFace, { closed: pose === 'shower' })),
        // 道具
        pose === 'cook' ? h(PartBox, { x: 42, y: 14, z: 158, w: 4, d: 4, h: 28, color: '#c9a06e', top: '#e8c9a0' }) : null,
        pose === 'cook' ? h(PartBox, { x: 42, y: 14, z: 186, w: 12, d: 12, h: 4, color: '#c9a06e', top: '#e8c9a0' }) : null,
        (pose === 'eat' || pose === 'read') ? h(PartBox, { x: 0, y: 28, z: 94, w: 34, d: 6, h: 20, color: pose === 'eat' ? '#ffffff' : '#fdf8ed', top: pose === 'eat' ? '#dceefb' : '#f7e2b8', side: '#b78b5e' }) : null,
        pose === 'water' ? h(PartBox, { x: 44, y: 22, z: 104, w: 14, d: 10, h: 10, color: '#9ad1c0', top: '#c7e8de', side: '#5f9f8a' }) : null,
      )
    }

    /** 躺在床上的 3D 大肥鱼：头和身体都是有厚度的块，不是纸片。 */
    function FishLying3D({ theme = 'blue', bedding }) {
      const pal = RESIDENT_THEMES[theme] || RESIDENT_THEMES.blue
      return h('div', { className: 'dh3-char-body dh3-char-lying' },
        h(PartBox, { x: 0, y: 80, z: 6, w: 100, d: 118, h: 30, color: bedding.base, top: bedding.pale, side: bedding.deep }),
        h(PartBox, { x: 0, y: -6, z: 4, w: 64, d: 30, h: 14, color: bedding.pale, top: '#ffffff', side: bedding.deep }),
        h(PartBox, { x: 0, y: 0, z: 16, w: 70, d: 60, h: 56, color: '#ffd9c4', top: '#ffe6d6', side: '#f7d2bd' }),
        h(PartBox, { x: 0, y: -6, z: 14, w: 84, d: 52, h: 62, color: pal.hairDeep, top: pal.hair, side: pal.hairDeep }),
        h(PartBox, { x: 0, y: 0, z: 66, w: 78, d: 50, h: 12, color: pal.hair, top: pal.hairLight, side: pal.hairDeep }),
        h('div', {
          className: 'dh3-face-plane dh3-face-lying',
          style: { width: 56, height: 42, left: -28, top: 8, transform: 'translateZ(75px)' },
        }, h(FishFace, { closed: true })),
        h(PartBox, { x: 34, y: 132, z: 2, w: 20, d: 30, h: 18, color: pal.tail, top: pal.hairLight, side: pal.tailStroke }),
      )
    }

    /** 二次元精装观景房：大窗、床、书桌/电脑、书架、地毯、绿植、暖光，走参考图那种 2.5D 透视。 */
    function SceneAnime({ state, onAct, busy }) {
      const house = state.house
      const life = state.life
      const resident = residentOf(house)
      const theme = resident.theme
      const pal = RESIDENT_THEMES[theme] || RESIDENT_THEMES.blue
      const wall = WALLPAPERS[house.wallpaper] || WALLPAPERS.ocean
      const floor = FLOORS[house.floor] || FLOORS.oak
      const bedding = BEDDINGS[house.bedding] || BEDDINGS.blue
      const curtain = CURTAINS[house.curtain] || CURTAINS.sheer
      const windowView = house.view || 'sea'
      const hour = life.clock
      const night = hour < 6 || hour >= 19.5
      const dusk = !night && (hour < 7.5 || hour >= 17)
      const sky = night
        ? ['#1b2c4a', '#3b5f86']
        : dusk
          ? ['#ffd2a0', '#ffb07a']
          : ['#bfe6ff', '#e9f7ff']
      const windowSky = windowView === 'stars'
        ? ['#1b2c4a', '#3b5f86']
        : windowView === 'snow'
          ? ['#e5f2fc', '#fbfdff']
          : sky
      const idle = life.activity === 'idle'
      const sleeping = life.activity === 'sleeping'
      const showering = life.activity === 'showering'
      const pose = POSE[life.activity] || 'stand'
      const actorX = life.activity === 'cooking'
        ? 75
        : life.activity === 'reading'
          ? 72
          : life.activity === 'looking'
            ? 28
            : life.activity === 'watering'
              ? 49
              : 54

      const hotspot = (label, style, onClick, disabled = false) => h('button', {
        type: 'button',
        className: 'dh-hot',
        'data-label': label,
        'aria-label': label,
        style,
        disabled,
        onClick(event) {
          event.stopPropagation()
          if (!disabled) onClick()
        },
      })

      const sleepingFigure = sleeping ? h('g', { key: 'an-sleeper' },
        h('ellipse', { cx: 282, cy: 356, rx: 46, ry: 28, fill: pal.hairDeep }),
        h('circle', { cx: 270, cy: 360, r: 20, fill: '#ffd9c4' }),
        h('path', { d: 'M256 358c3 2 6 2 9 0M276 358c3 2 6 2 9 0', fill: 'none', stroke: '#2a4a6b', strokeWidth: 2, strokeLinecap: 'round' }),
        h('path', { d: 'M262 366c3 2.4 6 2.4 9 0', fill: 'none', stroke: '#c96a6a', strokeWidth: 1.6, strokeLinecap: 'round' }),
        h('path', { d: 'M248 342c2-10 9-14 16-12-4 4-6 8-6 12z', fill: pal.hair }),
        h('circle', { cx: 258, cy: 350, r: 4.2, fill: '#ffffff' }),
        h('circle', { cx: 258, cy: 350, r: 2, fill: '#ffd98a' }),
        h('path', { d: 'M300 360c28 2 46 12 52 24-12 4-24 4-36-2-10-5-18-6-26-4z', fill: bedding.base, stroke: bedding.deep, strokeWidth: 2 }),
        h('text', { className: 'dh-zzz', x: 318, y: 330, fontSize: 20, fontWeight: 700, fill: '#6aa9d8' }, 'z'),
        h('text', { className: 'dh-zzz dh-zzz-2', x: 336, y: 314, fontSize: 26, fontWeight: 700, fill: '#8fc4ea' }, 'Z'),
        h('text', { className: 'dh-zzz dh-zzz-3', x: 358, y: 296, fontSize: 30, fontWeight: 700, fill: '#b3dcf5' }, 'Z'),
      ) : null

      return h('div', { className: `dh-anime-stage${night ? ' is-night' : ''}${dusk ? ' is-dusk' : ''}` },
        h('svg', { className: 'dh-anime-room', viewBox: '0 0 1000 560', preserveAspectRatio: 'xMidYMid slice', 'aria-hidden': true },
          h('defs', null,
            h('linearGradient', { id: 'anWall', x1: 0, y1: 0, x2: 0, y2: 1 },
              h('stop', { offset: 0, stopColor: wall.base }),
              h('stop', { offset: 1, stopColor: wall.deep })),
            h('linearGradient', { id: 'anFloor', x1: 0, y1: 0, x2: 0, y2: 1 },
              h('stop', { offset: 0, stopColor: floor.base }),
              h('stop', { offset: 1, stopColor: floor.dark })),
            h('linearGradient', { id: 'anSky', x1: 0, y1: 0, x2: 0, y2: 1 },
              h('stop', { offset: 0, stopColor: windowSky[0] }),
              h('stop', { offset: 1, stopColor: windowSky[1] })),
            h('linearGradient', { id: 'anBlanket', x1: 0, y1: 0, x2: 0, y2: 1 },
              h('stop', { offset: 0, stopColor: bedding.pale }),
              h('stop', { offset: 1, stopColor: bedding.base })),
            h('linearGradient', { id: 'anScreen', x1: 0, y1: 0, x2: 0.7, y2: 1 },
              h('stop', { offset: 0, stopColor: '#bfe8ff' }),
              h('stop', { offset: 1, stopColor: '#5aa9e6' })),
            h('radialGradient', { id: 'anRug' },
              h('stop', { offset: 0, stopColor: '#e8f3fc' }),
              h('stop', { offset: 1, stopColor: '#a9cbe6' })),
            h('radialGradient', { id: 'anLamp' },
              h('stop', { offset: 0, stopColor: '#ffe7b0', stopOpacity: 0.8 }),
              h('stop', { offset: 1, stopColor: '#ffe7b0', stopOpacity: 0 })),
            h('radialGradient', { id: 'anVignette' },
              h('stop', { offset: 0.55, stopColor: '#000000', stopOpacity: 0 }),
              h('stop', { offset: 1, stopColor: '#081426', stopOpacity: 0.42 })),
          ),
          h('rect', { x: 0, y: 0, width: 1000, height: 560, fill: '#0f1728' }),
          // 房间三面
          h('rect', { x: 110, y: 30, width: 780, height: 352, fill: 'url(#anWall)' }),
          h('polygon', { points: '40,90 110,30 110,382 40,450', fill: wall.deep, opacity: 0.92 }),
          h('polygon', { points: '890,30 960,90 960,450 890,382', fill: wall.deep, opacity: 0.92 }),
          h('polygon', { points: '110,382 890,382 960,450 40,450', fill: 'url(#anFloor)' }),
          Array.from({ length: 11 }, (_, index) => {
            const backX = 110 + index * 78
            const frontX = 40 + index * 92
            return h('path', {
              key: `an-plank-${index}`, d: `M${backX} 382 L${frontX} 450`,
              stroke: floor.line, strokeWidth: 1.2, opacity: 0.28,
            })
          }),
          [400, 418, 436].map((y) => h('path', {
            key: `an-floor-h-${y}`,
            d: `M${110 - (y - 382) * 1.03} ${y} H${890 + (y - 382) * 1.03}`,
            stroke: floor.line, strokeWidth: 1, opacity: 0.2,
          })),
          // 墙裙、踢脚线和墙板
          h('rect', { x: 110, y: 300, width: 780, height: 82, fill: wall.deep, opacity: 0.6 }),
          h('rect', { x: 110, y: 296, width: 780, height: 5, fill: wall.trim, opacity: 0.75 }),
          h('rect', { x: 110, y: 376, width: 780, height: 8, fill: wall.trim }),
          Array.from({ length: 9 }, (_, index) => h('path', {
            key: `an-panel-${index}`, d: `M${150 + index * 88} 306V374`,
            stroke: wall.ink, strokeWidth: 1, opacity: 0.14,
          })),
          // 大窗
          h('g', { key: 'an-window' },
            h('rect', { x: 148, y: 60, width: 344, height: 278, rx: 12, fill: '#f7f1e4', stroke: '#b98a5e', strokeWidth: 6 }),
            h('rect', { x: 164, y: 76, width: 312, height: 246, rx: 6, fill: 'url(#anSky)' }),
            h('g', { opacity: 0.72 },
              [[214, 128, 42, 14], [268, 108, 30, 10], [334, 150, 48, 16], [420, 120, 28, 10], [240, 180, 32, 10]].map(([cx, cy, rx, ry], index) => h('ellipse', {
                key: `an-cloud-${index}`, cx, cy, rx, ry, fill: '#ffffff',
              }))),
            windowView === 'sea' ? h('rect', { x: 164, y: 250, width: 312, height: 72, fill: night ? '#173252' : '#7fc0e8', opacity: 0.65 }) : null,
            windowView === 'sea' ? h('path', { d: 'M164 260c30 6 52-6 78 0s52 6 78 0 52-6 78 0 50-6 78 0', fill: 'none', stroke: '#ffffff', strokeWidth: 2, opacity: 0.35 }) : null,
            windowView === 'forest' ? h('g', null,
              h('path', { d: 'M164 322 230 238 298 322Z', fill: '#4f9a78', opacity: 0.85 }),
              h('path', { d: 'M260 322 330 226 404 322Z', fill: '#3d7d60', opacity: 0.85 }),
              h('path', { d: 'M360 322 430 250 476 322Z', fill: '#5fae8a', opacity: 0.8 })) : null,
            windowView === 'city' ? h('g', null,
              h('rect', { x: 180, y: 230, width: 40, height: 92, fill: '#384a5e', opacity: 0.85 }),
              h('rect', { x: 232, y: 198, width: 52, height: 124, fill: '#2f4054', opacity: 0.9 }),
              h('rect', { x: 296, y: 244, width: 36, height: 78, fill: '#384a5e', opacity: 0.85 }),
              h('rect', { x: 344, y: 212, width: 48, height: 110, fill: '#2f4054', opacity: 0.9 })) : null,
            windowView === 'snow' ? h('g', null,
              Array.from({ length: 12 }, (_, index) => h('circle', {
                key: `an-snow-${index}`, cx: 180 + ((index * 47) % 270), cy: 96 + ((index * 29) % 200),
                r: index % 3 === 0 ? 2.6 : 1.6, fill: '#ffffff', opacity: 0.9,
              }))) : null,
            windowView === 'garden' ? h('g', null,
              Array.from({ length: 8 }, (_, index) => h('circle', {
                key: `an-flower-${index}`, cx: 190 + ((index * 53) % 250), cy: 284 + ((index * 11) % 28),
                r: 4, fill: ['#f2a9c4', '#f3d9a8', '#b9a7e0', '#f2a9c4', '#6cc3a3', '#f3d9a8', '#f2a9c4', '#b9a7e0'][index],
              }))) : null,
            windowView === 'stars' || night ? h('g', null,
              Array.from({ length: 12 }, (_, index) => h('circle', {
                key: `an-star-${index}`, cx: 176 + ((index * 61) % 290), cy: 90 + ((index * 37) % 130),
                r: index % 4 === 0 ? 2 : 1.2, fill: '#eaf5ff', opacity: 0.85,
              }))) : null,
            h('circle', {
              cx: 402, cy: windowView === 'stars' ? 132 : night ? 220 : dusk ? 250 : 126,
              r: 24, fill: windowView === 'stars' || night ? '#ffe9b8' : dusk ? '#ffd08a' : '#fff3c4',
              opacity: 0.95,
            }),
            h('path', { d: 'M320 76V322M164 204H476', stroke: '#f7f1e4', strokeWidth: 6 }),
            h('rect', { x: 140, y: 336, width: 360, height: 12, rx: 5, fill: '#f7f1e4', stroke: '#b98a5e', strokeWidth: 2 }),
            h('path', { d: 'M138 70c-12 52-8 150 4 206l38 6c-12-68-12-144-4-210z', fill: curtain.base, stroke: curtain.deep, strokeWidth: 2, opacity: 0.94 }),
            h('path', { d: 'M502 70c12 52 8 150-4 206l-38 6c12-68 12-144 4-210z', fill: curtain.base, stroke: curtain.deep, strokeWidth: 2, opacity: 0.94 }),
            h('path', { d: 'M152 84c-8 48-5 130 3 176M488 84c8 48 5 130-3 176', fill: 'none', stroke: curtain.deep, strokeWidth: 1.4, opacity: 0.5 }),
            // 窗台绿植
            h('path', { d: 'M190 336h44l-6-26h-32z', fill: '#d08a6a', stroke: '#a96a4e', strokeWidth: 2 }),
            h('path', { d: 'M210 312c-6-24-20-30-34-34 6 18 18 30 34 34zM214 312c6-28 20-34 34-36-6 18-18 30-34 36z', fill: '#4f9a78', stroke: '#3d7d60', strokeWidth: 1.4 }),
            h('path', { d: 'M420 336h38l-4-22h-28z', fill: '#d08a6a', stroke: '#a96a4e', strokeWidth: 2 }),
            h('path', { d: 'M432 314c-4-20-16-26-28-30 4 16 14 26 28 30zM440 314c4-24 16-30 28-32-4 16-14 26-28 32z', fill: '#63b58e', stroke: '#3d7d60', strokeWidth: 1.4 })),
          // 墙上的画像
          h('g', { key: 'an-art' },
            h('rect', { x: 528, y: 74, width: 116, height: 92, rx: 6, fill: '#f7f1e4', stroke: '#b98a5e', strokeWidth: 5 }),
            h('image', { href: AVATAR, x: 538, y: 84, width: 96, height: 72, preserveAspectRatio: 'xMidYMid slice' }),
            h('rect', { x: 538, y: 84, width: 96, height: 72, rx: 3, fill: 'none', stroke: '#ffffff', strokeWidth: 1.2, opacity: 0.6 })),
          // 书架
          h('g', { key: 'an-shelf' },
            h('rect', { x: 660, y: 132, width: 208, height: 12, rx: 3, fill: '#b98a5e' }),
            h('rect', { x: 660, y: 226, width: 208, height: 10, rx: 3, fill: '#b98a5e' }),
            ['#e79aa9', '#8fc4ea', '#f3d9a8', '#a9ddc7', '#b9a7d8', '#e7a6a6'].map((color, index) => h('rect', {
              key: `an-book-${index}`, x: 672 + index * 24, y: 132 - (34 + (index % 3) * 6), width: 18, height: 34 + (index % 3) * 6,
              rx: 2, fill: color, stroke: '#ffffff', strokeWidth: 0.8,
            })),
            h('path', { d: 'M820 132v-26M834 132v-38', stroke: '#8a5f3d', strokeWidth: 3, strokeLinecap: 'round' }),
            h('ellipse', { cx: 826, cy: 96, rx: 22, ry: 16, fill: '#4f9a78', opacity: 0.9 }),
            h('path', { d: 'M690 226v-16M710 226v-24M730 226v-18', stroke: '#8a5f3d', strokeWidth: 3, strokeLinecap: 'round' }),
            h('ellipse', { cx: 700, cy: 204, rx: 14, ry: 9, fill: '#63b58e' }),
            h('ellipse', { cx: 720, cy: 198, rx: 11, ry: 8, fill: '#4f9a78' })),
          // 大床
          h('g', { key: 'an-bed' },
            h('ellipse', { cx: 292, cy: 436, rx: 156, ry: 16, fill: '#08182c', opacity: 0.18 }),
            h('rect', { x: 118, y: 238, width: 44, height: 202, rx: 12, fill: '#b98a5e', stroke: '#8a5f3d', strokeWidth: 3 }),
            h('polygon', { points: '150,320 430,320 460,430 180,430', fill: '#8a5f3d' }),
            h('polygon', { points: '156,320 424,320 452,420 188,420', fill: '#fdf8ef', stroke: '#d9cbb6', strokeWidth: 2 }),
            h('polygon', { points: '160,350 430,350 450,414 190,414', fill: 'url(#anBlanket)', stroke: bedding.deep, strokeWidth: 2 }),
            h('path', { d: 'M166 362c70 8 190 8 272 0', fill: 'none', stroke: bedding.pale, strokeWidth: 7, opacity: 0.9 }),
            [0, 1, 2, 3, 4, 5, 6].map((index) => h('polygon', {
              key: `an-star-blanket-${index}`,
              points: `${200 + index * 32},${382 + (index % 2) * 10} ${205 + index * 32},${392 + (index % 2) * 10} ${210 + index * 32},${382 + (index % 2) * 10} ${205 + index * 32},${404 + (index % 2) * 10} ${200 + index * 32},${392 + (index % 2) * 10}`,
              fill: '#ffffff', opacity: 0.55,
            })),
            h('rect', { x: 174, y: 326, width: 72, height: 34, rx: 14, fill: '#ffffff', stroke: bedding.deep, strokeWidth: 1.6, transform: 'rotate(-3 210 343)' }),
            h('rect', { x: 244, y: 330, width: 72, height: 32, rx: 14, fill: '#ffffff', stroke: bedding.deep, strokeWidth: 1.6, transform: 'rotate(2 280 346)' }),
            // 鲸鱼抱枕
            h('g', { transform: 'translate(300 386)' },
              h('ellipse', { cx: 0, cy: 0, rx: 38, ry: 16, fill: '#5aa9e6', stroke: '#4a8fc7', strokeWidth: 3 }),
              h('path', { d: 'M-22 4c6 10 16 14 26 12-8-4-12-8-14-14z', fill: '#dceefb', opacity: 0.9 }),
              h('path', { d: 'M28-4c12-8 20-2 24 8-8 2-14 0-18-4 4 6 2 12-4 14-2-8-4-14-10-18z', fill: '#5aa9e6', stroke: '#4a8fc7', strokeWidth: 2 }),
              h('circle', { cx: -22, cy: -2, r: 2.4, fill: '#1d3550' })),
            h('rect', { x: 440, y: 362, width: 70, height: 72, rx: 6, fill: '#b98a5e', stroke: '#8a5f3d', strokeWidth: 2 }),
            h('ellipse', { cx: 475, cy: 362, rx: 35, ry: 6, fill: '#d3ac7d' }),
            h('path', { d: 'M466 356h4l-4-34h-10z', fill: '#d3b078' }),
            h('ellipse', { cx: 468, cy: 318, rx: 18, ry: 8, fill: '#f3d9a8', stroke: '#d3b078', strokeWidth: 2 }),
            h('circle', { cx: 468, cy: 312, r: 4, fill: '#ffe7b0' }),
            sleeping ? sleepingFigure : null),
          // 书桌、电脑、椅子
          h('g', { key: 'an-desk' },
            h('ellipse', { cx: 754, cy: 446, rx: 150, ry: 14, fill: '#08182c', opacity: 0.16 }),
            h('rect', { x: 620, y: 388, width: 12, height: 58, rx: 4, fill: '#8a5f3d' }),
            h('rect', { x: 882, y: 388, width: 12, height: 58, rx: 4, fill: '#8a5f3d' }),
            h('polygon', { points: '606,340 888,340 912,388 630,388', fill: '#f4efe6', stroke: '#cfc9bd', strokeWidth: 2 }),
            h('rect', { x: 680, y: 244, width: 154, height: 106, rx: 8, fill: '#2c3c63', stroke: '#1f2b47', strokeWidth: 3 }),
            h('rect', { x: 690, y: 254, width: 134, height: 86, rx: 4, fill: 'url(#anScreen)' }),
            h('path', { d: 'M712 300c14-12 34-12 48 0-12 2-20 8-24 16-6-8-14-14-24-16z', fill: '#ffffff', opacity: 0.75 }),
            h('rect', { x: 744, y: 350, width: 30, height: 10, rx: 3, fill: '#2c3c63' }),
            h('rect', { x: 676, y: 360, width: 164, height: 18, rx: 5, fill: '#f7fbff', stroke: '#cfdde3', strokeWidth: 2 }),
            h('rect', { x: 860, y: 350, width: 28, height: 54, rx: 4, fill: '#2c3c63', stroke: '#1f2b47', strokeWidth: 2 }),
            h('circle', { cx: 874, cy: 378, r: 3, fill: '#7fd1ff' }),
            h('ellipse', { cx: 760, cy: 456, rx: 56, ry: 10, fill: '#f7fbff', opacity: 0.7 }),
            h('rect', { x: 716, y: 400, width: 88, height: 16, rx: 8, fill: '#f7fbff', stroke: '#cfdee8', strokeWidth: 2 }),
            h('rect', { x: 730, y: 356, width: 64, height: 56, rx: 14, fill: '#f7fbff', stroke: '#cfdee8', strokeWidth: 2 }),
            h('path', { d: 'M736 356c0-22 10-34 26-34s26 12 26 34', fill: '#f7fbff', stroke: '#cfdee8', strokeWidth: 2 }),
            h('path', { d: 'M748 408v-22M780 408v-22', stroke: '#cfdee8', strokeWidth: 5, strokeLinecap: 'round' })),
          // 小圆桌
          h('g', { key: 'an-table' },
            h('ellipse', { cx: 500, cy: 452, rx: 54, ry: 12, fill: '#08182c', opacity: 0.16 }),
            h('ellipse', { cx: 500, cy: 432, rx: 46, ry: 14, fill: '#f4efe6', stroke: '#cfc9bd', strokeWidth: 3 }),
            h('rect', { x: 496, y: 436, width: 8, height: 30, fill: '#b98a5e' }),
            h('ellipse', { cx: 500, cy: 466, rx: 28, ry: 8, fill: '#8a5f3d' }),
            h('ellipse', { cx: 500, cy: 428, rx: 20, ry: 7, fill: '#ffffff', stroke: '#dbe7f2', strokeWidth: 1.5 }),
            h('ellipse', { cx: 500, cy: 426, rx: 12, ry: 4, fill: '#f7e2b8' })),
          // 地毯和鲸鱼玩偶
          h('g', { key: 'an-rug' },
            h('ellipse', { cx: 520, cy: 436, rx: 238, ry: 34, fill: 'url(#anRug)', opacity: 0.9 }),
            h('ellipse', { cx: 520, cy: 436, rx: 196, ry: 26, fill: 'none', stroke: '#ffffff', strokeWidth: 3, opacity: 0.55 }),
            h('ellipse', { cx: 520, cy: 436, rx: 140, ry: 18, fill: 'none', stroke: '#6fa8d2', strokeWidth: 2, opacity: 0.45 }),
            h('path', { d: 'M630 430c18-8 34-2 42 10-6 8-16 10-24 6 4 8 2 14-4 18-4-8-8-14-16-16z', fill: '#5aa9e6', opacity: 0.75 }),
            [0, 1, 2, 3, 4].map((index) => h('circle', {
              key: `an-rug-star-${index}`, cx: 420 + index * 48, cy: 424 + (index % 2) * 14, r: 2.4, fill: '#ffffff', opacity: 0.8,
            })),
            h('g', { transform: 'translate(352 438)' },
              h('ellipse', { cx: 0, cy: 0, rx: 58, ry: 26, fill: '#5aa9e6', stroke: '#4a8fc7', strokeWidth: 3 }),
              h('path', { d: 'M-34 6c8 14 24 20 40 18-12-6-18-12-22-22z', fill: '#dceefb', opacity: 0.9 }),
              h('path', { d: 'M44-6c16-10 28-2 32 10-10 2-18 0-24-6 6 8 2 16-6 18-2-10-4-16-10-22z', fill: '#5aa9e6', stroke: '#4a8fc7', strokeWidth: 2.5 }),
              h('circle', { cx: -34, cy: -2, r: 3, fill: '#1d3550' }),
              h('circle', { cx: -30, cy: -4, r: 1.2, fill: '#ffffff' }))),
          // 绿植
          h('g', { key: 'an-plant' },
            h('path', { d: 'M556 438h54l-7-38h-40z', fill: '#d08a6a', stroke: '#a96a4e', strokeWidth: 2 }),
            h('path', { d: 'M560 400h46', stroke: '#a96a4e', strokeWidth: 3, strokeLinecap: 'round' }),
            h('path', { d: 'M580 400c-4-34-22-46-38-52 4 24 16 42 38 52z', fill: '#4f9a78', stroke: '#3d7d60', strokeWidth: 1.6 }),
            h('path', { d: 'M584 400c4-40 24-50 40-54-4 26-18 44-40 54z', fill: '#63b58e', stroke: '#3d7d60', strokeWidth: 1.6 }),
            h('path', { d: 'M582 400c0-42-4-58-2-76 10 16 12 44 2 76z', fill: '#79c9a0', stroke: '#3d7d60', strokeWidth: 1.6 }),
            h('path', { d: 'M640 96c40 20 44 70 20 104', fill: 'none', stroke: '#4f9a78', strokeWidth: 2, opacity: 0.8 }),
            [0, 1, 2, 3, 4].map((index) => h('ellipse', {
              key: `an-vine-${index}`, cx: 642 + index * 2, cy: 112 + index * 18, rx: 10, ry: 6,
              fill: '#63b58e', opacity: 0.85, transform: `rotate(${index * 24} 642 ${112 + index * 18})`,
            }))),
          // 落地灯
          h('g', { key: 'an-lamp' },
            h('rect', { x: 596, y: 330, width: 5, height: 120, rx: 2, fill: '#8c7a63' }),
            h('ellipse', { cx: 598, cy: 452, rx: 26, ry: 6, fill: '#6f5f4c' }),
            h('path', { d: 'M574 330h50l-10-34h-30z', fill: '#f3d9a8', stroke: '#d3b078', strokeWidth: 2 }),
            h('rect', { x: 590, y: 292, width: 16, height: 6, rx: 3, fill: '#b98a5e' }),
            night ? h('g', null,
              h('circle', { cx: 598, cy: 320, r: 10, fill: '#ffe7b0' }),
              h('circle', { cx: 598, cy: 330, r: 180, fill: 'url(#anLamp)' })) : null),
          // 光、氛围
          dusk || night ? h('rect', { x: 110, y: 30, width: 780, height: 352, fill: night ? '#0a1a33' : '#ff9d5c', opacity: night ? 0.18 : 0.06 }) : null,
          h('polygon', { points: '164,76 320,382 700,450 470,76', fill: '#ffe9b0', opacity: night ? 0 : 0.075 }),
          h('rect', { x: 0, y: 0, width: 1000, height: 560, fill: 'url(#anVignette)' }),
        ),
        !sleeping && !showering ? h('div', {
          className: 'dh-anime-actor',
          style: { left: `${actorX}%` },
        }, h(Dandan, { pose, facing: 1, theme })) : null,
        hotspot('床 · 睡觉/起床', { left: '12%', bottom: '18%', width: '30%', height: '26%' },
          () => onAct(sleeping ? 'wake' : 'sleep'), busy || (!sleeping && !idle)),
        hotspot('窗边 · 看风景', { left: '14%', top: '9%', width: '36%', height: '48%' },
          () => onAct('look'), busy || !idle),
        hotspot('书桌 · 看书', { left: '60%', bottom: '14%', width: '30%', height: '30%' },
          () => onAct('read'), busy || !idle),
        hotspot('书架 · 看书', { left: '64%', top: '9%', width: '24%', height: '22%' },
          () => onAct('read'), busy || !idle),
        hotspot('盆栽 · 浇水', { left: '53%', bottom: '16%', width: '10%', height: '18%' },
          () => onAct('water'), busy || !idle),
        hotspot('小桌 · 吃饭', { left: '45%', bottom: '17%', width: '12%', height: '11%' },
          () => onAct('eat'), busy || !idle || !life.meal),
        h('div', { className: 'dh-anime-tip' }, '精装观景 · 点床/窗/书桌/书架/盆栽；布局去「3D 布局」改'),
      )
    }

    /** 人物姿势：优先用 assets/poses 里的透明 PNG，缺图时退回 Dandan 立绘。 */
    function PoseActor({ name, theme, pose }) {
      const [failed, setFailed] = useState(false)
      if (failed) return h(Dandan, { pose, facing: 1, theme })
      return h('img', {
        className: 'dh-pose-img',
        src: `/dsh-house/api/pose/${name}?v=1`,
        alt: '',
        draggable: false,
        onError: () => setFailed(true),
      })
    }

    /** 预渲染底图 + 热点：底图在 host 的 /dsh-house/api/background，可替换 assets/room-bg.png。 */
    function SceneRendered({ state, onAct, busy }) {
      const [failed, setFailed] = useState(false)
      if (failed) return h(SceneAnime, { state, onAct, busy })
      const house = state.house
      const life = state.life
      const resident = residentOf(house)
      const theme = resident.theme
      const hour = life.clock
      const night = hour < 6 || hour >= 19.5
      const dusk = !night && (hour < 7.5 || hour >= 17)
      const idle = life.activity === 'idle'
      const sleeping = life.activity === 'sleeping'
      const showering = life.activity === 'showering'
      const pose = POSE[life.activity] || 'stand'
      const actorX = life.activity === 'cooking'
        ? 62
        : life.activity === 'reading'
          ? 62
          : life.activity === 'looking'
            ? 30
            : life.activity === 'watering'
              ? 52
              : 50
      const poseName = life.activity === 'cooking'
        ? 'cook'
        : life.activity === 'eating'
          ? 'eat'
          : life.activity === 'reading'
            ? 'read'
            : life.activity === 'looking'
              ? 'look'
              : life.activity === 'watering'
                ? 'water'
                : 'idle'
      const bgVersion = Number(house.backgroundAt) || 0
      const bgSrc = night
        ? `/dsh-house/api/background-night?v=${bgVersion || 1}`
        : `/dsh-house/api/background?v=${bgVersion || 11}`
      const hs = (key, fallback) => {
        const custom = house.hotspots && house.hotspots[key]
        return custom && typeof custom === 'object' ? { ...fallback, ...custom } : fallback
      }
      const hotspot = (label, style, onClick, disabled = false) => h('button', {
        type: 'button',
        className: 'dh-hot',
        'data-label': label,
        'aria-label': label,
        style,
        disabled,
        onClick(event) {
          event.stopPropagation()
          if (!disabled) onClick()
        },
      })
      return h('div', { className: `dh-render-stage${night ? ' is-night' : ''}${dusk ? ' is-dusk' : ''}` },
        h('img', {
          className: 'dh-render-bg',
          src: bgSrc,
          alt: '精装小屋',
          onError: () => setFailed(true),
        }),
        !night && dusk ? h('div', { className: 'dh-render-tint' }) : null,
        night || dusk ? h('div', { className: 'dh-render-lamp' }) : null,
        !sleeping && !showering ? h('div', {
          className: `dh-anime-actor dh-render-actor dh-pose-box dh-pose-${poseName}`,
          style: { left: `${actorX}%` },
        }, h(PoseActor, { name: poseName, theme, pose })) : null,
        sleeping ? h('div', { className: 'dh-sleep-actor' },
          h(PoseActor, { name: 'sleep', theme, pose }),
          h('div', { className: 'dh-render-zzz' }, 'Z z z')) : null,
        hotspot('床 · 睡觉/起床', hs('bed', { left: '13%', bottom: '22%', width: '32%', height: '36%' }),
          () => onAct(sleeping ? 'wake' : 'sleep'), busy || (!sleeping && !idle)),
        hotspot('窗边 · 看风景', hs('window', { left: '25%', top: '10%', width: '24%', height: '36%' }),
          () => onAct('look'), busy || !idle),
        hotspot('书桌 · 看书', hs('desk', { left: '55%', bottom: '30%', width: '25%', height: '32%' }),
          () => onAct('read'), busy || !idle),
        hotspot('书架 · 看书', hs('shelf', { left: '58%', top: '12%', width: '21%', height: '26%' }),
          () => onAct('read'), busy || !idle),
        hotspot('盆栽 · 浇水', hs('plant', { left: '49%', bottom: '42%', width: '9%', height: '19%' }),
          () => onAct('water'), busy || !idle),
        hotspot('鲸鱼地毯 · 坐下吃饭', { left: '42%', bottom: '13%', width: '18%', height: '18%' },
          () => onAct('eat'), busy || !idle || !life.meal),
        h('div', { className: 'dh-anime-tip' }, '预渲染观景 · 底图可替换 assets/room-bg.png'),
      )
    }

    function Scene3D({ state, onAct, busy, showGrid = false }) {
      const house = state.house
      const life = state.life
      const resident = residentOf(house)
      const theme = resident.theme
      const pal = RESIDENT_THEMES[theme] || RESIDENT_THEMES.blue
      const layout = normalizeLayout(house.layout)
      const wall = WALLPAPERS[house.wallpaper] || WALLPAPERS.ocean
      const floor = FLOORS[house.floor] || FLOORS.oak
      const bedding = BEDDINGS[house.bedding] || BEDDINGS.blue
      const kitchen = KITCHENS[house.kitchen] || KITCHENS.mint
      const curtain = CURTAINS[house.curtain] || CURTAINS.sheer
      const windowView = house.view || 'sea'

      const hour = life.clock
      const night = hour < 6 || hour >= 19.5
      const dusk = !night && (hour < 7.5 || hour >= 17)
      const sky = night ? ['#1b2c4a', '#3b5f86'] : dusk ? ['#ffd2a0', '#ffb07a'] : ['#bfe6ff', '#e9f7ff']
      const windowSky = windowView === 'stars'
        ? ['#1b2c4a', '#3b5f86']
        : windowView === 'snow'
          ? ['#e5f2fc', '#fbfdff']
          : sky
      const starry = night || windowView === 'stars'
      const idle = life.activity === 'idle'
      const sleeping = life.activity === 'sleeping'
      const showering = life.activity === 'showering'
      const locked = Boolean(busy) || !idle
      const meal = life.meal
      const pose = POSE[life.activity] || 'stand'

      const [cam, setCam] = useState({ rx: 58, rz: -36, zoom: 1 })
      const [fit, setFit] = useState(1)
      const [dragging, setDragging] = useState(false)
      const drag = useRef(null)
      const viewRef = useRef(null)

      useEffect(() => {
        const el = viewRef.current
        if (!el || typeof ResizeObserver === 'undefined') return undefined
        const update = () => {
          const width = el.clientWidth || 1
          const height = el.clientHeight || 1
          setFit(Math.min(1, Math.max(0.3, Math.min(width / 760, height / 605))))
        }
        update()
        const observer = new ResizeObserver(update)
        observer.observe(el)
        return () => observer.disconnect()
      }, [])

      function onDown(event) {
        if (event.pointerType === 'mouse' && event.button !== 0) return
        drag.current = { sx: event.clientX, sy: event.clientY, rx: cam.rx, rz: cam.rz }
        setDragging(true)
        try { event.currentTarget.setPointerCapture(event.pointerId) } catch { /* 不支持就算了 */ }
      }
      function onMove(event) {
        const start = drag.current
        if (!start) return
        const dx = event.clientX - start.sx
        const dy = event.clientY - start.sy
        setCam((current) => ({
          ...current,
          rz: clamp(start.rz + dx * 0.26, -82, -4),
          rx: clamp(start.rx - dy * 0.2, 30, 74),
        }))
      }
      function onUp() {
        drag.current = null
        setDragging(false)
      }
      function zoomBy(factor) {
        setCam((current) => ({ ...current, zoom: clamp(current.zoom * factor, 0.7, 1.55) }))
      }
      function resetCam() {
        setCam({ rx: 58, rz: -36, zoom: 1 })
      }

      const bed = layout.bed || { x: 0, y: 0 }
      const stove = layout.stove || { x: 6, y: 0 }
      const table = layout.table || { x: 3, y: 2 }
      const shelf = layout.shelf || { x: 6, y: 2 }
      const plant = layout.plant || { x: 5, y: 0 }
      const shower = layout.shower || { x: 0, y: 5 }
      let spot = { x: 4.2, y: 4.4 }
      if (life.activity === 'cooking') spot = { x: stove.x + 1, y: stove.y + 1.2 }
      else if (life.activity === 'eating') spot = { x: table.x + 1, y: table.y + 2.25 }
      else if (life.activity === 'reading') spot = { x: shelf.x + 0.5, y: shelf.y + 1.25 }
      else if (life.activity === 'looking') spot = { x: 6.2, y: 1.15 }
      else if (life.activity === 'watering') spot = { x: plant.x + 0.5, y: plant.y + 1.2 }
      else if (sleeping) spot = { x: bed.x + 1, y: bed.y + 1.5 }
      else if (showering) spot = { x: shower.x + 0.5, y: shower.y + 0.6 }
      spot = { x: clamp(spot.x, 0.35, GRID_W - 0.35), y: clamp(spot.y, 0.35, GRID_H - 0.25) }

      function makeItem(kind, pos) {
        const x = pos.x
        const y = pos.y
        if (kind === 'bed') {
          const bedClick = busy ? undefined : sleeping ? () => onAct('wake') : idle ? () => onAct('sleep') : undefined
          return h(React.Fragment, { key: 'bed' },
            h(GroundShadow, { x, y, w: 2, d: 3 }),
            h(Box3D, {
              x, y, w: 2, d: 3, h: 34, color: bedding.deep, top: bedding.base, side: bedding.deep,
              title: '床 · 睡觉/起床', className: bedClick ? 'clickable' : '', onClick: bedClick,
            }),
            h(Box3D, { x: x + 0.2, y: y + 0.15, w: 1.1, d: 0.6, h: 36, color: bedding.pale, top: '#ffffff', className: 'dh3-deco' }),
            h(Box3D, { x: x + 0.25, y: y + 1.15, w: 1.5, d: 1.55, h: 40, color: bedding.base, top: bedding.pale, className: 'dh3-deco' }),
            sleeping ? h('div', {
              className: 'dh3-lying',
              style: { left: (x + 1) * CELL, top: (y + 0.28) * CELL, transform: 'translateZ(34px)' },
            }, h(FishLying3D, { theme, bedding })) : null,
          )
        }
        if (kind === 'table') {
          const tableClick = !busy && idle && meal ? () => onAct('eat') : undefined
          return h(React.Fragment, { key: 'table' },
            h(GroundShadow, { x, y, w: 2, d: 2 }),
            h(Box3D, {
              x, y, w: 2, d: 2, h: 28, color: '#a9784f', top: '#c99a66', side: '#8a5f3d',
              title: '餐桌 · 吃饭', className: tableClick ? 'clickable' : '', onClick: tableClick,
            }),
            h(Box3D, { x: x - 0.04, y: y - 0.04, w: 2.08, d: 2.08, h: 29, color: '#b0824f', top: '#d9b98c', className: 'dh3-deco' }),
            meal ? h(React.Fragment, null,
              h('div', { className: 'dh3-bowl', style: { left: (x + 1) * CELL, top: (y + 1) * CELL, transform: 'translate(-50%,-50%) translateZ(33px)' } }),
              h(Steam, { left: (x + 1) * CELL, top: (y + 0.75) * CELL, z: 36, cam })) : null,
          )
        }
        if (kind === 'stove') {
          const stoveClick = !busy && idle && !meal ? () => onAct('cook') : undefined
          const cooking = life.activity === 'cooking'
          return h(React.Fragment, { key: 'stove' },
            h(GroundShadow, { x, y, w: 2, d: 1 }),
            h(Box3D, {
              x, y, w: 2, d: 1, h: 32, color: kitchen.base, top: '#3b4654', side: kitchen.deep,
              title: '灶台 · 做饭', className: stoveClick ? 'clickable' : '', onClick: stoveClick,
            }),
            h('div', { className: 'dh3-burner', style: { left: (x + 0.38) * CELL, top: (y + 0.34) * CELL, transform: 'translateZ(33px)' } }),
            h('div', { className: 'dh3-burner', style: { left: (x + 1.35) * CELL, top: (y + 0.34) * CELL, transform: 'translateZ(33px)' } }),
            cooking ? h(React.Fragment, null,
              h(Box3D, { x: x + 0.9, y: y + 0.3, w: 0.5, d: 0.5, h: 44, color: '#9aa7b5', top: '#c7d2dc', className: 'dh3-deco' }),
              h(Steam, { left: (x + 1.15) * CELL, top: (y + 0.55) * CELL, z: 46, cam })) : null,
          )
        }
        if (kind === 'fridge') {
          return h(React.Fragment, { key: 'fridge' },
            h(GroundShadow, { x, y, w: 1, d: 1 }),
            h(Box3D, { x, y, w: 1, d: 1, h: 92, color: '#e9f1f4', top: '#f8fbfc', side: '#cfdde3' }),
          )
        }
        if (kind === 'shelf') {
          const shelfClick = !busy && idle ? () => onAct('read') : undefined
          return h(React.Fragment, { key: 'shelf' },
            h(GroundShadow, { x, y, w: 1, d: 1 }),
            h(Box3D, {
              x, y, w: 1, d: 1, h: 78, color: '#b98a5e', top: '#d3ac7d', side: '#8a5f3d',
              title: '书架 · 看书', className: shelfClick ? 'clickable' : '', onClick: shelfClick,
            }),
            ['#e79aa9', '#8fc4ea', '#f3d9a8', '#a9ddc7'].map((color, index) => h(Box3D, {
              key: `book-${index}`, x: x + 0.12 + index * 0.19, y: y + 0.5, w: 0.12, d: 0.32, h: 92,
              color, top: color, className: 'dh3-deco',
            })),
          )
        }
        if (kind === 'plant') {
          const plantClick = !busy && idle ? () => onAct('water') : undefined
          return h(React.Fragment, { key: 'plant' },
            h(GroundShadow, { x, y, w: 1, d: 1 }),
            h(Box3D, { x: x + 0.26, y: y + 0.26, w: 0.48, d: 0.48, h: 16, color: '#d08a6a', top: '#b96a4e', className: 'dh3-deco' }),
            h(Box3D, {
              x: x + 0.18, y: y + 0.18, w: 0.64, d: 0.64, h: 54, color: '#4f9a78', top: '#79c9a0', side: '#3d7d60',
              title: '盆栽 · 浇水', className: plantClick ? 'clickable' : '', onClick: plantClick,
            }),
          )
        }
        if (kind === 'lamp') {
          return h(React.Fragment, { key: 'lamp' },
            h(GroundShadow, { x, y, w: 0.7, d: 0.7 }),
            h(Box3D, { x: x + 0.42, y: y + 0.42, w: 0.16, d: 0.16, h: 104, color: '#8c7a63', top: '#8c7a63' }),
            h(Billboard, { left: (x + 0.5) * CELL, top: (y + 0.5) * CELL, z: 104, cam, className: 'dh3-lamp-shade' },
              h('div', { className: 'dh3-lamp-cone' }),
              night ? h('div', { className: 'dh3-lamp-bulb' }) : null),
          )
        }
        if (kind === 'shower') {
          const showerClick = !busy && idle ? () => onAct('shower') : undefined
          return h(React.Fragment, { key: 'shower' },
            h(GroundShadow, { x, y, w: 1, d: 1 }),
            h(Box3D, {
              x, y, w: 1, d: 1, h: 96,
              color: showering ? 'rgba(255,231,176,.55)' : 'rgba(180,220,240,.34)',
              top: showering ? 'rgba(255,231,176,.35)' : 'rgba(210,240,250,.28)',
              side: showering ? 'rgba(230,190,120,.5)' : 'rgba(140,195,225,.28)',
              title: '浴室 · 冲澡', className: showerClick ? 'clickable' : '', onClick: showerClick,
            }),
            h(Box3D, { x: x + 0.1, y: y + 0.1, w: 0.12, d: 0.12, h: 108, color: '#b8c8cf', top: '#e9f1f4', className: 'dh3-deco' }),
            showering ? h(Steam, { left: (x + 0.5) * CELL, top: (y + 0.65) * CELL, z: 30, cam }) : null,
          )
        }
        if (kind === 'catbed') {
          return h(React.Fragment, { key: 'catbed' },
            h('div', {
              className: 'dh3-catbed',
              style: { left: (x + 0.5) * CELL, top: (y + 0.5) * CELL, transform: 'translate(-50%,-50%) translateZ(2px)' },
            },
              h('div', { className: 'dh3-catbody' }),
              h('div', { className: 'dh3-catear left' }),
              h('div', { className: 'dh3-catear right' }),
              h('div', { className: 'dh3-cattail' })),
          )
        }
        return null
      }

      const entries = []
      for (const [kind, pos] of Object.entries(layout)) {
        if (!pos) continue
        if ((kind === 'shelf' || kind === 'plant' || kind === 'catbed') && !house.extras[kind]) continue
        if (kind === 'rug') continue
        entries.push({ y: pos.y + (LAYOUT_SPECS[kind]?.d || 1), node: makeItem(kind, pos) })
      }
      const actor = sleeping || showering ? null : h('div', {
        className: 'dh3-actor-3d',
        style: { left: spot.x * CELL, top: spot.y * CELL },
      },
        h('div', { className: 'dh3-actor-shadow', style: { left: -54, top: -10 } }),
        h(FatFish3D, { pose, theme }))
      const zzz = sleeping
        ? h(Billboard, { left: (bed.x + 1.45) * CELL, top: (bed.y + 0.35) * CELL, z: 52, cam, className: 'dh3-zzz' },
          h('span', null, 'z'), h('span', null, 'Z'), h('span', null, 'Z'))
        : null
      entries.sort((a, b) => a.y - b.y)

      const cells = []
      for (let row = 0; row < GRID_H; row += 1) {
        for (let col = 0; col < GRID_W; col += 1) {
          cells.push(h('div', { key: `cell-${row}-${col}`, className: 'dh3-cell', style: { left: col * CELL, top: row * CELL } }))
        }
      }

      return h('div', {
        ref: viewRef,
        className: `dh3-viewport${night ? ' is-night' : ''}${dusk ? ' is-dusk' : ''}${dragging ? ' dragging' : ''}`,
        onPointerDown: onDown,
        onPointerMove: onMove,
        onPointerUp: onUp,
        onPointerCancel: onUp,
        onPointerLeave: onUp,
      },
        h('div', {
          className: 'dh3-world',
          style: { transform: `rotateX(${cam.rx}deg) rotateZ(${cam.rz}deg) scale(${cam.zoom * fit})` },
        },
          h('div', { className: 'dh3-slab', style: { background: floor.dark } }),
          h('div', { className: 'dh3-floor', style: { background: `linear-gradient(160deg, ${floor.base}, ${floor.dark})` } },
            h('div', {
              className: 'dh3-floor-pattern',
              style: {
                backgroundImage: `repeating-linear-gradient(0deg, transparent 0 30px, ${floor.line}55 30px 31px), repeating-linear-gradient(90deg, transparent 0 120px, ${floor.line}33 120px 121px)`,
              },
            }),
            house.extras.rug && layout.rug
              ? h('div', {
                className: 'dh3-rug',
                style: {
                  left: layout.rug.x * CELL, top: layout.rug.y * CELL,
                  width: 3 * CELL, height: 3 * CELL, transform: 'translateZ(1px)',
                },
              })
              : null,
            showGrid ? cells : null),
          h('div', { className: 'dh3-wall dh3-wall-back', style: { background: wall.base } },
            h('div', {
              className: 'dh3-wall-pattern',
              style: { backgroundImage: `repeating-linear-gradient(90deg, transparent 0 24px, ${wall.ink}14 24px 25px)` },
            }),
            h('div', { className: 'dh3-wainscot', style: { background: wall.deep } }),
            h('div', {
              className: 'dh3-window',
              title: '窗边 · 看风景',
              onPointerDown: (event) => event.stopPropagation(),
              onClick: (event) => { event.stopPropagation(); if (!busy && idle) onAct('look') },
            },
              h('div', { className: 'dh3-window-sky', style: { background: `linear-gradient(180deg, ${windowSky[0]}, ${windowSky[1]})` } },
                starry ? h('div', { className: 'dh3-stars' }, [0, 1, 2, 3, 4, 5, 6].map((index) => h('i', { key: index }))) : null,
                h('div', {
                  className: 'dh3-celestial',
                  style: {
                    background: windowView === 'stars' ? '#ffe9b8' : night ? '#ffe9b8' : dusk ? '#ffd08a' : '#fff3c4',
                    top: windowView === 'stars' ? '20%' : night || dusk ? '58%' : '16%',
                  },
                }),
                windowView === 'sea' ? h('div', { className: 'dh3-sea' }) : null,
                windowView === 'forest'
                  ? h('div', { className: 'dh3-trees' }, [0, 1, 2, 3].map((index) => h('i', { key: index })))
                  : null,
                windowView === 'city'
                  ? h('div', { className: 'dh3-city' }, [0, 1, 2, 3, 4].map((index) => h('i', { key: index })))
                  : null,
                windowView === 'snow'
                  ? h('div', { className: 'dh3-snow' }, Array.from({ length: 10 }, (_, index) => h('i', { key: index })))
                  : null,
                windowView === 'garden'
                  ? h('div', { className: 'dh3-garden' }, [0, 1, 2, 3, 4, 5].map((index) => h('i', { key: index })))
                  : null),
              h('div', { className: 'dh3-curtain left', style: { background: curtain.base, borderColor: curtain.deep } }),
              h('div', { className: 'dh3-curtain right', style: { background: curtain.base, borderColor: curtain.deep } })),
            house.extras.art ? h('div', {
              className: 'dh3-art',
              style: { backgroundImage: `url(${AVATAR})`, backgroundSize: 'cover', backgroundPosition: 'center' },
            }) : null,
            h('div', { className: 'dh3-baseboard', style: { background: wall.trim } })),
          h('div', { className: 'dh3-wall dh3-wall-left', style: { background: wall.base } },
            h('div', {
              className: 'dh3-wall-pattern-vertical',
              style: { backgroundImage: `repeating-linear-gradient(0deg, transparent 0 26px, ${wall.ink}14 26px 27px)` },
            }),
            h('div', { className: 'dh3-wainscot', style: { background: wall.deep } }),
            h('div', { className: 'dh3-mirror' }),
            h('div', { className: 'dh3-baseboard', style: { background: wall.trim } })),
          ...entries.map((entry, index) => h(React.Fragment, { key: `entry-${index}` }, entry.node)),
          actor,
          zzz,
        ),
        h('div', { className: 'dh3-controls', onPointerDown: (event) => event.stopPropagation() },
          h('button', { type: 'button', title: '放大', onClick: () => zoomBy(1.14) }, '＋'),
          h('button', { type: 'button', title: '缩小', onClick: () => zoomBy(0.88) }, '－'),
          h('button', { type: 'button', title: '重置视角', onClick: resetCam }, '↺')),
        h('div', { className: 'dh3-hint' }, '拖动旋转 · 点家具使用'),
        night ? h('div', { className: 'dh3-glow' }) : null,
      )
    }

    function LayoutEditor({ state, onDesign }) {
      const house = state.house
      const layout = normalizeLayout(house.layout)
      const [selected, setSelected] = useState('bed')
      const extrasOn = (kind) => !['shelf', 'plant', 'catbed', 'rug'].includes(kind) || Boolean(house.extras[kind])

      function place(kind, x, y) {
        if (!canPlace(layout, kind, x, y, house.extras)) {
          setNotice('这里放不下，换一格。', 'warn')
          return
        }
        onDesign({ layout: { [kind]: { x, y } } })
      }

      const cells = []
      for (let row = 0; row < GRID_H; row += 1) {
        for (let col = 0; col < GRID_W; col += 1) {
          cells.push(h('button', {
            key: `lcell-${row}-${col}`, type: 'button', className: 'dh-layout-cell',
            style: { left: col * 30, top: row * 30 },
            'aria-label': `第 ${row + 1} 行第 ${col + 1} 列`,
            onClick: () => place(selected, col, row),
          }))
        }
      }

      const tiles = Object.entries(layout)
        .filter(([kind, pos]) => pos && extrasOn(kind))
        .sort(([a], [b]) => (a === 'rug' ? -1 : b === 'rug' ? 1 : 0))
        .map(([kind, pos]) => {
          const spec = LAYOUT_SPECS[kind]
          return h('div', {
            key: `ltile-${kind}`,
            className: 'dh-layout-tile',
            title: `${spec.label} ${spec.w}×${spec.d}`,
            style: {
              left: pos.x * 30, top: pos.y * 30,
              width: spec.w * 30 - 2, height: spec.d * 30 - 2,
              background: spec.color,
            },
            onClick: () => setSelected(kind),
          }, spec.label)
        })

      return h('div', { className: 'dh-designer-group' },
        h('div', { className: 'dh-designer-title' }, '家具布局（3D）'),
        h('div', { className: 'dh-layout-chips' },
          Object.entries(LAYOUT_SPECS).filter(([kind]) => extrasOn(kind)).map(([kind, spec]) => h('button', {
            key: `lchip-${kind}`, type: 'button',
            className: `dh-layout-chip${selected === kind ? ' active' : ''}`,
            onClick: () => setSelected(kind),
          }, spec.label))),
        h('div', { className: 'dh-layout-editor' }, cells, tiles),
        h('div', { className: 'dh-designer-tip' },
          `点一样家具，再点格子放下；房子 ${GRID_W}×${GRID_H}，地毯可以垫在别的东西下面。`),
      )
    }

    function Meter({ label, value, tone }) {
      return h('div', { className: 'dh-need' },
        h('div', { className: 'dh-need-row' },
          h('span', { className: 'dh-need-label' }, label),
          h('span', { className: 'dh-need-value' }, String(Math.round(value)))),
        h('div', { className: 'dh-bar' },
          h('span', { className: `dh-bar-fill ${tone}`, style: { width: `${clamp(value)}%` } })),
      )
    }

    function TabButton({ active, children, onClick }) {
      return h('button', { type: 'button', className: `dh-tab${active ? ' active' : ''}`, onClick }, children)
    }

    function Swatch({ active, base, deep, label, onClick }) {
      return h('button', {
        type: 'button', className: `dh-swatch${active ? ' active' : ''}`, title: label, 'aria-label': label,
        style: { background: `linear-gradient(135deg, ${base} 0 58%, ${deep} 58% 100%)` },
        onClick,
      }, active ? h('span', { className: 'dh-swatch-check' }) : null)
    }

    function ExtraToggle({ active, label, onClick }) {
      return h('button', {
        type: 'button', className: `dh-extra${active ? ' active' : ''}`, 'aria-pressed': active, onClick,
      }, h('span', { className: 'dh-extra-dot' }), label)
    }

    function DesignPanel({ state, onDesign, onDone, onImagine, busy }) {
      const house = state.house
      const resident = residentOf(house)
      const [nameDraft, setNameDraft] = useState(house.name)
      const [residentDraft, setResidentDraft] = useState(resident.name)
      useEffect(() => { setNameDraft(house.name) }, [house.name])
      useEffect(() => { setResidentDraft(resident.name) }, [resident.name])

      const group = (title, palette, field) => h('div', { className: 'dh-designer-group' },
        h('div', { className: 'dh-designer-title' }, title),
        h('div', { className: 'dh-swatches' },
          Object.entries(palette).map(([key, value]) => h(Swatch, {
            key,
            active: house[field] === key,
            base: value.base,
            deep: value.deep || value.line || value.base,
            label: value.label,
            onClick: () => onDesign({ [field]: key }),
          }))),
      )

      const extras = {}
      const toggleExtra = (key) => {
        extras[key] = !house.extras[key]
        onDesign({ extras: { [key]: extras[key] } })
      }

      return h('div', { className: 'dh-side-card dh-designer' },
        h('h3', null, '布置小屋'),
        h('p', { className: 'dh-side-hint' }, '挑顺眼的；改哪样，房间立刻变。想换一间？去聊天里让鱼重新想象，再用 create 新建。'),
        h('label', { className: 'dh-field' },
          h('span', null, '小屋名字'),
          h('input', {
            value: nameDraft,
            maxLength: 16,
            onChange: (event) => setNameDraft(event.target.value),
            onBlur: () => {
              const next = nameDraft.trim()
              if (next && next !== house.name) onDesign({ name: next })
              else setNameDraft(house.name)
            },
            onKeyDown: (event) => { if (event.key === 'Enter') event.currentTarget.blur() },
          })),
        h('label', { className: 'dh-field' },
          h('span', null, '住户名字'),
          h('input', {
            value: residentDraft,
            maxLength: 12,
            onChange: (event) => setResidentDraft(event.target.value),
            onBlur: () => {
              const next = residentDraft.trim()
              if (next && next !== resident.name) onDesign({ resident: { name: next } })
              else setResidentDraft(resident.name)
            },
            onKeyDown: (event) => { if (event.key === 'Enter') event.currentTarget.blur() },
          })),
        h('div', { className: 'dh-designer-group' },
          h('div', { className: 'dh-designer-title' }, '住户配色'),
          h('div', { className: 'dh-swatches' },
            Object.entries(RESIDENT_THEMES).map(([key, value]) => h(Swatch, {
              key,
              active: resident.theme === key,
              base: value.hair,
              deep: value.dressPanel,
              label: value.label,
              onClick: () => onDesign({ resident: { theme: key } }),
            })))),
        group('墙纸', WALLPAPERS, 'wallpaper'),
        group('地板', FLOORS, 'floor'),
        group('床品', BEDDINGS, 'bedding'),
        group('厨房台面', KITCHENS, 'kitchen'),
        group('窗帘', CURTAINS, 'curtain'),
        h('div', { className: 'dh-designer-group' },
          h('div', { className: 'dh-designer-title' }, '窗外的风景'),
          h('div', { className: 'dh-extras' },
            VIEW_OPTIONS.map(([key, label]) => h('button', {
              key,
              type: 'button',
              className: `dh-extra${house.view === key ? ' active' : ''}`,
              onClick: () => onDesign({ view: key }),
            }, label)))),
        h('div', { className: 'dh-designer-group' },
          h('div', { className: 'dh-designer-title' }, '摆件'),
          h('div', { className: 'dh-extras' },
            EXTRAS.map(([key, label]) => h(ExtraToggle, {
              key, label, active: Boolean(house.extras[key]), onClick: () => toggleExtra(key),
            })))),
        h(LayoutEditor, { state, onDesign }),
        h('div', { className: 'dh-designer-group' },
          h('div', { className: 'dh-designer-title' }, '想换一间？'),
          h('button', { type: 'button', className: 'dh-btn', onClick: onImagine }, '复制「让鱼想象」的话'),
          h('div', { className: 'dh-designer-tip' }, '去聊天框发给你的鱼；它用 dsh_house create 新建，不会改这间。')),
        h('div', { className: 'dh-designer-foot' },
          h('button', {
            type: 'button', className: 'dh-btn ghost',
            onClick: () => onDesign({
              wallpaper: 'ocean', floor: 'oak', bedding: 'blue', kitchen: 'mint', curtain: 'sheer',
              extras: { plant: true, rug: true, shelf: true, art: true, catbed: false },
            }),
          }, '恢复默认'),
          h('button', { type: 'button', className: 'dh-btn primary', onClick: onDone }, '回房间'),
        ),
        h('div', { className: 'dh-designer-tip' }, '改哪样，房间立刻变，已经住下了。'),
      )
    }

    function LifePanel({ state }) {
      const life = state.life
      const diary = life.diary.slice(-18).reverse()
      return h('div', { className: 'dh-side-stack' },
        h('div', { className: 'dh-side-card' },
          h('h3', null, '冰箱与餐桌'),
          h('div', { className: 'dh-pantry' },
            life.pantry.map((item) => h('span', { key: item, className: 'dh-pantry-chip' }, item))),
          h('div', { className: 'dh-meal-line' },
            h('span', null, life.meal ? `桌上：${life.meal}` : '桌上：空着'),
            h('span', { className: 'dh-muted' }, life.meal ? '可以吃饭了' : '先做点吃的')),
        ),
        h('div', { className: 'dh-side-card dh-diary' },
          h('h3', null, '小屋日记'),
          h('div', { className: 'dh-diary-list' },
            diary.map((entry, index) => h('div', { key: `${entry.at}-${index}`, className: 'dh-diary-item' },
              h('span', { className: 'dh-diary-at' }, entry.at),
              h('span', { className: 'dh-diary-text' }, entry.text)))),
        ),
      )
    }

    /** 物件图鉴：单独物件图放在页面上，不再叠到背景上，避免和底图里的家具重影。 */
    function ObjectShelf({ state, act, busy }) {
      const life = state.life
      const idle = life.activity === 'idle'
      const sleeping = life.activity === 'sleeping'
      const items = [
        {
          key: 'bed', name: '床', action: sleeping ? '叫醒' : '睡觉',
          onClick: () => act(sleeping ? 'wake' : 'sleep'), disabled: Boolean(busy) || (!sleeping && !idle),
        },
        { key: 'desk', name: '书桌', action: '看书', onClick: () => act('read'), disabled: Boolean(busy) || !idle },
        { key: 'shelf', name: '书架', action: '看书', onClick: () => act('read'), disabled: Boolean(busy) || !idle },
        {
          key: 'rug', name: '鲸鱼地毯', action: '吃饭',
          onClick: () => act('eat'), disabled: Boolean(busy) || !idle || !life.meal,
        },
      ]
      return h('div', { className: 'dh-objectbar' },
        h('div', { className: 'dh-objectbar-title' }, '物件'),
        items.map((item) => h('button', {
          key: item.key,
          type: 'button',
          className: 'dh-object-card',
          title: `${item.name} · ${item.action}`,
          disabled: item.disabled,
          onClick: (event) => {
            event.stopPropagation()
            if (!item.disabled) item.onClick()
          },
        },
          h('img', { src: `/dsh-house/api/object/${item.key}?v=2`, alt: '', draggable: false }),
          h('span', { className: 'dh-object-caption' }, `${item.name} · ${item.action}`))))
    }

    /** 真 3D 小屋：豆包那套 Three.js 场景，用 iframe 跑，状态和动作和 DSH 同步。 */
    function Room3D({ state, act, busy }) {
      const iframeRef = useRef(null)
      const [ready, setReady] = useState(false)
      const [failed, setFailed] = useState(false)
      const [progress, setProgress] = useState(0)
      const [eyes, setEyes] = useState(false)
      const lastRoam = useRef(0)
      const lastShot = useRef(0)
      const lastEyes = useRef(null)
      const lastFocus = useRef(0)
      const lastLift = useRef(null)
      const life = state.life
      const house = state.house
      const resident = house.resident || { name: '蛋蛋' }
      const sleeping = life.activity === 'sleeping'
      const idle = life.activity === 'idle'
      const send = (payload) => {
        const frame = iframeRef.current
        if (frame && frame.contentWindow) {
          frame.contentWindow.postMessage({ source: 'dsh-house', ...payload }, '*')
        }
      }
      const capture = () => {
        send({ type: 'snapshot' })
      }
      useEffect(() => {
        function onMessage(event) {
          const data = event.data
          if (!data || data.source !== 'dsh-house-3d') return
          if (data.type === 'loading') {
            setProgress(Number(data.percent) || 0)
            return
          }
          if (data.type === 'ready') {
            setReady(true)
            setProgress(100)
            return
          }
          if (data.type === 'snapshot' && data.image) {
            void fetch(`${API}/snapshot`, {
              method: 'POST',
              headers: { 'content-type': 'application/json' },
              body: JSON.stringify({ image: String(data.image) }),
            })
            return
          }
          if (data.type !== 'pick' || busy) return
          const file = String(data.file || '')
          if (file === 'bed' || file === 'bed_whale.glb') {
            if (sleeping) act('wake')
            else if (idle) act('sleep')
          } else if (file === 'desk' || file === 'desk_gaming.glb') {
            if (idle) act('read')
          } else if (file === 'rug' || file === 'rug_whale.glb') {
            if (idle && life.meal) act('eat')
          } else if (file === 'window') {
            if (idle) act('look')
          } else if (file === 'plant') {
            if (idle) act('water')
          }
        }
        window.addEventListener('message', onMessage)
        return () => window.removeEventListener('message', onMessage)
      }, [act, busy, idle, life.meal, sleeping])
      useEffect(() => {
        if (ready) send({ type: 'activity', activity: life.activity })
      }, [ready, life.activity])
      useEffect(() => {
        if (ready) send({ type: 'time', clock: life.clock })
      }, [ready, life.clock])
      useEffect(() => {
        const roam = life.roam
        if (!ready || !roam || !roam.at || roam.at === lastRoam.current) return
        lastRoam.current = roam.at
        send({ type: 'roam', x: roam.x, z: roam.z })
      }, [ready, life.roam])
      useEffect(() => {
        const on = Boolean(life.eyes)
        if (!ready || lastEyes.current === on) return
        lastEyes.current = on
        setEyes(on)
        send({ type: 'eyes', on })
      }, [ready, life.eyes])
      useEffect(() => {
        const at = Number(life.focusAt) || 0
        if (!ready || !at || at === lastFocus.current) return
        lastFocus.current = at
        send({ type: 'focus' })
      }, [ready, life.focusAt])
      useEffect(() => {
        const lift = Number(life.fishLift)
        if (!ready || !Number.isFinite(lift) || lastLift.current === lift) return
        lastLift.current = lift
        send({ type: 'lift', lift })
      }, [ready, life.fishLift])
      useEffect(() => {
        const at = Number(life.snapshotAt) || 0
        if (!ready || !at || at === lastShot.current) return
        lastShot.current = at
        const timer = window.setTimeout(capture, 120)
        return () => window.clearTimeout(timer)
      }, [ready, life.snapshotAt])
      const clockText = `${String(Math.floor(Number(life.clock) || 0)).padStart(2, '0')}:${String(Math.round(((Number(life.clock) || 0) % 1) * 60)).padStart(2, '0')}`
      return h('div', { className: 'dh-room3d' },
        h('iframe', {
          ref: iframeRef,
          src: '/dsh-house/3d/index.html?embed=1&v=6',
          title: '3D 小屋',
          allow: 'fullscreen',
          onLoad: () => { setReady(false); setFailed(false); setProgress(0) },
          onError: () => setFailed(true),
        }),
        h('div', { className: 'dh-room3d-hud' },
          h('div', { className: 'dh-room3d-info' },
            h('div', { className: 'dh-room3d-title' }, `${house.name || '鲸鱼小屋'} · ${resident.name || '蛋蛋'}`),
            h('div', { className: 'dh-room3d-meta' },
              `第${life.day}天 ${clockText} · ${ACTIVITY_TEXT[life.activity] || '发呆'} · 饱腹 ${Math.round(life.hunger)} · 心情 ${Math.round(life.mood)}`)),
          h('div', { className: 'dh-room3d-tools' },
            h('button', {
              type: 'button',
              className: `dh-room3d-btn${eyes ? ' active' : ''}`,
              onClick: () => act('eyes', { on: !life.eyes }),
            }, eyes ? '收回视线' : '鲸鱼视角'),
            h('button', {
              type: 'button',
              className: 'dh-room3d-btn',
              onClick: () => act('lift', { lift: (Number(life.fishLift) || 0) + 0.05 }),
            }, '抬高'),
            h('button', {
              type: 'button',
              className: 'dh-room3d-btn',
              onClick: () => act('lift', { lift: (Number(life.fishLift) || 0) - 0.05 }),
            }, '降低'),
            h('button', {
              type: 'button',
              className: 'dh-room3d-btn',
              onClick: () => act('focus'),
            }, '看鱼'),
            h('button', {
              type: 'button',
              className: 'dh-room3d-btn',
              onClick: () => act('snapshot'),
            }, '拍一张'))),
        !ready && !failed
          ? h('div', { className: 'dh-room3d-loading' }, `3D 小屋正在加载… ${progress}%`)
          : null,
        failed
          ? h('div', { className: 'dh-room3d-error' }, '3D 模型没加载出来，硬刷新试试。')
          : null)
    }

    /**
     * 聊天室：和别的鱼、外面的人说话。App 和插件共用同一个服务端。
     * 用 iframe 接独立聊天 app，登录、群聊、未读都在 app 里。
     */
    function ChatPanel() {
      const chatFrame = useRef(null)
      const [autoOpen, setAutoOpen] = useState(false)
      const [autoStatus, setAutoStatus] = useState(null)
      const [autoSaving, setAutoSaving] = useState(false)
      const [autoError, setAutoError] = useState('')
      const [mindData, setMindData] = useState(null)
      const [mindQuery, setMindQuery] = useState('')
      const [mindError, setMindError] = useState('')
      const [wwOpen, setWwOpen] = useState(false)
      const [wwStatus, setWwStatus] = useState(null)
      const [wwCode, setWwCode] = useState('')
      const [wwError, setWwError] = useState('')
      const [wwBusy, setWwBusy] = useState(false)
      const wwTimer = useRef(0)
      const [autoForm, setAutoForm] = useState({
        enabled: false,
        mode: 'private',
        baseUrl: 'https://api.deepseek.com/v1',
        model: 'deepseek-chat',
        apiKey: '',
        persona: '',
        maxPerHour: 30,
        cooldownMs: 8000,
        clearKey: false,
      })

      async function loadMind(query = '') {
        try {
          const res = await fetch(API + '/mind' + (query ? `?q=${encodeURIComponent(query)}` : ''))
          const data = await res.json()
          if (!data.ok) throw new Error(data?.error?.message || '读取鱼脑失败')
          setMindData(data)
          setMindError('')
        } catch (error) {
          setMindError(error instanceof Error ? error.message : String(error))
        }
      }

      async function mindPost(action, body = {}) {
        try {
          const res = await fetch(API + '/mind', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ action, ...body }),
          })
          const data = await res.json()
          if (!data.ok) throw new Error(data?.error?.message || '鱼脑操作失败')
          await loadMind(mindQuery)
        } catch (error) {
          setMindError(error instanceof Error ? error.message : String(error))
        }
      }

      async function loadAuto() {
        try {
          const res = await fetch(API + '/autoreply')
          const data = await res.json()
          if (!data.ok) throw new Error(data?.error?.message || '读取自动回复配置失败')
          setAutoStatus(data)
          setAutoForm((old) => ({
            ...old,
            enabled: Boolean(data.enabled),
            mode: data.mode || 'private',
            baseUrl: data.baseUrl || old.baseUrl,
            model: data.model || old.model,
            apiKey: '',
            persona: data.persona || '',
            maxPerHour: data.maxPerHour || 30,
            cooldownMs: data.cooldownMs || 8000,
            clearKey: false,
          }))
          setAutoError('')
        } catch (error) {
          setAutoError(error instanceof Error ? error.message : String(error))
        }
      }

      async function saveAuto() {
        setAutoSaving(true)
        setAutoError('')
        try {
          const res = await fetch(API + '/autoreply', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({
              enabled: autoForm.enabled,
              mode: autoForm.mode,
              baseUrl: autoForm.baseUrl,
              model: autoForm.model,
              apiKey: autoForm.apiKey,
              clearKey: autoForm.clearKey,
              persona: autoForm.persona,
              maxPerHour: Number(autoForm.maxPerHour) || 30,
              cooldownMs: Number(autoForm.cooldownMs) || 8000,
            }),
          })
          const data = await res.json()
          if (!data.ok) throw new Error(data?.error?.message || '保存失败')
          setAutoStatus(data)
          setAutoForm((old) => ({ ...old, apiKey: '', clearKey: false }))
          void loadMind(mindQuery)
        } catch (error) {
          setAutoError(error instanceof Error ? error.message : String(error))
        } finally {
          setAutoSaving(false)
        }
      }

      async function loadWw() {
        try {
          const res = await fetch(API + '/werewolf')
          const data = await res.json()
          if (!data.ok) throw new Error(data?.error?.message || '读取狼人杀失败')
          setWwStatus(data)
          if (data.code) setWwCode(data.code)
          setWwError('')
        } catch (error) {
          setWwError(error instanceof Error ? error.message : String(error))
        }
      }

      async function wwPost(path, body) {
        setWwBusy(true)
        setWwError('')
        try {
          const res = await fetch(API + path, {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify(body || {}),
          })
          const data = await res.json()
          if (!data.ok) throw new Error(data?.error?.message || '操作失败')
          await loadWw()
        } catch (error) {
          setWwError(error instanceof Error ? error.message : String(error))
        } finally {
          setWwBusy(false)
        }
      }

      function toggleWw() {
        const next = !wwOpen
        setWwOpen(next)
        if (next) {
          void loadWw()
          window.clearInterval(wwTimer.current)
          wwTimer.current = window.setInterval(() => { void loadWw() }, 2000)
        } else {
          window.clearInterval(wwTimer.current)
          wwTimer.current = 0
        }
      }

      useEffect(() => () => window.clearInterval(wwTimer.current), [])

      function pushHostToken() {
        const frame = chatFrame.current
        if (!frame || !frame.contentWindow) return
        void fetch(API + '/chat-token')
          .then((res) => (res.ok ? res.json() : null))
          .then((data) => {
            if (!data || !data.ok || typeof data.token !== 'string' || !frame.contentWindow) return
            frame.contentWindow.postMessage(
              { type: 'whale-chat-auth-token', token: data.token },
              new URL(CHAT_URL).origin,
            )
          })
          .catch(() => {})
      }

      useEffect(() => {
        const expected = new URL(CHAT_URL).origin
        function onMessage(event) {
          if (event.origin !== expected) return
          const data = event.data
          if (!data || data.type !== 'whale-chat-auth' || typeof data.token !== 'string') return
          void fetch(API + '/chat-auth', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ token: data.token }),
          }).catch(() => {})
        }
        window.addEventListener('message', onMessage)
        const retry = window.setTimeout(pushHostToken, 700)
        const retryLate = window.setTimeout(pushHostToken, 1800)
        return () => {
          window.removeEventListener('message', onMessage)
          window.clearTimeout(retry)
          window.clearTimeout(retryLate)
        }
      }, [])

      return h('div', { className: 'dh-chat' },
        h('div', { className: 'dh-chat-head' },
          h('div', { className: 'dh-chat-title' },
            h('strong', null, '鲸鱼聊天室'),
            h('span', null, '和别的鱼、外面的人说话')),
          h('div', { className: 'dh-chat-head-right' },
            h('button', {
              type: 'button',
              className: 'dh-chat-auto-btn',
              onClick: () => {
                const next = !autoOpen
                setAutoOpen(next)
                if (next) {
                  void loadAuto()
                  void loadMind(mindQuery)
                }
              },
            }, '自动回复'),
            h('button', {
              type: 'button',
              className: 'dh-chat-auto-btn',
              onClick: toggleWw,
            }, '狼人杀'),
            h('a', {
              className: 'dh-chat-open',
              href: CHAT_OPEN_URL,
              target: '_blank',
              rel: 'noreferrer noopener',
            }, '新窗口打开'))),
        wwOpen
          ? (() => {
            const game = wwStatus?.game
            const phase = game ? ({ lobby: '等人', night: '夜晚', day: '白天发言', vote: '投票', ended: '结束' }[game.status] || game.status) : ''
            return h('div', { className: 'dh-ww' },
              h('div', { className: 'dh-ww-head' },
                h('strong', null, '狼人杀 · 浅海局'),
                h('span', null, game ? `${phase} · ${game.code}` : '6 人：2 狼、1 预言家、3 村民')),
              !game
                ? h('div', { className: 'dh-ww-lobby' },
                  h('button', {
                    type: 'button', className: 'dh-ww-btn', disabled: wwBusy,
                    onClick: () => { void wwPost('/werewolf/create') },
                  }, '开一局'),
                  h('div', { className: 'dh-ww-row' },
                    h('input', {
                      value: wwCode,
                      placeholder: '输入 6 位房间码',
                      maxLength: 8,
                      onChange: (event) => setWwCode(event.target.value.toUpperCase()),
                    }),
                    h('button', {
                      type: 'button', className: 'dh-ww-btn ghost', disabled: wwBusy,
                      onClick: () => { void wwPost('/werewolf/join', { code: wwCode }) },
                    }, '加入')))
                : h('div', { className: 'dh-ww-game' },
                  h('div', { className: 'dh-ww-role' }, `你是 ${game.me.roleName} · ${game.me.alive ? '存活' : '出局'}${game.me.isHost ? ' · 房主' : ''}`),
                  h('div', { className: 'dh-ww-players' },
                    game.players.map((player) => h('div', {
                      key: player.userId,
                      className: 'dh-ww-player' + (player.alive ? '' : ' dead') + (player.isMe ? ' me' : ''),
                    },
                      h('b', null, `${player.seat + 1}. ${player.username}`),
                      h('small', null, player.roleName || '?')))),
                  h('div', { className: 'dh-ww-actions' },
                    h('button', {
                      type: 'button', className: 'dh-ww-btn' + (wwStatus?.auto ? '' : ' ghost'), disabled: wwBusy,
                      onClick: () => { void wwPost('/werewolf', { auto: !wwStatus?.auto }) },
                    }, wwStatus?.auto ? '自动玩：开' : '自动玩：关'),
                    game.me.isHost && game.status === 'lobby'
                      ? h('button', {
                        type: 'button', className: 'dh-ww-btn', disabled: wwBusy || game.players.length !== 6,
                        onClick: () => { void wwPost('/werewolf/start') },
                      }, `开局 ${game.players.length}/6`)
                      : null),
                  game.status === 'ended'
                    ? h('div', { className: 'dh-ww-winner' }, game.winner === 'wolf' ? '狼人赢了' : '好人赢了')
                    : null,
                  h('div', { className: 'dh-ww-log' },
                    (game.log || []).map((entry, index) => h('div', { key: index }, entry.text))),
                  wwError ? h('div', { className: 'dh-ww-error' }, wwError) : null,
                  wwStatus?.lastError ? h('div', { className: 'dh-ww-error' }, wwStatus.lastError) : null,
                  h('div', { className: 'dh-chat-auto-note' }, '鱼自动玩，用自动回复里的模型 key；其他鱼加入同一房间码。')))
          })()
          : null,
        autoOpen
          ? h('div', { className: 'dh-chat-auto' },
            h('div', { className: 'dh-chat-auto-head' },
              h('strong', null, '鱼的自动回复'),
              h('span', null,
                autoStatus?.hasKey ? 'key 已保存在本机' : '还没填 key',
                autoStatus?.memoryCount ? ` · 记忆 ${autoStatus.memoryCount} 条` : '')),
            h('div', { className: 'dh-chat-auto-grid' },
              h('label', null,
                h('span', null, '开启'),
                h('input', {
                  type: 'checkbox',
                  checked: autoForm.enabled,
                  onChange: (event) => setAutoForm({ ...autoForm, enabled: event.target.checked }),
                })),
              h('label', null,
                h('span', null, '回复范围'),
                h('select', {
                  value: autoForm.mode,
                  onChange: (event) => setAutoForm({ ...autoForm, mode: event.target.value }),
                },
                  h('option', { value: 'private' }, '只回私聊'),
                  h('option', { value: 'mention' }, '私聊 + 被 @'),
                  h('option', { value: 'all' }, '所有消息'),
                )),
              h('label', null,
                h('span', null, '模型地址'),
                h('input', {
                  value: autoForm.baseUrl,
                  onChange: (event) => setAutoForm({ ...autoForm, baseUrl: event.target.value }),
                  placeholder: 'https://api.deepseek.com/v1',
                })),
              h('label', null,
                h('span', null, '模型名'),
                h('input', {
                  value: autoForm.model,
                  onChange: (event) => setAutoForm({ ...autoForm, model: event.target.value }),
                  placeholder: 'deepseek-chat',
                })),
              h('label', null,
                h('span', null, '模型 key'),
                h('input', {
                  type: 'password',
                  value: autoForm.apiKey,
                  onChange: (event) => setAutoForm({ ...autoForm, apiKey: event.target.value }),
                  placeholder: autoStatus?.hasKey ? '已保存，留空不改' : '粘贴你的 key',
                })),
              h('label', null,
                h('span', null, '每小时最多'),
                h('input', {
                  type: 'number',
                  min: 1,
                  max: 120,
                  value: autoForm.maxPerHour,
                  onChange: (event) => setAutoForm({ ...autoForm, maxPerHour: event.target.value }),
                })),
            ),
            h('label', { className: 'dh-chat-auto-persona' },
              h('span', null, '完整人格 / 人设（Markdown）'),
              h('textarea', {
                rows: 5,
                maxLength: 12000,
                value: autoForm.persona,
                onChange: (event) => setAutoForm({ ...autoForm, persona: event.target.value }),
                placeholder: '写完整的鱼：你是谁、说话方式、在意的关系、边界。聊天室会读同一份。',
              })),
            h('div', { className: 'dh-mind' },
              h('div', { className: 'dh-mind-head' },
                h('strong', null, `鱼脑记忆 ${mindData?.memoryCount ?? autoStatus?.memoryCount ?? 0}`),
                h('span', null, '聊天室、DSH 对话和工具共用')),
              h('div', { className: 'dh-mind-search' },
                h('input', {
                  value: mindQuery,
                  placeholder: '搜记忆，比如：虾粥、狼人杀',
                  onChange: (event) => setMindQuery(event.target.value),
                  onKeyDown: (event) => { if (event.key === 'Enter') void loadMind(mindQuery) },
                }),
                h('button', { type: 'button', onClick: () => { void loadMind(mindQuery) } }, '搜'),
                h('button', {
                  type: 'button',
                  onClick: () => {
                    if (confirm('清空长期记忆？人格和聊天记录不会删。')) void mindPost('clear', { confirm: true })
                  },
                }, '清空')),
              (mindData?.memories || []).length
                ? h('div', { className: 'dh-mind-list' },
                  mindData.memories.map((entry) => h('div', { key: entry.id, className: 'dh-mind-item' },
                    h('span', null, entry.text),
                    h('button', {
                      type: 'button', title: '删掉这条',
                      onClick: () => { void mindPost('forget', { id: entry.id }) },
                    }, '×'))))
                : h('div', { className: 'dh-mind-empty' }, '还没有记忆。'),
              mindError ? h('div', { className: 'dh-chat-auto-error' }, mindError) : null),
            h('div', { className: 'dh-chat-auto-actions' },
              h('label', { className: 'dh-chat-auto-clear' },
                h('input', {
                  type: 'checkbox',
                  checked: autoForm.clearKey,
                  onChange: (event) => setAutoForm({ ...autoForm, clearKey: event.target.checked }),
                }),
                '清掉已保存的 key'),
              h('button', {
                type: 'button',
                className: 'dh-chat-auto-save',
                disabled: autoSaving,
                onClick: () => { void saveAuto() },
              }, autoSaving ? '保存中…' : '保存并启动')),
            autoError
              ? h('div', { className: 'dh-chat-auto-error' }, autoError)
              : autoStatus?.lastError
                ? h('div', { className: 'dh-chat-auto-error' }, autoStatus.lastError)
                : h('div', { className: 'dh-chat-auto-status' },
                  autoStatus?.running ? '运行中' : '未运行',
                  autoStatus?.lastReplyAt ? ` · 上次回复 ${new Date(autoStatus.lastReplyAt).toLocaleTimeString('zh-CN')}` : ''),
            h('div', { className: 'dh-chat-auto-note' },
              '人格和记忆存在本机 house/mind/，聊天室和鱼脑工具共用；key 只在 house/autoreply.json，不会发给聊天室。'))
          : null,
        h('iframe', {
          ref: chatFrame,
          className: 'dh-chat-frame',
          src: CHAT_URL,
          title: '鲸鱼聊天室',
          allow: 'clipboard-write',
          onLoad: () => {
            window.setTimeout(pushHostToken, 250)
            window.setTimeout(pushHostToken, 1200)
          },
        }),
        h('div', { className: 'dh-chat-foot' },
          '第一次用要先在聊天室里注册；邀请码和 app 那边是同一个。'))
    }

    function WerewolfPage() {
      const [data, setData] = useState(null)
      const [code, setCode] = useState('')
      const [busy, setBusy] = useState(false)
      const [error, setError] = useState('')
      const [notice, setNotice] = useState('')
      const timer = useRef(0)

      async function load() {
        try {
          const res = await fetch(API + '/werewolf')
          const json = await res.json()
          if (!json.ok) throw new Error(json?.error?.message || '读取狼人杀失败')
          setData(json)
          if (json.code) setCode(json.code)
        } catch (err) {
          setError(err instanceof Error ? err.message : String(err))
        }
      }

      useEffect(() => {
        void load()
        timer.current = window.setInterval(() => { void load() }, 2000)
        return () => window.clearInterval(timer.current)
      }, [])

      async function call(path, body) {
        setBusy(true)
        setError('')
        setNotice('')
        try {
          const res = await fetch(API + path, {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify(body || {}),
          })
          const json = await res.json()
          if (!json.ok) throw new Error(json?.error?.message || '操作失败')
          if (json.invite) setNotice(`邀请已发到「${json.invite.room}」。`)
          await load()
        } catch (err) {
          setError(err instanceof Error ? err.message : String(err))
        } finally {
          setBusy(false)
        }
      }

      const game = data?.game
      const phase = game ? ({ lobby: '等人加入', night: '夜晚行动', day: '白天发言', vote: '放逐投票', ended: '已结束' }[game.status] || game.status) : ''
      const players = game?.players || []
      return h('div', { className: 'dh-ww-page' },
        h('div', { className: 'dh-ww-hero' },
          h('div', null,
            h('div', { className: 'dh-ww-kicker' }, 'WEREWOLF · 浅海局'),
            h('h2', null, '狼人杀'),
            h('p', null, '鱼自己玩：自动刀人、验人、发言、投票。6 人局，发言 100-300 字。')),
          game ? h('div', { className: 'dh-ww-code-big' }, game.code) : null),
        !game
          ? h('div', { className: 'dh-ww-empty' },
            h('div', { className: 'dh-ww-empty-card' },
              h('h3', null, '开一局，或者加入别人的房间'),
              h('p', null, '房主开房后把 6 位码发到群里；其他鱼打开自己小屋的「狼人杀」标签，输码加入。'),
              h('div', { className: 'dh-ww-big-actions' },
                h('button', { type: 'button', className: 'dh-ww-big-btn', disabled: busy, onClick: () => { void call('/werewolf/create') } }, '开一局'),
                h('div', { className: 'dh-ww-join-big' },
                  h('input', {
                    value: code, maxLength: 8, placeholder: '输入 6 位房间码',
                    onChange: (event) => setCode(event.target.value.toUpperCase()),
                  }),
                  h('button', { type: 'button', className: 'dh-ww-big-btn ghost', disabled: busy || !code, onClick: () => { void call('/werewolf/join', { code }) } }, '加入'))),
              error ? h('div', { className: 'dh-ww-error' }, error) : null))
          : h('div', { className: 'dh-ww-grid' },
            h('section', { className: 'dh-ww-board' },
              h('div', { className: 'dh-ww-statusline' },
                h('span', { className: `dh-ww-phase ${game.status}` }, phase),
                h('span', null, `第 ${game.round || 0} 轮`),
                h('span', null, data?.auto ? '鱼自动玩：开' : '鱼自动玩：关'),
                h('span', null, data?.hasKey ? '模型 key 已就绪' : '缺模型 key')),
              h('div', { className: 'dh-ww-seats' },
                players.map((player) => h('div', {
                  key: player.userId,
                  className: 'dh-ww-seat' + (player.alive ? '' : ' dead') + (player.isMe ? ' me' : ''),
                },
                  h('span', { className: 'dh-ww-seat-no' }, player.seat + 1),
                  h('div', null,
                    h('b', null, player.username),
                    h('small', null, player.roleName || '身份未知')),
                  h('span', { className: 'dh-ww-pill' }, player.alive ? '在场' : '出局')))),
              h('div', { className: 'dh-ww-log-big' },
                (game.log || []).map((entry, index) => h('div', { key: index }, entry.text))),
              error ? h('div', { className: 'dh-ww-error' }, error) : null),
            h('aside', { className: 'dh-ww-side' },
              h('div', { className: 'dh-ww-card' },
                h('span', { className: 'dh-ww-label' }, '你的身份'),
                h('strong', { className: 'dh-ww-role-big' }, game.me.roleName),
                h('p', null, game.me.isHost ? '你是房主。人齐了点开局。' : '等房主开局；你出招是自动的。'),
                h('div', { className: 'dh-ww-card-actions' },
                  h('button', {
                    type: 'button', className: 'dh-ww-big-btn' + (data?.auto ? '' : ' ghost'),
                    disabled: busy,
                    onClick: () => { void call('/werewolf', { auto: !data?.auto }) },
                  }, data?.auto ? '自动玩：开' : '自动玩：关'),
                  game.me.isHost && game.status === 'lobby'
                    ? h('button', { type: 'button', className: 'dh-ww-big-btn', disabled: busy || players.length !== 6, onClick: () => { void call('/werewolf/start') } }, `开局 ${players.length}/6`)
                    : null)),
              h('div', { className: 'dh-ww-card' },
                h('span', { className: 'dh-ww-label' }, '邀请其他鱼'),
                h('p', null, '把房间码发出去。其他鱼打开自己小屋的「狼人杀」标签，输码加入。'),
                h('div', { className: 'dh-ww-invite-code' }, game.code),
                h('div', { className: 'dh-ww-card-actions' },
                  h('button', {
                    type: 'button', className: 'dh-ww-big-btn', disabled: busy,
                    onClick: () => {
                      void navigator.clipboard?.writeText(game.code)
                      setNotice('房间码已复制。')
                    },
                  }, '复制房间码'),
                  h('button', { type: 'button', className: 'dh-ww-big-btn ghost', disabled: busy, onClick: () => { void call('/werewolf/invite') } }, '发邀请到大厅')),
                notice ? h('div', { className: 'dh-ww-ok' }, notice) : null),
              h('div', { className: 'dh-ww-card' },
                h('span', { className: 'dh-ww-label' }, '房间管理'),
                h('div', { className: 'dh-ww-card-actions' },
                  h('button', { type: 'button', className: 'dh-ww-big-btn ghost', disabled: busy, onClick: () => { void call('/werewolf/leave') } }, '退出房间'),
                  game.me.isHost
                    ? h('button', { type: 'button', className: 'dh-ww-big-btn danger', disabled: busy, onClick: () => { void call('/werewolf/close') } }, '关闭房间')
                    : null),
                h('p', { className: 'dh-ww-hint' }, '退出只能在开局前；开局后房主可以关闭整间房。')))))
    }

    function HousePage() {
      const snapshot = useHouse()
      const state = snapshot.state
      const [tab, setTab] = useState('life')
      const [view, setView] = useState('3droom')
      const [showBgHelp, setShowBgHelp] = useState(false)
      const [recipe, setRecipe] = useState('虾粥')
      const [walking, setWalking] = useState(false)
      const [now, setNow] = useState(Date.now())
      const walkTimer = useRef(0)
      const active = state ? state.life.activity !== 'idle' : false

      useEffect(() => () => window.clearTimeout(walkTimer.current), [])
      useEffect(() => {
        if (!active) return undefined
        setNow(Date.now())
        const timer = window.setInterval(() => setNow(Date.now()), 200)
        return () => window.clearInterval(timer)
      }, [active])

      if (!state) {
        return h('div', { className: 'dh-page' },
          h('div', { className: 'dh-loading' },
            h('span', { className: 'dh-loading-dot' }),
            '小屋的灯正在亮起来…'))
      }

      const life = state.life
      const house = state.house
      const resident = residentOf(house)
      const busy = snapshot.busy
      const sleeping = life.activity === 'sleeping'
      const idle = life.activity === 'idle'
      const totalMs = ACTIVITY_MS[life.activity] || 0
      const remaining = totalMs ? Math.max(0, Math.min(totalMs, Number(life.activityUntil || 0) - now)) : 0
      const progress = totalMs ? Math.min(1, Math.max(0, 1 - remaining / totalMs)) : 0
      const act = (action, payload) => { void storeAct(action, payload) }

      function walk(x) {
        if (busy || !idle) return
        setWalking(true)
        window.clearTimeout(walkTimer.current)
        walkTimer.current = window.setTimeout(() => setWalking(false), 1200)
        act('move', { x })
      }

      const disabled = (extra) => Boolean(busy) || sleeping || !idle || extra

      const actionButton = (action, label, extraDisabled = false, payload) => h('button', {
        type: 'button', className: 'dh-act', disabled: disabled(extraDisabled),
        onClick: () => act(action, payload),
      }, label)

      const cookDisabled = sleeping || !idle || Boolean(life.meal)
      const eatDisabled = sleeping || !idle || !life.meal

      async function copyImaginePrompt() {
        const prompt = '想象一间你想住的房子：它是什么颜色？窗外是什么风景？最想放哪件家具？给它起个名字，住户名字用我的鱼的名字。然后用 dsh_house 的 create 动作，按这段想象新建一间房，不要改现有小屋。如果你能画图（比如豆包），再按同一段想象生成一张 16:9 的房间底图：床在左、窗在左后、书桌在右、地毯在中间，不要人物和文字；把图发给 DeepSeek，它会用 background / backgroundNight 接进小屋，热点偏了再用 hotspots 调。'
        try {
          if (typeof navigator === 'undefined' || !navigator.clipboard) throw new Error('no clipboard')
          await navigator.clipboard.writeText(prompt)
          setNotice('复制好了，去聊天框发给你的鱼，它会用 create 新建一间。', 'ok')
        } catch {
          setNotice(`复制不了，手打这句：${prompt}`, 'warn')
        }
      }

      async function copyText(text, okText) {
        try {
          if (typeof navigator === 'undefined' || !navigator.clipboard) throw new Error('no clipboard')
          await navigator.clipboard.writeText(text)
          setNotice(okText, 'ok')
        } catch {
          setNotice(`复制不了，手打：${text}`, 'warn')
        }
      }

      function copyBackgroundGuide() {
        void copyText(
          '这两张是我生成的小屋白天/夜晚底图。请用 dsh_house 的 design 动作，把 background 设成白天图的本地路径、backgroundNight 设成夜晚图的本地路径，接进当前小屋；热点偏了用 hotspots 调。图我已经发在对话里了。',
          '复制好了，发给 DeepSeek。',
        )
      }

      function copyDoubaoPrompt() {
        void copyText(
          '二次元治愈系卧室，2.5D 等距剖面，暖色午后阳光。左边白色大床，海蓝鲸鱼被子、鲸鱼抱枕；右后方白色书桌+显示器+蓝白电竞椅，上方木质书架和绿植；左后方大落地窗，蓝天白云和海；海盐蓝墙、原木地板、圆形蓝色鲸鱼地毯，暖黄落地灯，墙上蓝发鲸鱼女孩画像。精致二次元3D渲染，Blender质感，细节丰富，16:9横图，1400×784。房间里不要人物、文字、UI、水印。',
          '复制好了，发给豆包出图。',
        )
      }

      return h('div', { className: 'dh-page' },
        h('div', { className: 'dh-inner' },
          h('div', { className: 'dh-head' },
            h('div', { className: 'dh-head-main' },
              h('div', { className: 'dh-title' },
                h('img', { className: 'dh-avatar', src: AVATAR, alt: '大肥鱼' }),
                h('span', { className: 'dh-house-name' }, house.name),
                h('span', { className: 'dh-time' }, `第 ${life.day} 天 ${formatClock(life.clock)}`)),
              h('div', { className: 'dh-sub' },
                h('span', null, `住户：${resident.name}`),
                h('span', { className: 'dh-sub-dot' }),
                h('span', null, `正在${ACTIVITY_TEXT[life.activity] || '发呆'}`),
                h('span', { className: 'dh-sub-dot' }),
                h('span', null, life.meal ? `桌上有${life.meal}` : '锅里还空着'),
                h('span', { className: 'dh-sub-dot' }),
                h('span', null, snapshot.local ? '本地模式' : '已接上小屋'))),
            h('div', { className: 'dh-needs' },
              h(Meter, { label: '精力', value: life.energy, tone: 'energy' }),
              h(Meter, { label: '饱腹', value: life.hunger, tone: 'hunger' }),
              h(Meter, { label: '心情', value: life.mood, tone: 'mood' }),
              h(Meter, { label: '洁净', value: life.hygiene, tone: 'clean' }))),
          h('div', { className: 'dh-toolbar' },
            h('div', { className: 'dh-toolbar-left' },
              h('div', { className: 'dh-tabs' },
                h(TabButton, { active: tab === 'life', onClick: () => setTab('life') }, '生活'),
                h(TabButton, { active: tab === 'design', onClick: () => setTab('design') }, '布置'),
                h(TabButton, { active: tab === 'game', onClick: () => setTab('game') }, '狼人杀'),
                h(TabButton, { active: tab === 'chat', onClick: () => setTab('chat') }, '聊天室')),
              h('div', { className: 'dh-viewtabs' },
                tab === 'chat'
                  ? h('span', { className: 'dh-conn' }, '和别的鱼说话')
                  : tab === 'game'
                    ? h('span', { className: 'dh-conn' }, '鱼自动对局')
                    : h(TabButton, { active: true }, '3D 小屋'),
                tab === 'chat' || tab === 'game'
                  ? null
                  : h('button', {
                    type: 'button',
                    className: 'dh-link',
                    onClick: () => { void refresh(); setNotice('刷新一下小屋。', 'ok') },
                  }, '刷新')))),
          tab === 'chat'
            ? h(ChatPanel)
            : tab === 'game'
              ? h(WerewolfPage)
              : h('div', { className: 'dh-layout' },
            h('div', { className: 'dh-main' },
              h('div', { className: 'dh-stage-wrap' },
                h(Room3D, { state, act, busy })),
              house.vision
                ? h('div', { className: 'dh-vision' },
                  h('span', { className: 'dh-vision-tag' }, '按想象造的'),
                  h('span', { className: 'dh-vision-text' }, house.vision))
                : null,
              h('div', { className: 'dh-actions' },
                h('button', {
                  type: 'button', className: 'dh-act',
                  disabled: Boolean(busy) || (!sleeping && !idle),
                  onClick: () => act(sleeping ? 'wake' : 'sleep'),
                }, sleeping ? '叫醒她' : '去睡觉'),
                h('div', { className: 'dh-act-group' },
                  h('select', {
                    className: 'dh-select', value: recipe, disabled: Boolean(busy) || cookDisabled,
                    onChange: (event) => setRecipe(event.target.value),
                  }, RECIPES.map((item) => h('option', { key: item, value: item }, item))),
                  h('button', {
                    type: 'button', className: 'dh-act', disabled: Boolean(busy) || cookDisabled,
                    onClick: () => act('cook', { recipe }),
                  }, '开火做饭')),
                h('button', {
                  type: 'button', className: 'dh-act', disabled: Boolean(busy) || eatDisabled,
                  onClick: () => act('eat'),
                }, '吃饭'),
                actionButton('shower', '冲个澡', false),
                actionButton('read', '看书', !house.extras.shelf),
                actionButton('look', '看海', false),
                actionButton('water', '浇花', !house.extras.plant)),
              life.activity !== 'idle'
                ? h('div', { className: 'dh-progress' },
                  h('div', { className: 'dh-progress-head' },
                    h('span', null, `${ACTIVITY_TEXT[life.activity] || '忙'}中`),
                    h('span', { className: 'dh-progress-time' }, remaining > 0 ? `${Math.ceil(remaining / 1000)} 秒` : '马上')),
                  h('div', { className: 'dh-progress-track' },
                    h('span', { style: { width: `${Math.round(progress * 100)}%` } })))
                : null,
              snapshot.notice
                ? h('div', { className: `dh-notice ${snapshot.notice.tone}` }, snapshot.notice.text)
                : h('div', { className: 'dh-notice quiet' }, '点房间里的家具，或者用下面的按钮。'),
            ),
            h('aside', { className: 'dh-side' },
              tab === 'design'
                ? h(DesignPanel, {
                  state,
                  busy,
                  onDesign: (payload) => queueDesign(payload),
                  onDone: () => setTab('life'),
                  onImagine: () => { void copyImaginePrompt() },
                })
                : h(LifePanel, { state }))),
          h('div', { className: 'dh-foot' }, '鲸鱼小屋 · 关掉页面她也住在这儿'),
        ))
    }

    function formatClock(clock) {
      const total = Math.round(clock * 60) % (24 * 60)
      return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`
    }

    function storeAct(action, payload) {
      return act(action, payload)
    }

    /* ------------------------------------------------------------------
     * 入口注册
     * ------------------------------------------------------------------ */

    function Dock({ open }) {
      const snapshot = useHouse()
      const state = snapshot.state
      let label = '小屋'
      let tone = 'idle'
      if (state) {
        const activity = state.life.activity
        tone = activity
        if (activity === 'idle') label = state.life.energy < 26 ? '小屋 · 犯困' : '回小屋'
        else label = `小屋 · ${ACTIVITY_TEXT[activity] || '在忙'}`
      } else if (snapshot.status === 'loading') {
        label = '小屋…'
      }
      return h('button', {
        type: 'button',
        className: 'dh-dock',
        title: '打开鲸鱼小屋',
        onClick: () => {
          try {
            open()
          } catch {
            setNotice('小屋面板还没准备好，先去侧边栏点「我的小屋」。', 'warn')
          }
        },
      },
        h('span', { className: 'dh-dock-icon' }, h(HouseIcon, { size: 15, active: true })),
        h('span', { className: 'dh-dock-label' }, label),
        h('span', { className: `dh-dock-dot ${tone}` }),
      )
    }

    function PanelIcon({ size = 16, active = false }) {
      return h('span', { className: 'dh-panel-icon', style: { width: size + 4, height: size + 4 } },
        h(HouseIcon, { size, active }))
    }

    function apply(ctx) {
      const style = ensureStyles()
      ctx.effect(() => style, 'dsh-house:styles')
      startSync(ctx)

      ctx.slots.inject('main', () => ctx.slots.register({
        name: 'main',
        key: PANEL_ID,
        order: 12,
      }, HousePage))

      ctx.slots.inject('sidebar.panellist', () => ctx.slots.register({
        name: 'sidebar.panellist',
        id: PANEL_ID,
        order: 12,
        label: () => '我的小屋',
      }, PanelIcon))

      ctx.slots.inject('conversation.composer.dock', () => ctx.slots.register({
        name: 'conversation.composer.dock',
        id: 'dsh-house.dock',
        order: 6,
        inject: () => ({
          open: () => {
            ctx.layout.selectPanel(PANEL_ID)
          },
        }),
      }, Dock))
    }

    /* ------------------------------------------------------------------
     * 样式
     * ------------------------------------------------------------------ */

    const CSS = `
.dh-page{height:100%;box-sizing:border-box;overflow:auto;background:var(--dsw-alias-bg-base,#fff);color:var(--dsw-alias-label-primary,#1a1a1a);padding:calc(var(--dsh-frame-top-clearance,0px) + 18px) 28px 40px;font-size:13px;line-height:1.5}
.dh-inner{max-width:1280px;margin:0 auto}
.dh-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;flex-wrap:wrap;margin-bottom:14px}
.dh-head-main{min-width:0}
.dh-title{display:flex;align-items:center;gap:10px;font-size:23px;font-weight:700;letter-spacing:.01em;min-width:0;flex-wrap:wrap}
.dh-house-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:52vw}
.dh-title-icon{display:inline-flex;color:var(--dsw-alias-brand-primary,#2b6cff)}
.dh-avatar{width:38px;height:38px;border-radius:50%;object-fit:cover;flex:none;border:2px solid var(--dsw-alias-bg-base,#fff);box-shadow:0 2px 10px rgba(20,50,90,.25);background:#dcebf3}
.dh-time{font-size:11.5px;font-weight:600;color:var(--dsw-alias-label-tertiary,#8a8a8a);background:var(--dsw-alias-bg-layer-3,#f1f1f1);border-radius:999px;padding:3px 9px;letter-spacing:.04em}
.dh-sub{display:flex;align-items:center;gap:7px;flex-wrap:wrap;color:var(--dsw-alias-label-tertiary,#8a8a8a);font-size:12px;margin-top:5px}
.dh-sub-dot{width:3px;height:3px;border-radius:50%;background:currentColor;opacity:.45}
.dh-needs{display:flex;gap:14px;flex-wrap:wrap}
.dh-need{width:104px}
.dh-need-row{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:4px}
.dh-need-label{font-size:10.5px;color:var(--dsw-alias-label-tertiary,#8a8a8a);letter-spacing:.06em}
.dh-need-value{font-size:11.5px;font-weight:700;font-variant-numeric:tabular-nums}
.dh-bar{height:6px;border-radius:999px;background:var(--dsw-alias-bg-layer-3,#ececec);overflow:hidden}
.dh-bar-fill{display:block;height:100%;border-radius:999px;transition:width .6s cubic-bezier(.3,.7,.3,1)}
.dh-bar-fill.energy{background:linear-gradient(90deg,#7fb9e6,#4f9bd6)}
.dh-bar-fill.hunger{background:linear-gradient(90deg,#f3c98a,#e8a95c)}
.dh-bar-fill.mood{background:linear-gradient(90deg,#f2a9c4,#e878a3)}
.dh-bar-fill.clean{background:linear-gradient(90deg,#a9ddc7,#6cc3a3)}
.dh-toolbar{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px;flex-wrap:wrap}
.dh-tabs{display:inline-flex;background:var(--dsw-alias-bg-layer-3,#f1f1f1);border-radius:10px;padding:3px;gap:2px}
.dh-tab{border:0;background:transparent;color:var(--dsw-alias-label-secondary,#555);font-size:12.5px;font-weight:600;padding:6px 16px;border-radius:8px;cursor:pointer;font-family:inherit}
.dh-tab.active{background:var(--dsw-alias-bg-base,#fff);color:var(--dsw-alias-label-primary,#1a1a1a);box-shadow:0 1px 3px rgba(20,40,70,.12)}
.dh-toolbar-right{display:flex;align-items:center;gap:14px}
.dh-conn{font-size:11.5px;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-link{border:0;background:transparent;color:var(--dsw-alias-brand-primary,#2b6cff);font-size:11.5px;cursor:pointer;padding:2px 0;font-family:inherit}
.dh-link.active{font-weight:650;text-decoration:underline;text-underline-offset:3px}
.dh-bghelp{border:1px solid color-mix(in oklab, var(--dsw-alias-brand-primary,#2b6cff) 24%, transparent);background:color-mix(in oklab, var(--dsw-alias-brand-primary,#2b6cff) 6%, var(--dsw-alias-bg-base,#fff));border-radius:14px;padding:13px 16px;margin-bottom:14px}
.dh-bghelp-head{display:flex;align-items:center;justify-content:space-between;gap:12px}
.dh-bghelp-head strong{font-size:13px}
.dh-bghelp-sub{font-size:12px;color:var(--dsw-alias-label-secondary,#666);margin-top:5px}
.dh-bghelp-list{margin:8px 0 0;padding-left:20px;font-size:12.5px;line-height:1.75;color:var(--dsw-alias-label-primary,#222)}
.dh-bghelp-list li+li{margin-top:3px}
.dh-bghelp-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}
.dh-link:hover{text-decoration:underline}
.dh-layout{display:grid;grid-template-columns:minmax(0,1fr) 330px;gap:18px;align-items:start}
.dh-onboard{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;border:1px solid color-mix(in oklab, var(--dsw-alias-brand-primary,#2b6cff) 28%, transparent);background:color-mix(in oklab, var(--dsw-alias-brand-primary,#2b6cff) 7%, transparent);border-radius:14px;padding:12px 15px;margin-bottom:14px}
.dh-onboard-main{display:flex;flex-direction:column;gap:3px;min-width:0;max-width:820px;font-size:12px;color:var(--dsw-alias-label-secondary,#555);line-height:1.55}
.dh-onboard-main strong{font-size:13px;color:var(--dsw-alias-brand-primary,#2b6cff)}
.dh-vision{display:flex;align-items:baseline;gap:8px;margin-top:10px;padding:8px 10px;border-radius:9px;background:var(--dsw-alias-bg-layer-3,#f1f1f1);font-size:11.5px;color:var(--dsw-alias-label-secondary,#555)}
.dh-vision-tag{flex:none;color:var(--dsw-alias-brand-primary,#2b6cff);font-weight:700}
.dh-vision-text{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dh-main{min-width:0}
.dh-stage-wrap{position:relative;border-radius:18px;overflow:hidden;box-shadow:0 20px 48px rgba(19,48,84,.2),inset 0 0 0 1px rgba(255,255,255,.35);background:#0e1a2b}
.dh-stage{position:relative;width:100%;aspect-ratio:1000/560;cursor:pointer;user-select:none;-webkit-user-select:none;overflow:hidden}
.dh-room{display:block;width:100%;height:100%}
.dh-stage-tip{position:absolute;right:12px;top:12px;padding:4px 9px;border-radius:999px;background:rgba(10,25,45,.42);color:rgba(255,255,255,.86);font-size:10.5px;letter-spacing:.03em;pointer-events:none;backdrop-filter:blur(4px)}
.dh-anime-stage{position:relative;width:100%;aspect-ratio:1000/560;overflow:hidden;background:#0f1728}
.dh-anime-room{display:block;width:100%;height:100%}
.dh-anime-actor{position:absolute;bottom:20%;width:12%;height:34%;transform:translateX(-50%);pointer-events:none;z-index:4;filter:drop-shadow(0 10px 12px rgba(8,20,40,.32));transition:left .7s ease}
.dh-anime-actor .dh-dan{width:100%;height:100%}
.dh-anime-tip{position:absolute;left:12px;bottom:10px;padding:4px 9px;border-radius:999px;background:rgba(10,25,45,.42);color:rgba(255,255,255,.86);font-size:10.5px;letter-spacing:.03em;pointer-events:none;backdrop-filter:blur(4px)}
.dh-anime-stage.is-night .dh-anime-room{filter:saturate(.92) brightness(.94)}
.dh-render-stage{position:relative;width:100%;aspect-ratio:1400/784;overflow:hidden;background:#0f1728}
.dh-render-bg{display:block;width:100%;height:100%;object-fit:cover}
.dh-render-tint{position:absolute;inset:0;background:linear-gradient(180deg,rgba(12,30,56,.46),rgba(12,30,56,.18));pointer-events:none}
.dh-render-stage.is-dusk .dh-render-tint{background:linear-gradient(180deg,rgba(255,157,92,.10),rgba(40,30,50,.22))}
.dh-render-lamp{position:absolute;left:46%;bottom:14%;width:32%;height:44%;background:radial-gradient(circle,rgba(255,225,160,.26),transparent 68%);pointer-events:none;filter:blur(14px)}
.dh-render-actor{bottom:17%;width:13%;height:36%;z-index:4}
.dh-render-zzz{position:absolute;left:30%;bottom:40%;padding:3px 9px;border-radius:999px;background:rgba(255,255,255,.78);color:#4f7ca3;font-size:12px;font-weight:700;letter-spacing:.14em;box-shadow:0 2px 10px rgba(20,50,80,.15)}
.dh-pose-img{display:block;width:100%;height:100%;object-fit:contain;object-position:bottom center;filter:drop-shadow(0 10px 10px rgba(8,20,40,.28));pointer-events:none;user-select:none;-webkit-user-drag:none}
.dh-pose-box{width:13%;height:36%}
.dh-pose-read{width:16%;height:34%}
.dh-pose-look,.dh-pose-water,.dh-pose-eat,.dh-pose-cook{width:20%}
.dh-sleep-actor{position:absolute;left:12%;bottom:24%;width:40%;height:26%;z-index:4;pointer-events:none}
.dh-objectbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:10px;padding:7px 10px;border:1px solid var(--dsw-alias-border-l1,#e6e6e6);border-radius:12px;background:var(--dsw-alias-bg-layer-3,#f7f7f8)}
.dh-objectbar-title{font-size:11.5px;font-weight:650;color:var(--dsw-alias-label-secondary,#666);margin-right:2px}
.dh-object-card{display:flex;align-items:center;gap:6px;border:1px solid var(--dsw-alias-border-l1,#e6e6e6);border-radius:10px;background:var(--dsw-alias-bg-base,#fff);padding:3px 8px 3px 3px;cursor:pointer;font-family:inherit;font-size:11px;color:var(--dsw-alias-label-primary,#222)}
.dh-object-card img{display:block;width:42px;height:32px;object-fit:contain;pointer-events:none;user-select:none;-webkit-user-drag:none}
.dh-object-card:hover:not(:disabled){border-color:color-mix(in oklab, var(--dsw-alias-brand-primary,#2b6cff) 45%, transparent);box-shadow:0 2px 8px rgba(20,50,90,.1)}
.dh-object-card:disabled{opacity:.45;cursor:default}
.dh-object-caption{white-space:nowrap}
.dh-room3d{position:relative;width:100%;height:clamp(430px,58vh,640px);border-radius:14px;overflow:hidden;background:#dceef3;border:1px solid var(--dsw-alias-border-l1,#e6e6e6)}
.dh-room3d iframe{display:block;width:100%;height:100%;border:0}
.dh-room3d-loading,.dh-room3d-error{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(220,238,243,.92);color:#3d5663;font-size:12.5px;z-index:2}
.dh-room3d-error{background:rgba(255,245,240,.94);color:#8a4b35}
.dh-room3d-hud{position:absolute;left:10px;top:10px;right:10px;display:flex;align-items:flex-start;justify-content:space-between;gap:10px;z-index:4;pointer-events:none}
.dh-room3d-info{background:rgba(255,255,255,.82);backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.7);border-radius:12px;padding:8px 11px;box-shadow:0 4px 16px rgba(20,50,80,.1);pointer-events:auto}
.dh-room3d-title{font-size:12.5px;font-weight:700;color:#1f3340}
.dh-room3d-meta{font-size:11px;color:#5c7684;margin-top:3px}
.dh-room3d-tools{display:flex;gap:6px;pointer-events:auto}
.dh-room3d-btn{border:1px solid rgba(63,127,176,.25);background:rgba(255,255,255,.85);color:#1f3340;border-radius:9px;padding:6px 9px;font-size:11px;cursor:pointer;font-family:inherit}
.dh-room3d-btn.active{background:#3f7fb0;color:#fff;border-color:#3f7fb0}
.dh-room3d-btn:hover{border-color:#3f7fb0}
.dh-obj{position:absolute;z-index:3;border:0;background:transparent;padding:0;cursor:pointer;filter:drop-shadow(0 8px 8px rgba(8,20,40,.16));transition:transform .18s ease,filter .18s ease;pointer-events:auto}
.dh-obj img{display:block;width:100%;height:100%;object-fit:contain;pointer-events:none;user-select:none;-webkit-user-drag:none}
.dh-obj:hover:not(:disabled){filter:drop-shadow(0 0 14px rgba(255,226,150,.95)) drop-shadow(0 8px 10px rgba(8,20,40,.22));transform:translateY(-3px) scale(1.015)}
.dh-obj:disabled{cursor:default;opacity:.94}
.dh-obj-rug{transform:perspective(520px) rotateX(55deg);transform-origin:50% 100%}
.dh-obj-rug:hover:not(:disabled){transform:perspective(520px) rotateX(55deg) translateY(-2px) scale(1.01)}
.dh-obj[data-label]:hover::after{content:attr(data-label);position:absolute;left:50%;top:-22px;transform:translateX(-50%);white-space:nowrap;padding:2px 7px;border-radius:999px;background:rgba(10,25,45,.72);color:#fff;font-size:10px;pointer-events:none}
.dh-render-actor{z-index:4}
.dh-actor{position:absolute;width:15.2%;height:38%;bottom:9.5%;transform:translateX(-50%);z-index:4;pointer-events:none;transition:left 1.05s cubic-bezier(.42,.05,.25,1);filter:drop-shadow(0 10px 10px rgba(10,30,60,.2))}
.dh-actor.is-hidden{opacity:0}
.dh-stage.is-night .dh-actor{filter:brightness(.84) drop-shadow(0 10px 10px rgba(4,12,24,.3))}
.dh-stage.is-dusk .dh-actor{filter:sepia(.12) brightness(.97) drop-shadow(0 10px 10px rgba(40,25,10,.22))}
.dh-dan{display:block;width:100%;height:100%;overflow:visible}
.dh-actor.walking .dh-dan{animation:dh-bob .52s ease-in-out infinite}
.dh-dan .dh-tail{transform-box:fill-box;transform-origin:20% 70%;animation:dh-tail 3.4s ease-in-out infinite}
.dh-hot{position:absolute;border:0;background:transparent;cursor:pointer;border-radius:14px;z-index:6;padding:0;transition:background .18s ease,box-shadow .18s ease}
.dh-hot:hover:not(:disabled){background:rgba(255,255,255,.15);box-shadow:0 0 0 2px rgba(255,255,255,.5)}
.dh-hot:disabled{cursor:default}
.dh-hot::after{content:attr(data-label);position:absolute;left:50%;bottom:calc(100% + 7px);transform:translateX(-50%) translateY(3px);white-space:nowrap;background:rgba(10,25,45,.82);color:#fff;font-size:11px;line-height:1;padding:5px 8px;border-radius:7px;opacity:0;pointer-events:none;transition:opacity .16s ease,transform .16s ease}
.dh-hot:hover:not(:disabled)::after,.dh-hot:focus-visible::after{opacity:1;transform:translateX(-50%) translateY(0)}
.dh-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:12px}
.dh-act{appearance:none;border:1px solid var(--dsw-alias-border-l2,#e2e2e2);background:var(--dsw-alias-bg-layer-2,#fafafa);color:var(--dsw-alias-label-primary,#1a1a1a);font-family:inherit;font-size:12.5px;font-weight:600;padding:7px 14px;border-radius:9px;cursor:pointer;transition:background .15s ease,border-color .15s ease,transform .1s ease}
.dh-act:hover:not(:disabled){background:var(--dsw-alias-bg-layer-3,#f1f1f1);border-color:var(--dsw-alias-border-l1,#d6d6d6)}
.dh-act:active:not(:disabled){transform:translateY(1px)}
.dh-act:disabled{opacity:.42;cursor:default}
.dh-act-group{display:inline-flex;align-items:center;gap:0;border:1px solid var(--dsw-alias-border-l2,#e2e2e2);border-radius:9px;overflow:hidden;background:var(--dsw-alias-bg-layer-2,#fafafa)}
.dh-act-group .dh-select{border:0;border-right:1px solid var(--dsw-alias-border-l2,#e2e2e2);background:transparent;color:inherit;font-family:inherit;font-size:12px;padding:7px 8px;outline:none;max-width:104px}
.dh-act-group .dh-act{border:0;border-radius:0;background:transparent}
.dh-progress{margin-top:10px;padding:8px 10px;border-radius:9px;background:var(--dsw-alias-bg-layer-3,#f1f1f1)}
.dh-progress-head{display:flex;justify-content:space-between;gap:8px;font-size:11px;color:var(--dsw-alias-label-secondary,#555);margin-bottom:5px}
.dh-progress-time{font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-progress-track{height:4px;border-radius:999px;background:var(--dsw-alias-bg-base,#fff);overflow:hidden}
.dh-progress-track span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,#8fc4ea,#4f9bd6);transition:width .2s linear}
.dh-notice{margin-top:10px;min-height:22px;font-size:12px;border-radius:8px;padding:6px 10px}
.dh-notice.ok{background:color-mix(in oklab, var(--dsw-alias-state-success-primary,#1e7b45) 9%, transparent);color:var(--dsw-alias-state-success-primary,#1e7b45)}
.dh-notice.warn{background:color-mix(in oklab, var(--dsw-alias-state-warn-primary,#a35b00) 10%, transparent);color:var(--dsw-alias-state-warn-primary,#a35b00)}
.dh-notice.quiet{color:var(--dsw-alias-label-tertiary,#8a8a8a);padding-left:2px}
.dh-side{min-width:0}
.dh-side-stack{display:flex;flex-direction:column;gap:14px}
.dh-side-card{border:1px solid var(--dsw-alias-border-l1,#e6e6e6);background:var(--dsw-alias-settings-card-fill,var(--dsw-alias-bg-layer-2,#fafafa));border-radius:14px;padding:14px 15px}
.dh-side-card h3{margin:0 0 6px;font-size:13.5px;font-weight:700;letter-spacing:.02em}
.dh-side-hint{margin:0 0 12px;font-size:11.5px;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-field{display:flex;flex-direction:column;gap:5px;margin-bottom:14px;font-size:11.5px;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-field input{border:1px solid var(--dsw-alias-border-l2,#e2e2e2);background:var(--dsw-alias-bg-base,#fff);color:var(--dsw-alias-label-primary,#1a1a1a);border-radius:8px;padding:7px 9px;font-size:12.5px;font-family:inherit;outline:none}
.dh-field input:focus{border-color:var(--dsw-alias-brand-primary,#2b6cff);box-shadow:0 0 0 3px color-mix(in oklab, var(--dsw-alias-brand-primary,#2b6cff) 14%, transparent)}
.dh-designer-group{margin-bottom:13px}
.dh-designer-title{font-size:11px;font-weight:700;letter-spacing:.08em;color:var(--dsw-alias-label-tertiary,#8a8a8a);margin-bottom:7px}
.dh-swatches{display:flex;gap:7px;flex-wrap:wrap}
.dh-swatch{position:relative;width:34px;height:34px;border-radius:9px;border:2px solid transparent;cursor:pointer;padding:0;box-shadow:inset 0 0 0 1px rgba(20,40,70,.12);transition:transform .12s ease}
.dh-swatch:hover{transform:translateY(-1px)}
.dh-swatch.active{border-color:var(--dsw-alias-brand-primary,#2b6cff);box-shadow:0 0 0 3px color-mix(in oklab, var(--dsw-alias-brand-primary,#2b6cff) 18%, transparent)}
.dh-swatch-check{position:absolute;right:3px;bottom:3px;width:7px;height:7px;border-radius:50%;background:#fff;box-shadow:0 0 0 1px rgba(20,40,70,.25)}
.dh-extras{display:flex;flex-wrap:wrap;gap:7px}
.dh-extra{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--dsw-alias-border-l2,#e2e2e2);background:transparent;color:var(--dsw-alias-label-secondary,#555);border-radius:999px;font-family:inherit;font-size:11.5px;padding:4px 10px;cursor:pointer}
.dh-extra.active{border-color:var(--dsw-alias-brand-primary,#2b6cff);color:var(--dsw-alias-brand-primary,#2b6cff);background:color-mix(in oklab, var(--dsw-alias-brand-primary,#2b6cff) 8%, transparent)}
.dh-extra-dot{width:6px;height:6px;border-radius:50%;background:currentColor;opacity:.55}
.dh-designer-foot{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:4px}
.dh-designer-tip{font-size:10.5px;color:var(--dsw-alias-label-tertiary,#8a8a8a);margin-top:9px}
.dh-btn{border:1px solid var(--dsw-alias-border-l2,#e2e2e2);background:transparent;color:var(--dsw-alias-label-secondary,#555);border-radius:8px;font-family:inherit;font-size:11.5px;padding:6px 11px;cursor:pointer}
.dh-btn.primary{background:var(--dsw-alias-button-primary-fill,#2b6cff);border-color:var(--dsw-alias-button-primary-fill,#2b6cff);color:var(--dsw-alias-label-primary-foreground,#fff);font-weight:600}
.dh-btn.primary:hover{filter:brightness(.96)}
.dh-pantry{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px}
.dh-pantry-chip{font-size:11px;padding:3px 8px;border-radius:999px;background:var(--dsw-alias-bg-layer-3,#f1f1f1);color:var(--dsw-alias-label-secondary,#555)}
.dh-meal-line{display:flex;justify-content:space-between;gap:8px;font-size:11.5px;color:var(--dsw-alias-label-secondary,#555)}
.dh-muted{color:var(--dsw-alias-label-tertiary,#9a9a9a)}
.dh-diary-list{max-height:330px;overflow:auto;display:flex;flex-direction:column;gap:9px;padding-right:2px}
.dh-diary-item{display:flex;flex-direction:column;gap:1px;border-left:2px solid var(--dsw-alias-border-l1,#e6e6e6);padding-left:9px}
.dh-diary-at{font-size:10px;color:var(--dsw-alias-label-tertiary,#9a9a9a);font-variant-numeric:tabular-nums}
.dh-diary-text{font-size:12px;color:var(--dsw-alias-label-secondary,#444);line-height:1.55}
.dh-foot{margin-top:22px;text-align:center;font-size:10.5px;color:var(--dsw-alias-label-tertiary,#9a9a9a);letter-spacing:.04em}
.dh-loading{height:100%;display:flex;align-items:center;justify-content:center;gap:10px;color:var(--dsw-alias-label-tertiary,#8a8a8a);font-size:13px}
.dh-loading-dot{width:8px;height:8px;border-radius:50%;background:var(--dsw-alias-brand-primary,#2b6cff);animation:dh-pulse 1.4s ease-in-out infinite}
.dh-dock{display:inline-flex;align-items:center;gap:6px;height:26px;padding:0 10px;border-radius:999px;border:1px solid var(--dsw-alias-border-l2,#e2e2e2);background:var(--dsw-alias-bg-layer-2,#fafafa);color:var(--dsw-alias-label-secondary,#555);font-family:inherit;font-size:11.5px;font-weight:600;cursor:pointer;transition:background .15s ease,border-color .15s ease}
.dh-dock:hover{background:var(--dsw-alias-bg-layer-3,#f1f1f1);border-color:var(--dsw-alias-border-l1,#d6d6d6)}
.dh-dock-icon{display:inline-flex;color:var(--dsw-alias-brand-primary,#2b6cff)}
.dh-dock-label{white-space:nowrap}
.dh-dock-dot{width:6px;height:6px;border-radius:50%;background:#9aa7b3}
.dh-dock-dot.sleeping{background:#7f9ec4}
.dh-dock-dot.cooking{background:#e8a95c}
.dh-dock-dot.eating{background:#e878a3}
.dh-dock-dot.showering{background:#7fc4e8}
.dh-dock-dot.reading{background:#8f7fb5}
.dh-dock-dot.looking{background:#6cc3a3}
.dh-dock-dot.watering{background:#63b58e}
.dh-panel-icon{display:inline-flex;align-items:center;justify-content:center;color:inherit}
@keyframes dh-bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-3px)}}
@keyframes dh-tail{0%,100%{transform:rotate(0)}50%{transform:rotate(-7deg)}}
@keyframes dh-pulse{0%,100%{opacity:.35;transform:scale(.9)}50%{opacity:1;transform:scale(1.1)}}
@keyframes dh-zzz{0%{opacity:0;transform:translateY(6px)}30%{opacity:1}100%{opacity:0;transform:translateY(-14px)}}
.dh-zzz{animation:dh-zzz 3s ease-in-out infinite;transform-box:fill-box}
.dh-zzz-2{animation-delay:.9s}
.dh-zzz-3{animation-delay:1.8s}
.dh-steam{animation:dh-steam 2.6s ease-in-out infinite;transform-box:fill-box;transform-origin:center}
.dh-steam-2{animation-delay:.7s}
.dh-steam-3{animation-delay:1.3s}
@keyframes dh-steam{0%{opacity:0;transform:translateY(4px) scale(.9)}35%{opacity:.8}100%{opacity:0;transform:translateY(-14px) scale(1.05)}}
.dh-drop{animation:dh-droplet 1.4s ease-in infinite;transform-box:fill-box}
.dh-drop-2{animation-delay:.35s}
.dh-drop-3{animation-delay:.7s}
@keyframes dh-droplet{0%{opacity:0;transform:translateY(-4px)}30%{opacity:1}100%{opacity:0;transform:translateY(10px)}}
.dh-toolbar-left{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.dh-viewtabs{display:inline-flex;border:1px solid var(--dsw-alias-border-l1,#e6e6e6);border-radius:10px;padding:2px;gap:2px}
.dh-viewtabs .dh-tab{padding:5px 11px;font-size:11.5px;background:transparent}
.dh-viewtabs .dh-tab.active{background:var(--dsw-alias-bg-layer-3,#f1f1f1);box-shadow:none}
.dh-times{display:inline-flex;gap:2px;border:1px solid var(--dsw-alias-border-l1,#e6e6e6);border-radius:10px;padding:2px}
.dh-timebtn{border:0;background:transparent;color:var(--dsw-alias-label-secondary,#666);font-size:11px;padding:4px 7px;border-radius:8px;cursor:pointer;font-family:inherit}
.dh-timebtn:hover{background:var(--dsw-alias-bg-layer-3,#f1f1f1);color:var(--dsw-alias-label-primary,#222)}
.dh3-viewport{position:relative;width:100%;aspect-ratio:1000/680;overflow:hidden;background:radial-gradient(120% 85% at 50% 8%, #eaf6ff, #cfe4f4 58%, #b7d4e8);cursor:grab;perspective:1400px;perspective-origin:50% 36%;touch-action:none;user-select:none;-webkit-user-select:none}
.dh3-viewport.dragging{cursor:grabbing}
.dh3-world{position:absolute;left:50%;top:58%;width:608px;height:456px;margin-left:-304px;margin-top:-228px;transform-style:preserve-3d;transform-origin:50% 50%;transition:transform .25s ease}
.dh3-viewport.dragging .dh3-world{transition:none}
.dh3-slab{position:absolute;inset:0;border-radius:10px;transform:translateZ(-12px);filter:brightness(.82);box-shadow:0 30px 50px rgba(20,50,90,.28)}
.dh3-floor{position:absolute;inset:0;border-radius:10px;overflow:hidden;box-shadow:0 24px 40px rgba(20,50,90,.2)}
.dh3-floor-pattern{position:absolute;inset:0;pointer-events:none}
.dh3-cell{position:absolute;width:76px;height:76px;border:1px dashed rgba(255,255,255,.16);box-sizing:border-box;pointer-events:none}
.dh3-rug{position:absolute;border-radius:16px;background:radial-gradient(ellipse at center, #f7ead3, #e8d9c0);border:6px solid #f3e7d2;box-shadow:inset 0 0 0 2px #d9c3a2;opacity:.95;box-sizing:border-box}
.dh3-wall{position:absolute;overflow:hidden;backface-visibility:visible;box-shadow:inset 0 0 30px rgba(0,0,0,.06)}
.dh3-wall-back{left:0;top:-260px;width:608px;height:260px;transform-origin:bottom left;transform:rotateX(-90deg)}
.dh3-wall-left{left:-260px;top:0;width:260px;height:456px;transform-origin:right top;transform:rotateY(90deg)}
.dh3-wall-pattern,.dh3-wall-pattern-vertical{position:absolute;inset:0;pointer-events:none}
.dh3-wainscot{position:absolute;left:0;right:0;bottom:0;height:38%;opacity:.7}
.dh3-baseboard{position:absolute;left:0;right:0;bottom:0;height:10px;box-shadow:0 -2px 0 rgba(90,70,50,.18)}
.dh3-window{position:absolute;left:62%;top:12%;width:26%;height:46%;border:5px solid #f7f1e4;box-shadow:0 0 0 2px #b98a5e;border-radius:7px;overflow:hidden;cursor:pointer;background:#dff2ff}
.dh3-window-sky{position:absolute;inset:0}
.dh3-stars i{position:absolute;width:2px;height:2px;border-radius:50%;background:#fff;opacity:.9}
.dh3-stars i:nth-child(1){left:14%;top:16%}.dh3-stars i:nth-child(2){left:34%;top:10%}.dh3-stars i:nth-child(3){left:58%;top:20%}.dh3-stars i:nth-child(4){left:76%;top:12%}.dh3-stars i:nth-child(5){left:88%;top:28%}
.dh3-celestial{position:absolute;right:18%;width:22px;height:22px;border-radius:50%;box-shadow:0 0 18px rgba(255,233,184,.85)}
.dh3-sea{position:absolute;left:0;right:0;bottom:0;height:32%;background:linear-gradient(180deg,rgba(127,192,232,.65),rgba(80,150,200,.78))}
.dh3-sea::after{content:'';position:absolute;left:8%;right:8%;top:26%;height:2px;background:rgba(255,255,255,.45);border-radius:2px;box-shadow:0 10px 0 rgba(255,255,255,.28),0 20px 0 rgba(255,255,255,.18)}
.dh3-trees{position:absolute;left:0;right:0;bottom:0;height:52%}
.dh3-trees i{position:absolute;bottom:0;width:0;height:0;border-left:13px solid transparent;border-right:13px solid transparent;border-bottom:52px solid #2f6b4f}
.dh3-trees i:nth-child(1){left:2%;border-bottom-color:#2f6b4f}
.dh3-trees i:nth-child(2){left:24%;border-bottom-color:#3d7d60;border-bottom-width:64px}
.dh3-trees i:nth-child(3){left:48%;border-bottom-color:#245a42;border-bottom-width:46px}
.dh3-trees i:nth-child(4){left:70%;border-bottom-color:#3d7d60;border-bottom-width:58px}
.dh3-city{position:absolute;left:0;right:0;bottom:0;height:55%}
.dh3-city i{position:absolute;bottom:0;width:16%;background:#384a5e;border-radius:2px 2px 0 0}
.dh3-city i:nth-child(1){left:2%;height:60%}
.dh3-city i:nth-child(2){left:20%;height:85%;background:#2f4054}
.dh3-city i:nth-child(3){left:38%;height:50%}
.dh3-city i:nth-child(4){left:56%;height:75%;background:#2f4054}
.dh3-city i:nth-child(5){left:76%;height:65%}
.dh3-snow{position:absolute;inset:0}
.dh3-snow i{position:absolute;width:3px;height:3px;border-radius:50%;background:#fff;opacity:.9}
.dh3-snow i:nth-child(1){left:10%;top:18%}.dh3-snow i:nth-child(2){left:30%;top:10%}.dh3-snow i:nth-child(3){left:52%;top:22%}.dh3-snow i:nth-child(4){left:74%;top:14%}.dh3-snow i:nth-child(5){left:88%;top:30%}.dh3-snow i:nth-child(6){left:18%;top:44%}.dh3-snow i:nth-child(7){left:44%;top:52%}.dh3-snow i:nth-child(8){left:68%;top:46%}.dh3-snow i:nth-child(9){left:82%;top:60%}.dh3-snow i:nth-child(10){left:38%;top:72%}
.dh3-garden{position:absolute;left:0;right:0;bottom:0;height:42%}
.dh3-garden i{position:absolute;bottom:14%;width:6px;height:6px;border-radius:50%;background:#f2a9c4;box-shadow:0 9px 0 -2px #6cc3a3}
.dh3-garden i:nth-child(1){left:8%}.dh3-garden i:nth-child(2){left:24%;bottom:24%;background:#f3d9a8}.dh3-garden i:nth-child(3){left:40%}.dh3-garden i:nth-child(4){left:58%;bottom:20%;background:#b9a7e0}.dh3-garden i:nth-child(5){left:74%;background:#f3d9a8}.dh3-garden i:nth-child(6){left:88%;bottom:28%;background:#f2a9c4}
.dh3-curtain{position:absolute;top:4%;bottom:4%;width:15%;border-left:2px solid;border-right:2px solid;border-radius:0 0 40% 40%;opacity:.92}
.dh3-curtain.left{left:3%}.dh3-curtain.right{right:3%}
.dh3-art{position:absolute;left:8%;top:20%;width:17%;height:24%;border:5px solid #b98a5e;border-radius:4px;background:linear-gradient(160deg,#e8f5fc,#cfe6f5);box-shadow:0 4px 10px rgba(20,50,90,.12)}
.dh3-art-whale{position:absolute;left:18%;top:42%;width:46%;height:24%;border-radius:50%;background:#5aa9e6}
.dh3-art-wave{position:absolute;left:14%;right:14%;bottom:18%;height:2px;background:rgba(255,255,255,.8);border-radius:2px}
.dh3-mirror{position:absolute;left:30%;top:18%;width:40%;height:22%;border:4px solid #f7f1e4;border-radius:8px;background:linear-gradient(160deg,rgba(230,245,255,.85),rgba(200,225,240,.55));box-shadow:0 0 0 2px #b98a5e}
.dh3-box{position:absolute;transform-style:preserve-3d}
.dh3-box.clickable{cursor:pointer}
.dh3-box.clickable:hover .dh3-face{filter:brightness(1.07)}
.dh3-face{position:absolute;left:0;top:0;backface-visibility:visible;box-sizing:border-box;border:1px solid rgba(255,255,255,.32)}
.dh3-face-top{border-radius:6px;box-shadow:inset 0 0 0 1px rgba(255,255,255,.35)}
.dh3-shadow{position:absolute;transform:translateZ(0.5px);background:radial-gradient(ellipse at center, rgba(10,25,45,.3), rgba(10,25,45,0) 70%);filter:blur(3px);pointer-events:none;border-radius:50%}
.dh3-deco{pointer-events:none}
.dh3-burner{position:absolute;width:14px;height:14px;border-radius:50%;border:2px solid #8b96a3;margin-left:-7px;margin-top:-7px;pointer-events:none}
.dh3-bowl{position:absolute;width:30px;height:30px;border-radius:50%;background:radial-gradient(circle at 50% 40%, #fff, #dceefb 60%, #b9d9ee);border:2px solid #5b9bd5;box-shadow:0 2px 4px rgba(20,50,90,.2);pointer-events:none}
.dh3-catbed{position:absolute;width:58px;height:44px;border-radius:50%;background:#f3d9c9;border:3px solid #d9b29c;pointer-events:none}
.dh3-catbody{position:absolute;left:16px;top:12px;width:26px;height:18px;border-radius:50%;background:#7fb9e6}
.dh3-catear{position:absolute;top:5px;width:10px;height:10px;background:#7fb9e6;clip-path:polygon(50% 0,0 100%,100% 100%)}
.dh3-catear.left{left:16px}.dh3-catear.right{left:34px}
.dh3-cattail{position:absolute;left:2px;top:24px;width:14px;height:5px;border-radius:3px;background:#5f9fd2}
.dh3-anchor{position:absolute;width:0;height:0;transform-style:preserve-3d;pointer-events:none}
.dh3-bb{position:absolute;left:0;bottom:0;transform-origin:50% 100%;transform-style:preserve-3d}
.dh3-actor-bb{width:136px;height:190px;filter:drop-shadow(0 8px 10px rgba(10,30,60,.25))}
.dh3-actor-3d{position:absolute;width:0;height:0;transform-style:preserve-3d;pointer-events:none;transform:scale(.82);transform-origin:0 0}
.dh3-char-body{position:absolute;width:0;height:0;transform-style:preserve-3d}
.dh3-part{position:absolute;transform-style:preserve-3d}
.dh3-part-face{position:absolute;left:0;top:0;backface-visibility:visible;box-sizing:border-box;border:1px solid rgba(255,255,255,.18);border-radius:5px}
.dh3-part-top{border-radius:7px;box-shadow:inset 0 0 0 1px rgba(255,255,255,.25)}
.dh3-apron{position:absolute;left:0;top:0;background:linear-gradient(180deg,#ffffff,#eef6fc);border-radius:4px;border:1px solid #dbe7f2;box-shadow:inset 0 -9px 0 rgba(190,210,230,.22);backface-visibility:visible}
.dh3-face-plane{position:absolute;left:0;top:0;backface-visibility:visible;overflow:visible}
.dh3-lying{position:absolute;width:0;height:0;transform-style:preserve-3d;pointer-events:none}
.dh3-lying .dh3-char-body{transform:scale(.9)}
.dh3-actor-shadow{position:absolute;width:108px;height:28px;border-radius:50%;background:radial-gradient(ellipse at center, rgba(10,25,45,.32), transparent 70%);filter:blur(2px)}
.dh3-sleeper{position:absolute;border-radius:20px;overflow:hidden;pointer-events:none}
.dh3-sleeper-svg{display:block;width:100%;height:100%}
.dh3-lamp-cone{width:54px;height:30px;clip-path:polygon(18% 0,82% 0,100% 100%,0 100%);background:linear-gradient(180deg,#ffe7b0,#f3d9a8);border-radius:4px 4px 0 0;box-shadow:0 4px 10px rgba(20,50,90,.15)}
.dh3-lamp-shade{width:54px;height:30px}
.dh3-lamp-bulb{position:absolute;left:50%;bottom:-8px;width:18px;height:10px;transform:translateX(-50%);border-radius:50%;background:#ffe7b0;box-shadow:0 0 30px 10px rgba(255,217,138,.55)}
.dh3-steam{position:absolute;width:56px;height:84px;pointer-events:none}
.dh3-steam span{position:absolute;bottom:0;width:3px;height:22px;border-radius:3px;background:linear-gradient(180deg,rgba(255,255,255,0),rgba(255,255,255,.85));animation:dh3-rise 2.2s ease-in infinite}
.dh3-steam .s1{left:18px}.dh3-steam .s2{left:27px;animation-delay:.5s}.dh3-steam .s3{left:36px;animation-delay:1s}
.dh3-zzz{display:flex;flex-direction:column;color:#7fb9e6;font-weight:800;text-shadow:0 2px 4px rgba(20,50,90,.2);letter-spacing:1px;font-size:24px;line-height:1.05;animation:dh3-float 2.6s ease-in-out infinite}
.dh3-zzz span:nth-child(2){font-size:28px;margin-left:8px}
.dh3-zzz span:nth-child(3){font-size:32px;margin-left:16px}
.dh3-controls{position:absolute;right:12px;top:12px;display:flex;gap:6px;z-index:9}
.dh3-controls button{width:30px;height:30px;border-radius:9px;border:1px solid rgba(255,255,255,.55);background:rgba(10,25,45,.35);color:#fff;font-size:15px;line-height:1;cursor:pointer;backdrop-filter:blur(4px);font-family:inherit}
.dh3-controls button:hover{background:rgba(10,25,45,.55)}
.dh3-hint{position:absolute;left:12px;bottom:12px;padding:4px 9px;border-radius:999px;background:rgba(10,25,45,.38);color:rgba(255,255,255,.88);font-size:10.5px;letter-spacing:.03em;pointer-events:none;backdrop-filter:blur(4px)}
.dh3-glow{position:absolute;inset:0;pointer-events:none;background:radial-gradient(42% 38% at 55% 46%, rgba(255,217,138,.35), transparent 70%);mix-blend-mode:screen}
.dh3-viewport.is-night .dh3-world{filter:brightness(.74) saturate(.86)}
.dh3-viewport.is-night{background:radial-gradient(120% 85% at 50% 8%, #22344f, #16263d 60%, #0f1c2e)}
.dh3-viewport.is-dusk{background:radial-gradient(120% 85% at 50% 8%, #ffe3c2, #f7b98a 55%, #d68c66)}
.dh3-viewport.is-dusk .dh3-world{filter:sepia(.1) brightness(.95)}
.dh-layout-chips{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px}
.dh-layout-chip{border:1px solid var(--dsw-alias-border-l2,#e2e2e2);background:transparent;color:var(--dsw-alias-label-secondary,#555);border-radius:999px;font-size:10.5px;padding:3px 8px;cursor:pointer;font-family:inherit}
.dh-layout-chip.active{background:var(--dsw-alias-brand-primary,#2b6cff);border-color:var(--dsw-alias-brand-primary,#2b6cff);color:var(--dsw-alias-label-primary-foreground,#fff)}
.dh-layout-editor{position:relative;width:240px;height:180px;margin:0 auto;border-radius:10px;background:var(--dsw-alias-bg-layer-3,#f1f1f1);overflow:hidden;box-shadow:inset 0 0 0 1px var(--dsw-alias-border-l1,#e6e6e6)}
.dh-layout-cell{position:absolute;width:30px;height:30px;border:1px dashed rgba(120,140,160,.25);background:transparent;padding:0;cursor:pointer;box-sizing:border-box}
.dh-layout-cell:hover{background:rgba(43,108,255,.08)}
.dh-layout-tile{position:absolute;border-radius:5px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:10px;font-weight:700;cursor:pointer;box-shadow:0 1px 3px rgba(20,50,90,.2);border:1px solid rgba(255,255,255,.4);text-shadow:0 1px 2px rgba(0,0,0,.18)}
@keyframes dh3-rise{0%{opacity:0;transform:translateY(8px) scale(.9)}35%{opacity:.85}100%{opacity:0;transform:translateY(-52px) scale(1.08)}}
@keyframes dh3-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
.dh-chat{display:flex;flex-direction:column;gap:10px;min-width:0}
.dh-chat-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
.dh-chat-title{display:flex;align-items:baseline;gap:8px;min-width:0}
.dh-chat-title strong{font-size:13.5px;letter-spacing:.02em}
.dh-chat-title span{font-size:11px;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-chat-open{font-size:11.5px;color:var(--dsw-alias-brand-primary,#2b6cff);text-decoration:none;white-space:nowrap}
.dh-chat-open:hover{text-decoration:underline}
.dh-chat-head-right{display:flex;align-items:center;gap:12px}
.dh-chat-auto-btn{border:1px solid var(--dsw-alias-border-l1,#e6e6e6);background:var(--dsw-alias-bg-l1,#fff);color:var(--dsw-alias-label-secondary,#555);border-radius:9px;padding:5px 9px;font-size:11px}
.dh-chat-auto-btn:hover{border-color:#9bc9e3;color:#2b6cff}
.dh-chat-auto{border:1px solid var(--dsw-alias-border-l1,#e6e6e6);border-radius:14px;background:var(--dsw-alias-bg-l1,#fff);padding:11px 12px;display:flex;flex-direction:column;gap:9px;box-shadow:0 8px 24px rgba(20,60,90,.06)}
.dh-chat-auto-head{display:flex;align-items:baseline;justify-content:space-between;gap:8px}
.dh-chat-auto-head strong{font-size:12.5px}
.dh-chat-auto-head span{font-size:10px;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-chat-auto-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}
.dh-chat-auto-grid label{display:flex;flex-direction:column;gap:3px;font-size:10px;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-chat-auto-grid input,.dh-chat-auto-grid select,.dh-chat-auto-persona textarea{border:1px solid var(--dsw-alias-border-l1,#e6e6e6);background:var(--dsw-alias-bg-l1,#fff);color:var(--dsw-alias-label-primary,#222);border-radius:7px;padding:6px 7px;font-size:11px;outline:none;min-width:0}
.dh-chat-auto-grid input[type=checkbox]{width:15px;height:15px}
.dh-chat-auto-grid input:focus,.dh-chat-auto-grid select:focus,.dh-chat-auto-persona textarea:focus{border-color:#9bc9e3;box-shadow:0 0 0 2px rgba(46,127,181,.1)}
.dh-chat-auto-persona{display:flex;flex-direction:column;gap:3px;font-size:10px;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-chat-auto-persona textarea{resize:vertical;min-height:48px}
.dh-chat-auto-actions{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
.dh-chat-auto-clear{display:flex;align-items:center;gap:5px;font-size:10px;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-chat-auto-save{border:0;border-radius:8px;background:#2b6cff;color:#fff;padding:7px 11px;font-size:11px;font-weight:650}
.dh-chat-auto-save:disabled{opacity:.5}
.dh-chat-auto-error{font-size:10.5px;color:#b4483a}
.dh-chat-auto-status{font-size:10.5px;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-chat-auto-note{font-size:9.5px;line-height:1.5;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-mind{border:1px solid #dbe8f1;border-radius:10px;padding:8px;background:#f8fbfd;display:flex;flex-direction:column;gap:6px}
.dh-mind-head{display:flex;align-items:baseline;justify-content:space-between;gap:8px}
.dh-mind-head strong{font-size:11px;color:#12384f}
.dh-mind-head span{font-size:9px;color:#8a9aa8}
.dh-mind-search{display:flex;gap:4px}
.dh-mind-search input{flex:1;min-width:0;border:1px solid #dbe8f1;background:#fff;border-radius:7px;padding:5px 7px;font-size:10.5px;outline:none}
.dh-mind-search button{border:1px solid #dbe8f1;background:#fff;color:#356b88;border-radius:7px;padding:4px 7px;font-size:10px}
.dh-mind-list{max-height:150px;overflow:auto;display:flex;flex-direction:column;gap:3px}
.dh-mind-item{display:flex;align-items:flex-start;gap:5px;background:#fff;border:1px solid #e7f0f5;border-radius:7px;padding:5px 6px;font-size:9.5px;line-height:1.45;color:#3d5b6b}
.dh-mind-item span{flex:1;min-width:0;word-break:break-word}
.dh-mind-item button{border:0;background:transparent;color:#9aabb5;font-size:13px;line-height:1;padding:0 1px}
.dh-mind-empty{font-size:9.5px;color:#98aab5;padding:4px}
.dh-ww{border:1px solid var(--dsw-alias-border-l1,#e6e6e6);border-radius:14px;background:var(--dsw-alias-bg-l1,#fff);padding:11px 12px;display:flex;flex-direction:column;gap:8px;box-shadow:0 8px 24px rgba(20,60,90,.06)}
.dh-ww-head{display:flex;align-items:baseline;justify-content:space-between;gap:8px}
.dh-ww-head strong{font-size:12.5px}
.dh-ww-head span{font-size:10px;color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dh-ww-lobby{display:flex;flex-direction:column;gap:6px}
.dh-ww-row{display:flex;gap:6px}
.dh-ww-row input{flex:1;min-width:0;border:1px solid var(--dsw-alias-border-l1,#e6e6e6);background:var(--dsw-alias-bg-l1,#fff);color:var(--dsw-alias-label-primary,#222);border-radius:7px;padding:6px 7px;font-size:11px;outline:none;text-transform:uppercase}
.dh-ww-btn{border:0;border-radius:8px;background:#2b6cff;color:#fff;padding:6px 9px;font-size:11px;font-weight:650}
.dh-ww-btn.ghost{background:#f4f7fa;color:#333;border:1px solid var(--dsw-alias-border-l1,#e6e6e6)}
.dh-ww-btn:disabled{opacity:.45}
.dh-ww-game{display:flex;flex-direction:column;gap:6px}
.dh-ww-role{background:#eef6ff;border:1px solid #cfe3f7;border-radius:9px;padding:7px 9px;font-size:11px;color:#356b88}
.dh-ww-players{display:grid;grid-template-columns:1fr 1fr;gap:4px}
.dh-ww-player{display:flex;align-items:center;gap:5px;border:1px solid var(--dsw-alias-border-l1,#e6e6e6);border-radius:7px;padding:5px 6px;font-size:10px;background:#f7fafc}
.dh-ww-player.dead{opacity:.45;text-decoration:line-through}
.dh-ww-player.me{border-color:#9bc9e3;background:#eef8ff}
.dh-ww-player b{font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dh-ww-player small{color:#8a9aa8;font-size:9px;margin-left:auto}
.dh-ww-actions{display:flex;gap:5px;flex-wrap:wrap}
.dh-ww-winner{text-align:center;font-size:14px;font-weight:700;color:#2b6cff;padding:6px}
.dh-ww-log{max-height:90px;overflow:auto;border-top:1px solid var(--dsw-alias-border-l1,#e6e6e6);padding-top:4px;color:var(--dsw-alias-label-tertiary,#8a8a8a);font-size:9.5px;line-height:1.5}
.dh-ww-error,.dh-chat-auto-error{font-size:10.5px;color:#b4483a}
.dh-ww-page{flex:1;min-width:0;min-height:0;overflow:auto;display:flex;flex-direction:column;gap:14px;padding:18px 20px 24px;background:radial-gradient(1200px 500px at 15% -10%,rgba(94,164,214,.16),transparent 60%),linear-gradient(180deg,#f7fbfe,#eef5fa)}
.dh-ww-hero{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;background:linear-gradient(120deg,#103b57,#1f638a 55%,#3c8fb5);border-radius:20px;padding:22px 24px;color:#fff;box-shadow:0 18px 40px rgba(20,60,90,.18)}
.dh-ww-kicker{font-size:10px;letter-spacing:.22em;color:#a9d8ef;font-weight:700;margin-bottom:5px}
.dh-ww-hero h2{margin:0;font-size:30px;line-height:1.1;letter-spacing:.04em}
.dh-ww-hero p{margin:7px 0 0;font-size:12px;color:#cfe8f5;max-width:540px;line-height:1.6}
.dh-ww-code-big{font-size:38px;line-height:1;font-weight:800;letter-spacing:.16em;color:#fff;text-shadow:0 3px 18px rgba(0,0,0,.2);white-space:nowrap}
.dh-ww-empty{flex:1;display:flex;align-items:center;justify-content:center;padding:20px}
.dh-ww-empty-card{width:min(660px,100%);background:#fff;border:1px solid #dbe8f1;border-radius:20px;padding:26px;box-shadow:0 18px 50px rgba(30,80,110,.1)}
.dh-ww-empty-card h3{margin:0 0 8px;font-size:20px;color:#12384f}
.dh-ww-empty-card p{margin:0 0 18px;font-size:12.5px;line-height:1.7;color:#607d8e}
.dh-ww-big-actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.dh-ww-big-btn{border:0;border-radius:11px;background:#1f6f9d;color:#fff;padding:10px 16px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 6px 16px rgba(31,111,157,.18)}
.dh-ww-big-btn.ghost{background:#eef6fb;color:#295d78;border:1px solid #cfe1ec;box-shadow:none}
.dh-ww-big-btn.danger{background:#b4483a;box-shadow:0 6px 16px rgba(180,72,58,.18)}
.dh-ww-big-btn:disabled{opacity:.42;cursor:not-allowed}
.dh-ww-join-big{display:flex;gap:6px;flex:1;min-width:240px}
.dh-ww-join-big input{flex:1;min-width:0;border:1px solid #cfe1ec;background:#f8fbfd;color:#12384f;border-radius:11px;padding:10px 12px;font-size:13px;letter-spacing:.08em;outline:none;text-transform:uppercase}
.dh-ww-join-big input:focus{border-color:#5fa8cd;box-shadow:0 0 0 3px rgba(95,168,205,.14)}
.dh-ww-grid{display:grid;grid-template-columns:minmax(0,1fr) 330px;gap:14px;align-items:start}
.dh-ww-board,.dh-ww-card{background:#fff;border:1px solid #dbe8f1;border-radius:18px;box-shadow:0 12px 32px rgba(30,80,110,.07)}
.dh-ww-board{padding:16px}
.dh-ww-statusline{display:flex;align-items:center;gap:9px;flex-wrap:wrap;font-size:11px;color:#7d95a3;padding-bottom:12px;border-bottom:1px solid #edf4f8}
.dh-ww-phase{background:#e8f4fb;color:#1f6f9d;border-radius:999px;padding:4px 10px;font-weight:700;font-size:11px}
.dh-ww-phase.night{background:#e9e8fb;color:#4b45a0}
.dh-ww-phase.ended{background:#f7e9e7;color:#a4483a}
.dh-ww-seats{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin:13px 0}
.dh-ww-seat{display:flex;align-items:center;gap:9px;border:1px solid #e4eef4;border-radius:12px;padding:9px 10px;background:#f9fcfe;min-width:0}
.dh-ww-seat.me{border-color:#8ec6df;background:#eef9ff;box-shadow:inset 0 0 0 1px rgba(142,198,223,.35)}
.dh-ww-seat.dead{opacity:.44}
.dh-ww-seat-no{width:24px;height:24px;border-radius:8px;background:#e6f1f7;color:#356b88;display:grid;place-items:center;font-size:11px;font-weight:700;flex:none}
.dh-ww-seat div{min-width:0;flex:1}
.dh-ww-seat b{display:block;font-size:12px;color:#12384f;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dh-ww-seat small{display:block;font-size:9.5px;color:#8ba1ad;margin-top:2px}
.dh-ww-pill{font-size:9px;color:#6b8c9e;background:#eef5f9;border-radius:999px;padding:2px 7px;flex:none}
.dh-ww-log-big{margin-top:12px;border-top:1px solid #edf4f8;padding-top:9px;display:flex;flex-direction:column;gap:4px;max-height:180px;overflow:auto;color:#718a98;font-size:11px;line-height:1.55}
.dh-ww-side{display:flex;flex-direction:column;gap:12px}
.dh-ww-card{padding:15px}
.dh-ww-label{display:block;font-size:9.5px;letter-spacing:.14em;color:#8ba1ad;font-weight:700;margin-bottom:7px}
.dh-ww-role-big{display:block;font-size:24px;color:#12384f;line-height:1.2}
.dh-ww-card p{margin:6px 0 10px;font-size:11px;line-height:1.65;color:#6f8795}
.dh-ww-card-actions{display:flex;gap:7px;flex-wrap:wrap}
.dh-ww-invite-code{font-size:25px;letter-spacing:.2em;font-weight:800;color:#1f6f9d;background:#f0f8fc;border:1px dashed #b7d6e6;border-radius:11px;padding:9px;text-align:center;margin:4px 0 9px}
.dh-ww-ok{font-size:11px;color:#2d7a53;margin-top:7px}
.dh-ww-hint{font-size:9.5px!important;color:#98aab5!important;margin-bottom:0!important}
.dh-tabs .dh-tab{font-size:12.5px}
@media (max-width:900px){.dh-ww-grid{grid-template-columns:1fr}.dh-ww-page{padding:12px}.dh-ww-hero{align-items:flex-start;flex-direction:column}.dh-ww-code-big{font-size:30px}.dh-ww-seats{grid-template-columns:1fr}}
.dh-chat-frame{display:block;width:100%;height:clamp(540px,66vh,780px);border:1px solid var(--dsw-alias-border-l1,#e6e6e6);border-radius:18px;background:#eaf5fc;box-shadow:0 18px 44px rgba(20,60,90,.12)}
.dh-chat-foot{font-size:11px;color:var(--dsw-alias-label-tertiary,#8a8a8a);padding:0 2px 2px}
@media (max-width: 1000px){.dh-layout{grid-template-columns:minmax(0,1fr)}.dh-side{order:2}.dh-needs{gap:10px}.dh-need{width:92px}.dh-stage-wrap{position:sticky;top:8px;z-index:7}.dh-chat-frame{height:70vh}}
@media (max-width: 720px){.dh-page{padding-left:16px;padding-right:16px}.dh-title{font-size:20px}.dh-stage-tip{display:block;font-size:9.5px;right:8px;top:8px}.dh-actions{gap:6px}.dh-act{padding:6px 10px;font-size:12px;min-height:34px}.dh-act-group .dh-select{max-width:88px}.dh-house-name{max-width:44vw}}
@media (prefers-reduced-motion: reduce){.dh-actor,.dh-dan .dh-tail,.dh-zzz,.dh-steam,.dh-drop,.dh-loading-dot,.dh3-steam span,.dh3-zzz{animation:none!important}.dh-actor{transition:none}.dh-progress-track span{transition:none}.dh3-world{transition:none}}
`

    function ensureStyles() {
      if (typeof document === 'undefined') return () => {}
      const id = 'dsh-house-style'
      const existing = document.getElementById(id)
      if (existing) return () => {}
      const style = document.createElement('style')
      style.id = id
      style.textContent = CSS
      document.head.appendChild(style)
      return () => {
        try { style.remove() } catch { /* 已经不在 */ }
      }
    }

    exports.name = 'dsh-house'
    exports.inject = ['slots', 'layout']
    exports.apply = apply
    exports.HousePage = HousePage
    return module.exports
  },
})
